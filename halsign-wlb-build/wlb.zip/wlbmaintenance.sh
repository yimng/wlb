#!/bin/bash

if [ -f /tmp/wlb/DwmWebSvc.exe.lock -o -f /tmp/wlb/DwmRestWebSvc.exe.lock -o -f /tmp/wlb/DwmAnalEngSvc.exe.lock.exe.lock -o -f /tmp/wlb/DwmDataColSvc.exe.lock ]; then
	#if any of the lock files exist, wlb must running currently
	wlb_running=1;
fi
/etc/init.d/workloadbalancing stop
sync; echo 3 > /proc/sys/vm/drop_caches

#start wlb only if if it was running
if [ "$wlb_running" == "1" ]; then
	/etc/init.d/workloadbalancing start
fi

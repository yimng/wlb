﻿-- =========================================================================
-- (c) Copyright 2012 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Date:		Mar 10, 2012
-- Description:
--	 	Function update script
-- =========================================================================

-- =========================================================================
-- (c) Copyright 2012 Citrix CSystems, Inc
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Date:		April 18, 2012
-- Description:
--	 Drop all existing functions, custom types and views
--
-- =========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".core_drop_all();

CREATE FUNCTION "WorkloadBalancing".core_drop_all()
RETURNS void AS 
$$
DECLARE
   _sql text;

BEGIN
	for _sql in 
		(
			(select 'DROP FUNCTIon IF EXISTS ' || quote_ident(ns.nspname) || '.' || proname || '(' || oidvectortypes(proargtypes) || ') CASCADE;' as drop_statement
			from pg_proc inner join pg_namespace ns on (pg_proc.pronamespace = ns.oid)
			where ns.nspname = 'WorkloadBalancing')
			
			UNION
			
			(select 'DROP VIEW IF EXISTS ' || quote_ident(schemaname) || '.' || viewname || ';' as drop_statement
			from pg_views 
			where schemaname = 'WorkloadBalancing')
			
			UNION
			
			(select 'DROP TYPE IF EXISTS ' || quote_ident(ns.nspname) || '.' || typname || ' CASCADE;' as drop_statement
			from pg_type pt1 
				left join pg_namespace ns on (ns.oid = pt1.typnamespace)
			where ns.nspname = 'WorkloadBalancing'
				and ns.nspname NOT IN ('pg_catalog', 'information_schema')
				and (pt1.typrelid = 0 
					 OR 
					(select pc.relkind = 'c' from pg_class pc where pc.oid = pt1.typrelid)
					) 
				and not exists(select 1 from pg_type pt2 where pt2.oid = pt1.typelem and pt2.typarray = pt1.oid))
		)
	loop
		execute _sql;
	end loop;
END;
$$ LANGUAGE plpgsql;

SELECT "WorkloadBalancing".core_drop_all();

/******************************************************************************/
/* (c) Copyright 2011 Citrix Systems, Inc.									  */
/* ALL RIGHTS RESERVED														  */
/*																			  */
/* Project:	SQL																  */
/* Module:	Citrix DWM Core Default Static Configuration					  */
/******************************************************************************/

/******************************************************************************
hypervisor_type_insert_value
*******************************************************************************/

CREATE OR REPLACE FUNCTION "WorkloadBalancing"."hypervisor_type_insert_value" 
(
  "_id" integer,
  "_name" varchar
)
RETURNS void AS
$$
BEGIN

	if not exists(select * from "WorkloadBalancing"."hypervisor_type" ht
    		 	  where ht."ID" = _id 
                  and lower(ht."Name") = lower(_name)) 
    then
		insert into  "WorkloadBalancing"."hypervisor_type" values (_id, _name);
	end if;	

END;
$$
LANGUAGE 'plpgsql';

-- Insert the hypervisor types
select * from "WorkloadBalancing"."hypervisor_type_insert_value"(1, 'Xen Server');

-- Drop the function
DROP FUNCTION "WorkloadBalancing"."hypervisor_type_insert_value"("_id" integer, "_name" varchar);

/******************************************************************************
optimize_reason_insert_value
*******************************************************************************/
CREATE OR REPLACE FUNCTION "WorkloadBalancing"."optimize_reason_insert_value" 
(
  "_id" integer,
  "_reason" varchar
)
RETURNS void AS
$$
BEGIN

	if not exists(select * from "WorkloadBalancing"."optimize_reason" opr
    		 	  where opr."id" = _id 
                  and lower(opr."reason") = lower(_reason)) 
    then
		insert into  "WorkloadBalancing"."optimize_reason"(id, reason)
		values (_id, _reason);
	end if;	

END;
$$
LANGUAGE 'plpgsql';


select * from "WorkloadBalancing"."optimize_reason_insert_value"(0, 'None');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(1, 'Cpu');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(2, 'Memory');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(3, 'Disk');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(4, 'Network');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(5, 'Consolidate');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(6, 'Disk Read');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(7, 'Disk Write');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(8, 'Network Read');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(9, 'Network Write');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(10, 'Load Average');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(11, 'PowerOn');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(12, 'PowerOff');
select * from "WorkloadBalancing"."optimize_reason_insert_value"(13, 'Runstate');

-- Drop the function
DROP FUNCTION "WorkloadBalancing"."optimize_reason_insert_value"("_id" integer, "_reason" varchar);


/******************************************************************************
core_component_insert_value
*******************************************************************************/
CREATE OR REPLACE FUNCTION "WorkloadBalancing"."core_component_insert_value" 
(
  "_id" integer,
  "_component_name" varchar
)
RETURNS void AS
$$
BEGIN

 if not exists(select * from "WorkloadBalancing"."core_component" 
  			   where id = _id 
               and lower(component_name) = lower(_component_name))
 then
	insert into  "WorkloadBalancing"."core_component"(id, component_name)
	values (_id, _component_name);
 end if;
END;
$$
LANGUAGE 'plpgsql';

-- Insert component types for the configuration
select * from "WorkloadBalancing"."core_component_insert_value"(1, 'Data Collection');
select * from "WorkloadBalancing"."core_component_insert_value"(2, 'Installer');
select * from "WorkloadBalancing"."core_component_insert_value"(3, 'General');
select * from "WorkloadBalancing"."core_component_insert_value"(4, 'Analysis Engine');
select * from "WorkloadBalancing"."core_component_insert_value"(5, 'Web Service Host');

-- Drop the function
DROP FUNCTION "WorkloadBalancing"."core_component_insert_value"("_id" integer, "_component_name" varchar);


/******************************************************************************
core_config_set_value
*******************************************************************************/
CREATE OR REPLACE FUNCTION "WorkloadBalancing"."core_config_set_value" 
(
  "_component_id" integer,
  "_category" varchar,
  "_item_name" varchar,
  "_value" varchar,
  "_default_value" varchar,
  "_description" varchar,
  "_touched_by" varchar = NULL,
  "_overwrite" integer = 0
)
RETURNS void AS
$$
declare UTCTimestamp timestamp;
BEGIN
 
 UTCTimestamp = (select current_timestamp at time zone 'UTC');

 if not exists(select * from "WorkloadBalancing"."core_config" 
  			   where component_id = _component_id 
 			   and category = _category and
 			   item_name = _item_name)
 then
 	insert into "WorkloadBalancing"."core_config" 
    	(component_id,
 		category, 
 		item_name,
 		value,
 		default_value,
 		description,
 		touched_by,
 		tstamp)
 		values (_component_id,
 		_category,
 		_item_name,
 		_value, 
 		_default_value,
 		_description,
 		_touched_by,
 		UTCTimestamp);
 	else
 		if (_overwrite <> 0) 
 		then
 			update "WorkloadBalancing"."core_config" 
 			set value = _value,
 			tstamp = getutcdate(),
 			touched_by = _touched_by
 			where component_id = _component_id and
 			category = _category and 
 			item_name = _item_name;
 		end if; 
 end if;
END;
$$
LANGUAGE 'plpgsql';


/*
Data collection and analysis engine.
*/
select * from "WorkloadBalancing"."core_config_set_value"
(	5, 
	'Security',	
    'WlbUsername', 
    '', 
    '', 
    'The username with access to the Web Service interface to the system.'
);

select * from "WorkloadBalancing"."core_config_set_value"
(	5, 
	'Security',	
    'WlbPassword', 
    '', 
    '', 
    'The encrypted password for the username account with access to the Web Service interface to the system.'
);

select * from "WorkloadBalancing"."core_config_set_value"
(	1, 
	'Collection', 
    'PollInterval', 
    '5', 
    '5', 
    'The interval, in seconds, at which the data collectors collects performance metrics'
);

select * from "WorkloadBalancing"."core_config_set_value"
(	1, 
	'Collection', 
    'AuditLogRetrievalInterval', 
    '2', 
    '2', 
    'The minimum time interval that the wlb data collecter retrieves XenServer audit log. Defaults to 2 minutes.'
);

select * from "WorkloadBalancing"."core_config_set_value"
(	4, 
	'Intervals',  
    'PollInterval', 
    '120', 
    '120', 
    'The interval, in seconds, at which the analysis engine checks for pool optimizations'
);

select * from "WorkloadBalancing"."core_config_set_value"
(	1, 
	'Grooming',	
    'DBSizeThreshold', 
    '3758096384', 
    '3758096384', 
    'Database size in bytes that will trigger automated grooming for SQLExpress databases'
);

select * from "WorkloadBalancing"."core_config_set_value"
(	1, 
	'Grooming',	
    'DBTrimPercent', 
    '15', 
    '15', 
    'Percentage of the historical data we will trim off'
);

/*
General and installer configuration values for core_config
*/
select * from "WorkloadBalancing"."core_config_set_value"
(	3, 
	'General', 
    'Product_GUID',
    '8C99917C-FC1C-431e-88E0-8CD2EEC68A50', 
    '8C99917C-FC1C-431e-88E0-8CD2EEC68A50', 
    'The authentication/authorization mode under which the data collection component runs.'
);

select * from "WorkloadBalancing"."core_config_set_value"
(	3, 
	'General', 
    'MAJOR_VERSION', 
    '6.1', 
    '', 
    'Major Version'
);

select * from "WorkloadBalancing"."core_config_set_value"
(	3, 
	'General', 
    'DWM_DB_UPGRADABLE', 
    'True', 
    '', 
    'Allow database upgrades on top of this version'
);

select * from "WorkloadBalancing"."core_config_set_value"
(   3, 
    'General', 
    'DBSchemaVersion', 
    '1', 
    '', 
    'Database schema current version'
);

select * from "WorkloadBalancing"."core_config_set_value"
(	3, 
	'General', 
    'PRODUCT_SHORT_NAME', 
    'WLB', 
    '', 
    'Product Short Name'
);

select * from "WorkloadBalancing"."core_config_set_value"
(	3, 
	'General', 
    'PRODUCT_LONG_NAME', 
    'Workload Balancing', 
    '',
    'Product Long Name'
);

/*
Report subscription settings
*/
/*
select * from "WorkloadBalancing"."core_config_set_value"
(	3, 
	'Reporting', 
    'SMTPServer', 
    'localhost', 
    'localhost', 
    'SMTP server address'
);
*/

-- Drop the function
DROP FUNCTION "WorkloadBalancing"."core_config_set_value" 
(
  "_component_id" integer,
  "_category" varchar,
  "_item_name" varchar,
  "_value" varchar,
  "_default_value" varchar,
  "_description" varchar,
  "_touched_by" varchar,
  "_overwrite" integer
);


/******************************************************************************
collection_state_insert_value
*******************************************************************************/
CREATE OR REPLACE FUNCTION "WorkloadBalancing"."collection_state_insert_value" 
(
  "_id" integer,
  "_description" varchar
)
RETURNS void AS
$$
BEGIN

	if not exists(select * from "WorkloadBalancing"."collection_state"
    		 	  where stateid = _id 
                  and lower(description) = lower(_description)) 
    then
		insert into "WorkloadBalancing"."collection_state"(stateid, description)
		values (_id, _description);
	end if;	

END;
$$
LANGUAGE 'plpgsql';

select * from "WorkloadBalancing"."collection_state_insert_value"(1, 'Active');
select * from "WorkloadBalancing"."collection_state_insert_value"(2, 'Inactive');
select * from "WorkloadBalancing"."collection_state_insert_value"(3, 'Not Collecting');

-- Drop the function
DROP FUNCTION "WorkloadBalancing"."collection_state_insert_value"("_id" integer, "_description" varchar);

/******************************************************************************
tmp_add_update_hv_pool_config
*******************************************************************************/
CREATE OR REPLACE FUNCTION "WorkloadBalancing"."tmp_add_update_hv_pool_config" 
(
  "_name" varchar,
  "_value" varchar,
  "_default_value" varchar,
  "_description" varchar = null 
)
RETURNS void AS
$$
declare UTCTimestamp timestamp;
BEGIN
 
	UTCTimestamp = (select current_timestamp at time zone 'UTC');

	-- This section is for default data
	if not exists(select * from "WorkloadBalancing"."hv_pool_config"
    		 	  where pool_id is null and lower(name) = lower(_name)) 
    then
		insert into "WorkloadBalancing"."hv_pool_config"
        (pool_id, name, value, default_value, description, tstamp)
		values  
        (null, _name, _value, _default_value, _description, UTCTimestamp);
    else
    	update "WorkloadBalancing"."hv_pool_config"
		set default_value = _default_value,
			description = _description,
        	tstamp = UTCTimestamp
		where pool_id is null and lower(name) = lower(_name);
	end if;	

	-- This section is for adding the new fields for existing pools
   	if not exists(select * from "WorkloadBalancing"."hv_pool_config" 
    			 where pool_id is not null and lower(name) = lower(_name)) 
	then
    	insert into "WorkloadBalancing"."hv_pool_config" 
        (pool_id, name, value, default_value, description, tstamp)
		select distinct pool_id, _name, _value, _default_value, _description, UTCTimestamp
			from "WorkloadBalancing"."hv_pool_config"
			where pool_id is not null;
	end if;

END;
$$
LANGUAGE 'plpgsql';

 -- Insert the default weighting factors used the XenCenter UI.
delete from "WorkloadBalancing"."hv_pool_config" where pool_id is null;

select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('CpuHighThresholdFactor', '.85', '.85', 'Used by XenCenter to compute the high CPU threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('CpuMediumThresholdFactor', '.50', '.50', 'Used by XenCenter to compute the medium CPU threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('CpuLowThresholdFactor', '.25', '.25', 'Used by XenCenter to compute the low CPU threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('MemoryHighThresholdFactor', '1.25', '1.25', 'Used by XenCenter to compute the high memory threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('MemoryMediumThresholdFactor', '10.00', '10.00', 'Used by XenCenter to compute the medium memory threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('MemoryLowThresholdFactor', '20.00', '20.00' , 'Used by XenCenter to compute the low memory threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NetworkReadHighThresholdFactor', '.85', '.85', 'Used by XenCenter to compute the high network read threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NetworkReadMediumThresholdFactor', '.50', '.50', 'Used by XenCenter to compute the medium network read threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NetworkReadLowThresholdFactor', '.15', '.15', 'Used by XenCenter to compute the low network read threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NetworkWriteHighThresholdFactor', '.85', '.85', 'Used by XenCenter to compute the high network write threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NetworkWriteMediumThresholdFactor', '.50', '.50', 'Used by XenCenter to compute the medium network write threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NetworkWriteLowThresholdFactor', '.15', '.15', 'Used by XenCenter to compute the low network write threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DiskReadHighThresholdFactor', '.85', '.85', 'Used by XenCenter to compute the high disk read threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DiskReadMediumThresholdFactor', '.50', '.50', 'Used by XenCenter to compute the medium disk read threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DiskReadLowThresholdFactor', '.15', '.15', 'Used by XenCenter to compute the low disk read threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DiskWriteHighThresholdFactor', '.85', '.85', 'Used by XenCenter to compute the high disk write threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DiskWriteMediumThresholdFactor', '.50', '.50', 'Used by XenCenter to compute the medium disk write threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DiskWriteLowThresholdFactor', '.15', '.15', 'Used by XenCenter to compute the low disk write threshold value from the configured critical value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('CpuMediumWeightFactor', '.60', '.60', 'Used by XenCenter to compute the medium CPU weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('CpuLowWeightFactor', '.30', '.30', 'Used by XenCenter to compute the low CPU weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('MemoryMediumWeightFactor', '.60', '.60', 'Used by XenCenter to compute the medium memory weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('MemoryLowWeightFactor', '.30', '.30', 'Used by XenCenter to compute the low memory weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NetworkReadMediumWeightFactor', '.60', '.60', 'Used by XenCenter to compute the medium network read weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NetworkReadLowWeightFactor', '.30', '.30', 'Used by XenCenter to compute the low network read weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NetworkWriteMediumWeightFactor', '.60', '.60', 'Used by XenCenter to compute the medium network write weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NetworkWriteLowWeightFactor', '.30', '.30', 'Used by XenCenter to compute the low network write weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DiskReadMediumWeightFactor', '.60', '.60', 'Used by XenCenter to compute the medium disk read weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DiskReadLowWeightFactor', '.30', '.30', 'Used by XenCenter to compute the low disk read weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DiskWriteMediumWeightFactor', '.60', '.60', 'Used by XenCenter to compute the medium disk write weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DiskWriteLowWeightFactor', '.30', '.30', 'Used by XenCenter to compute the low disk write weight value from the configured importance.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('OptimizationMode', '0', '0', 'Optimization mode for the pool.  0=Max Performance, 1=Max Density');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('OverCommitCpuInPerfMode', 'false', 'false', 'Flag to indicate if analysis engine should recommond running more virtual CPUs than physical CPUs when optimization mode is max performance');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('OverCommitCpuInDensityMode', 'true', 'true', 'Flag to indicate if analysis engine should recommond running more virtual CPUs than physical CPUs when optimization mode is max density');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('OverCommitCpuRatio', '1', '1', 'Used by the WLB VM placement algorithm');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('RecentMoveMinutes', '30', '30', 'Minimum time interval, in minutes, after a VM has moved before WLB will recommend another move for the VM.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('UseNameMatching', 'false', 'false', 'Flag to indicate if the WLB VM placement algorithm should consider VM lineage, based the name of the VM, during VM initial placement.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('NameMatchingPattern', 'NumericSuffix', 'NumericSuffix', 'The name matching pattern to used if UseNameMatching is set to true.  NumericSuffix is the naming convention used by LabManager.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('AutoBalanceEnabled', 'false', 'false', 'Flag to indicate if the WLB optimization engine should automatically apply optimization recommendations.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('AutoBalancePollIntervals', '3', '3', 'The consecutive number of WLB analysis engine poll intervals that a set of optimization recommendations must persist before they are automatically applied.  The default poll interval is 2 minutes.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('AutoBalanceSeverity', 'High', 'High', 'The minimum severity a set of optimization recommendations must have to be automatically applied.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('AutoBalanceAggressiveness', 'Low', 'Low', 'Specify how aggressively apply auto optimization recommendations.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('EnableOptimizationModeSchedules', 'false', 'false', 'Toggles whether WLB will process Optimization Mode scheduled tasks.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('PowerManagementEnabled', 'false', 'false', 'Flag to indicate if WLB power management (power hosts off/on) is enabled.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('PowerManagementPollIntervals', '3', '3', 'Depricated.  The consecutive number of WLB analysis engine poll intervals that a set of power recommendations must persist before they are automatically applied.  The default poll interval is 2 minutes.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('HonorHAPlan', 'false', 'false', 'Flag to indicate if the WLB optimization engine should honor the Xen server high availability (do not recommend optimization the violate the HA plan).');
--select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('MinimizeLoadOnPoolMaster', 'true', 'true', 'Flag to indicate if the VM placement algorithm should try to minimized the load on the pool master.');
--select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('MinimizeLoadStarThreshold', '2.5', '2.5', 'When the star rating of the pool master exceed the next highest host by this value, the pool master will be recommended to run a VM.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('PoolMasterCpuLimit', '.35', '.35', 'Limit the total CPU utilization of the host acting as the pool master to this value.  -1 indicates the limit should not be enforced.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('PoolMasterNetIoLimit', '100', '100', 'Limit the average network utilization of the host acting as the pool master to this value, in megabytes.  -1 indicates the limit should not be enforced.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('PreferPowerOnOverCompression', 'false', 'false', 'Flag to indicate if the VM placement and optimization algorithms should power on a host before compressing the memory alloted to running guests.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('PowerOnHostIfNoMemory', 'false', 'false', 'Flag to indicate if the VM placement logic should attempt to power-on an additional host when the pool does not have enough free memory to satisfy the minimum dynamic memory setting of the VM.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('PowerOnHostIfNoSR', 'false', 'false', 'Flag to indicate if the VM placement logic should attempt to power-on an additional host when the pool does not have a storage repository required by the VM attached to a running host.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('CompressGuestsToRelievePressure', 'true', 'false', 'Flag to indicate if the optimization engine, when running in maximum performance mode, should compress guest memory in order to migrate a VM off of a host that has exceeded a metric threshold limit.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('CompressGuestsToPreservePower', 'true', 'false', 'Flag to indicate if the optimization engine, when running in maximum density mode, should compress guest memory in order to power off a host.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('DefaultHostMemoryOverhead', '419430400', '419430400', 'The default host memory overhead to be used when adding hosts for which we cannot determine the actual memory overhead (powered off)');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('AuditLogRetrieveBackDays', '0', '0', 'The number of days in the past that old audit log will be retrieved, default is 0 days.  Please consult the WLB documentation before changing this value.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('RetrieveAuditLog', 'true', 'true', 'Flag indicating whether we should retrieve the audit log for this pool. Default is 1.');
select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('PoolAuditLogGranularity', 'Minimum', 'Minimum', 'Specify the pool audit trail log granularity. Default is Minimum.');

-- Drop the function
DROP FUNCTION "WorkloadBalancing"."tmp_add_update_hv_pool_config"("_name" varchar, "_value" varchar, "_default_value" varchar, "_description" varchar);
-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated:	Nov 26 2010
--		Converted to PostGreSQL
-- Description:	Populates the culture table with appropriate data
-- Parameters:
--   None
-- Returns:
--   Nothing
-- ==========================================================================
CREATE OR REPLACE FUNCTION "WorkloadBalancing".core_data_add_or_update_culture
(
	_name 			varchar(10),
	_two_letter_code 	char(2),
	_display_name 		varchar(50)
)
RETURNS VOID AS $$
BEGIN

	if exists(select * from culture where two_letter_code = _two_letter_code)
	then
		update culture
		set name = _name,
			display_name = _display_name
		where two_letter_code = _two_letter_code;

	else
		insert into culture
			( name, two_letter_code, display_name )
			values ( _name, _two_letter_code, _display_name );
	end if;

END;
$$ LANGUAGE plpgsql;

select * from "WorkloadBalancing".core_data_add_or_update_culture('en-US', 'en', 'English');
select * from "WorkloadBalancing".core_data_add_or_update_culture('fr-FR', 'fr', 'French');
select * from "WorkloadBalancing".core_data_add_or_update_culture('de-DE', 'de', 'German');
select * from "WorkloadBalancing".core_data_add_or_update_culture('ja-JP', 'ja', 'Japanese');
select * from "WorkloadBalancing".core_data_add_or_update_culture('es-ES', 'es', 'Spanish');

-- Drop the function
DROP FUNCTION "WorkloadBalancing".core_data_add_or_update_culture
(
	_name 			varchar(10),
	_two_letter_code 	char(2),
	_display_name 		varchar(50)
);
/*
 * (c) Copyright 2008 Citrix Systems, Inc.
 * ALL RIGHTS RESERVED
 *
 * Project:	SQL
 * Module:	Citrix DWM Scheduling Static Data
 *
 * $LOG$
 *
 */
CREATE OR REPLACE FUNCTION "WorkloadBalancing".tmp_add_action_type
(
	_id int,
	_name varchar(100),
	_description varchar(1024),
	_assembly varchar(255),
	_class varchar(255)
)
RETURNS VOID AS $$
BEGIN
    
    if exists(select * from sched_action_type where id = _id)
	then 
		update sched_action_type
			set name = _name,
				description = _description,
				assembly = _assembly,
				class = _class
		where id = _id;

	else
		insert into sched_action_type (id,
								name,
								description,
								assembly,
								class)
						values  (_id,
								 _name,
								 _description,
								 _assembly, 
								 _class);
	end if;

END;
$$ LANGUAGE plpgsql;

/*
	these used to be in the config file... default values
*/
select * from "WorkloadBalancing".tmp_add_action_type (1, 'SetOptimizationMode', 'Sets the Optimization Mode for a Pool.
Parameters:
PoolId(int) OR PoolUUID(string): Identifier of the Pool  
OptMode(int): 0 = Maximum Density; 1 = Maximum Performance', 'Citrix.Dwm.Domain', 'Citrix.Dwm.Domain.WlbSetOptModeTaskProcessor');

DROP FUNCTION "WorkloadBalancing".tmp_add_action_type
(
	_id int,
	_name varchar(100),
	_description varchar(1024),
	_assembly varchar(255),
	_class varchar(255)
);
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Rabin Karki
-- Date:		Mar 10, 2011
-- Description:
--	 Inserts data into audit log object and action tables
-- ============================================================================

CREATE FUNCTION "WorkloadBalancing"."add_audit_log_object" 
(
  _name varchar(96),
  _enabled boolean default false,
  _description varchar(1024) default null
)
RETURNS void AS
$$
BEGIN
	if not exists(select * from hv_audit_log_event_object where name=_name)
    then
		insert into hv_audit_log_event_object (name, description, enabled) values(_name, _description, _enabled);
	end if;	 
END;
$$
LANGUAGE 'plpgsql';


CREATE FUNCTION "WorkloadBalancing"."add_audit_log_action" 
(  
  _name varchar(96),
  _enabled boolean default false,
  _description varchar(1024) default null
)
RETURNS void AS
$$
BEGIN
	if not exists(select * from hv_audit_log_event_action where name=_name)
    then
		insert into hv_audit_log_event_action (name, description, enabled) values(_name, _description, _enabled);
	end if;	 
END;
$$
LANGUAGE 'plpgsql';

-- These are the audit log objects and actions
-- If you want more actions or objects set the enabled flag to true
-- objects to be logged
select * from add_audit_log_object('host', true);
select * from add_audit_log_object('vm', true);
select * from add_audit_log_object('pool', true);
-- objects not to be logged
select * from add_audit_log_object('auth', false);
select * from add_audit_log_object('blob', false);
select * from add_audit_log_object('bond', false);
select * from add_audit_log_object('console', false);
select * from add_audit_log_object('crashdump', false);
select * from add_audit_log_object('event', false);
select * from add_audit_log_object('host_cpu', false);
select * from add_audit_log_object('host_crashdump', false);
select * from add_audit_log_object('host_metrics', false);
select * from add_audit_log_object('host_patch', false);
select * from add_audit_log_object('http', false);
select * from add_audit_log_object('message', false);
select * from add_audit_log_object('network', false);
select * from add_audit_log_object('pbd', false);
select * from add_audit_log_object('pif', false);
select * from add_audit_log_object('pif_metrics', false);
select * from add_audit_log_object('pool_patch', false);
select * from add_audit_log_object('role', false);
select * from add_audit_log_object('secret', false);
select * from add_audit_log_object('session', false);
select * from add_audit_log_object('sm', false);
select * from add_audit_log_object('sr', false);
select * from add_audit_log_object('subject', false);
select * from add_audit_log_object('task', false);
select * from add_audit_log_object('tunnel', false);
select * from add_audit_log_object('user', false);
select * from add_audit_log_object('vbd', false);
select * from add_audit_log_object('vbd_metrics', false);
select * from add_audit_log_object('vdi', false);
select * from add_audit_log_object('vif', false);
select * from add_audit_log_object('vif_metrics', false);
select * from add_audit_log_object('vlan', false);
select * from add_audit_log_object('vm_guest_metrics', false);
select * from add_audit_log_object('vm_metrics', false);
select * from add_audit_log_object('vmpp', false);
select * from add_audit_log_object('vtpm', false);

-- actions to be logged
select * from add_audit_log_action('clean_reboot', true);
select * from add_audit_log_action('clean_shutdown', true);
select * from add_audit_log_action('clone', true);
select * from add_audit_log_action('copy', true);
select * from add_audit_log_action('create', true);
select * from add_audit_log_action('create_vlan', true);
select * from add_audit_log_action('destroy', true);
select * from add_audit_log_action('disable', true);
select * from add_audit_log_action('disable_ha', true);
select * from add_audit_log_action('enable', true);
select * from add_audit_log_action('enable_ha', true);
select * from add_audit_log_action('forget', true);
select * from add_audit_log_action('hard_reboot', true);
select * from add_audit_log_action('hard_shutdown', true);
select * from add_audit_log_action('join', true);
select * from add_audit_log_action('join_force', true);
select * from add_audit_log_action('migrate', true);
select * from add_audit_log_action('pool_migrate', true);
select * from add_audit_log_action('reboot', true);
select * from add_audit_log_action('set_address', true);
select * from add_audit_log_action('shutdown', true);
select * from add_audit_log_action('snapshot', true);
select * from add_audit_log_action('snapshot_with_quiesce', true);
select * from add_audit_log_action('start', true);
select * from add_audit_log_action('start_on', true);
select * from add_audit_log_action('suspend', true);
-- actions not to be logged
select * from add_audit_log_action('abort_new_master', false);
select * from add_audit_log_action('add_tags', false);
select * from add_audit_log_action('add_to_alarm_config', false);
select * from add_audit_log_action('add_to_archive_schedule', false);
select * from add_audit_log_action('add_to_archive_target_config', false);
select * from add_audit_log_action('add_to_backup_schedule', false);
select * from add_audit_log_action('add_to_blocked_operations', false);
select * from add_audit_log_action('add_to_gui_config', false);
select * from add_audit_log_action('add_to_hvm_boot_params', false);
select * from add_audit_log_action('add_to_license_server', false);
select * from add_audit_log_action('add_to_logging', false);
select * from add_audit_log_action('add_to_other_config', false);
select * from add_audit_log_action('add_to_platform', false);
select * from add_audit_log_action('add_to_qos_algorithm_params', false);
select * from add_audit_log_action('add_to_roles', false);
select * from add_audit_log_action('add_to_sm_config', false);
select * from add_audit_log_action('add_to_status', false);
select * from add_audit_log_action('add_to_vcpus_params', false);
select * from add_audit_log_action('add_to_vcpus_params_live', false);
select * from add_audit_log_action('add_to_xenstore_data', false);
select * from add_audit_log_action('apply', false);
select * from add_audit_log_action('apply_edition', false);
select * from add_audit_log_action('archive_now', false);
select * from add_audit_log_action('assert_agile', false);
select * from add_audit_log_action('assert_attachable', false);
select * from add_audit_log_action('assert_can_boot_here', false);
select * from add_audit_log_action('assert_can_evacuate', false);
select * from add_audit_log_action('assert_can_host_ha_statefile', false);
select * from add_audit_log_action('assert_operation_valid', false);
select * from add_audit_log_action('atomic_set_resident_on', false);
select * from add_audit_log_action('attach', false);
select * from add_audit_log_action('attach_static_vdis', false);
select * from add_audit_log_action('audit_log_append', false);
select * from add_audit_log_action('backup_rrds', false);
select * from add_audit_log_action('bugreport_upload', false);
select * from add_audit_log_action('call_plugin', false);
select * from add_audit_log_action('cancel', false);
select * from add_audit_log_action('certificate_install', false);
select * from add_audit_log_action('certificate_list', false);
select * from add_audit_log_action('certificate_sync', false);
select * from add_audit_log_action('certificate_uninstall', false);
select * from add_audit_log_action('change_password', false);
select * from add_audit_log_action('checkpoint', false);
select * from add_audit_log_action('clean', false);
select * from add_audit_log_action('commit_new_master', false);
select * from add_audit_log_action('compute_free_memory', false);
select * from add_audit_log_action('compute_memory_overhead', false);
select * from add_audit_log_action('connect_console', false);
select * from add_audit_log_action('connect_console/host_console', false);
select * from add_audit_log_action('connect_migrate', false);
select * from add_audit_log_action('connect_remotecmd', false);
select * from add_audit_log_action('copy_bios_strings', false);
select * from add_audit_log_action('create_alert', false);
select * from add_audit_log_action('create_new_blob', false);
select * from add_audit_log_action('create_vlan_from_pif', false);
select * from add_audit_log_action('crl_install', false);
select * from add_audit_log_action('crl_list', false);
select * from add_audit_log_action('crl_uninstall', false);
select * from add_audit_log_action('csvm', false);
select * from add_audit_log_action('db_forget', false);
select * from add_audit_log_action('db_introduce', false);
select * from add_audit_log_action('deconfigure_wlb', false);
select * from add_audit_log_action('designate_new_master', false);
select * from add_audit_log_action('detach_static_vdis', false);
select * from add_audit_log_action('detect_nonhomogeneous_external_auth', false);
select * from add_audit_log_action('disable_binary_storage', false);
select * from add_audit_log_action('disable_external_auth', false);
select * from add_audit_log_action('disable_local_storage_caching', false);
select * from add_audit_log_action('disable_redo_log', false);
select * from add_audit_log_action('dmesg', false);
select * from add_audit_log_action('dmesg_clear', false);
select * from add_audit_log_action('eject', false);
select * from add_audit_log_action('emergency_ha_disable', false);
select * from add_audit_log_action('emergency_reset_master', false);
select * from add_audit_log_action('emergency_transition_to_master', false);
select * from add_audit_log_action('enable_binary_storage', false);
select * from add_audit_log_action('enable_external_auth', false);
select * from add_audit_log_action('enable_local_storage_caching', false);
select * from add_audit_log_action('enable_redo_log', false);
select * from add_audit_log_action('evacuate', false);
select * from add_audit_log_action('force_unlock', false);
select * from add_audit_log_action('forget_data_source_archives', false);
select * from add_audit_log_action('generate_config', false);
select * from add_audit_log_action('get', false);
select * from add_audit_log_action('get_access_pif', false);
select * from add_audit_log_action('get_actions_after_crash', false);
select * from add_audit_log_action('get_actions_after_reboot', false);
select * from add_audit_log_action('get_actions_after_shutdown', false);
select * from add_audit_log_action('get_address', false);
select * from add_audit_log_action('get_affinity', false);
select * from add_audit_log_action('get_after_apply_guidance', false);
select * from add_audit_log_action('get_alarm_config', false);
select * from add_audit_log_action('get_alerts', false);
select * from add_audit_log_action('get_all', false);
select * from add_audit_log_action('get_all_records', false);
select * from add_audit_log_action('get_all_records_where', false);
select * from add_audit_log_action('get_all_subject_identifiers', false);
select * from add_audit_log_action('get_allow_caching', false);
select * from add_audit_log_action('get_allowed_operations', false);
select * from add_audit_log_action('get_allowed_vbd_devices', false);
select * from add_audit_log_action('get_allowed_vif_devices', false);
select * from add_audit_log_action('get_api_version_major', false);
select * from add_audit_log_action('get_api_version_minor', false);
select * from add_audit_log_action('get_api_version_vendor', false);
select * from add_audit_log_action('get_api_version_vendor_implementation', false);
select * from add_audit_log_action('get_applied', false);
select * from add_audit_log_action('get_archive_frequency', false);
select * from add_audit_log_action('get_archive_last_run_time', false);
select * from add_audit_log_action('get_archive_schedule', false);
select * from add_audit_log_action('get_archive_target_config', false);
select * from add_audit_log_action('get_archive_target_type', false);
select * from add_audit_log_action('get_audit_log', false);
select * from add_audit_log_action('get_auth_user_name', false);
select * from add_audit_log_action('get_auth_user_sid', false);
select * from add_audit_log_action('get_backend', false);
select * from add_audit_log_action('get_backup_frequency', false);
select * from add_audit_log_action('get_backup_last_run_time', false);
select * from add_audit_log_action('get_backup_retention_value', false);
select * from add_audit_log_action('get_backup_schedule', false);
select * from add_audit_log_action('get_backup_type', false);
select * from add_audit_log_action('get_bios_strings', false);
select * from add_audit_log_action('get_blob', false);
select * from add_audit_log_action('get_blobs', false);
select * from add_audit_log_action('get_blocked_operations', false);
select * from add_audit_log_action('get_bond_master_of', false);
select * from add_audit_log_action('get_bond_slave_of', false);
select * from add_audit_log_action('get_boot_record', false);
select * from add_audit_log_action('get_bootable', false);
select * from add_audit_log_action('get_bridge', false);
select * from add_audit_log_action('get_by_name_label', false);
select * from add_audit_log_action('get_by_permission', false);
select * from add_audit_log_action('get_by_permission_name_label', false);
select * from add_audit_log_action('get_by_uuid', false);
select * from add_audit_log_action('get_capabilities', false);
select * from add_audit_log_action('get_carrier', false);
select * from add_audit_log_action('get_children', false);
select * from add_audit_log_action('get_config_sync', false);
select * from add_audit_log_action('get_configuration', false);
select * from add_audit_log_action('get_consoles', false);
select * from add_audit_log_action('get_content_type', false);
select * from add_audit_log_action('get_cooperative', false);
select * from add_audit_log_action('get_copyright', false);
select * from add_audit_log_action('get_cpu_configuration', false);
select * from add_audit_log_action('get_cpu_info', false);
select * from add_audit_log_action('get_crash_dump_sr', false);
select * from add_audit_log_action('get_crash_dumps', false);
select * from add_audit_log_action('get_crashdumps', false);
select * from add_audit_log_action('get_created', false);
select * from add_audit_log_action('get_current_id', false);
select * from add_audit_log_action('get_current_operations', false);
select * from add_audit_log_action('get_currently_attached', false);
select * from add_audit_log_action('get_data_sources', false);
select * from add_audit_log_action('get_default_sr', false);
select * from add_audit_log_action('get_device', false);
select * from add_audit_log_action('get_device_config', false);
select * from add_audit_log_action('get_device_id', false);
select * from add_audit_log_action('get_device_name', false);
select * from add_audit_log_action('get_diagnostic_timing_stats', false);
select * from add_audit_log_action('get_disallow_unplug', false);
select * from add_audit_log_action('get_disks', false);
select * from add_audit_log_action('get_dns', false);
select * from add_audit_log_action('get_domarch', false);
select * from add_audit_log_action('get_domid', false);
select * from add_audit_log_action('get_driver_filename', false);
select * from add_audit_log_action('get_duplex', false);
select * from add_audit_log_action('get_edition', false);
select * from add_audit_log_action('get_empty', false);
select * from add_audit_log_action('get_enabled', false);
select * from add_audit_log_action('get_error_info', false);
select * from add_audit_log_action('get_export', false);
select * from add_audit_log_action('get_export_metadata', false);
select * from add_audit_log_action('get_external_auth_configuration', false);
select * from add_audit_log_action('get_external_auth_service_name', false);
select * from add_audit_log_action('get_external_auth_type', false);
select * from add_audit_log_action('get_family', false);
select * from add_audit_log_action('get_features', false);
select * from add_audit_log_action('get_finished', false);
select * from add_audit_log_action('get_flags', false);
select * from add_audit_log_action('get_fullname', false);
select * from add_audit_log_action('get_gateway', false);
select * from add_audit_log_action('get_group_membership', false);
select * from add_audit_log_action('get_guest_metrics', false);
select * from add_audit_log_action('get_gui_config', false);
select * from add_audit_log_action('get_ha_allow_overcommit', false);
select * from add_audit_log_action('get_ha_always_run', false);
select * from add_audit_log_action('get_ha_configuration', false);
select * from add_audit_log_action('get_ha_enabled', false);
select * from add_audit_log_action('get_ha_host_failures_to_tolerate', false);
select * from add_audit_log_action('get_ha_network_peers', false);
select * from add_audit_log_action('get_ha_overcommitted', false);
select * from add_audit_log_action('get_ha_plan_exists_for', false);
select * from add_audit_log_action('get_ha_restart_priority', false);
select * from add_audit_log_action('get_ha_statefiles', false);
select * from add_audit_log_action('get_host', false);
select * from add_audit_log_action('get_host_backup', false);
select * from add_audit_log_action('get_host_cpus', false);
select * from add_audit_log_action('get_host_logs_download', false);
select * from add_audit_log_action('get_host_patches', false);
select * from add_audit_log_action('get_host_rrd', false);
select * from add_audit_log_action('get_hostname', false);
select * from add_audit_log_action('get_hvm_boot_params', false);
select * from add_audit_log_action('get_hvm_boot_policy', false);
select * from add_audit_log_action('get_hvm_shadow_multiplier', false);
select * from add_audit_log_action('get_install_time', false);
select * from add_audit_log_action('get_io_read_kbs', false);
select * from add_audit_log_action('get_io_write_kbs', false);
select * from add_audit_log_action('get_ip', false);
select * from add_audit_log_action('get_ip_configuration_mode', false);
select * from add_audit_log_action('get_is_a_snapshot', false);
select * from add_audit_log_action('get_is_a_template', false);
select * from add_audit_log_action('get_is_alarm_enabled', false);
select * from add_audit_log_action('get_is_archive_running', false);
select * from add_audit_log_action('get_is_backup_running', false);
select * from add_audit_log_action('get_is_control_domain', false);
select * from add_audit_log_action('get_is_local_superuser', false);
select * from add_audit_log_action('get_is_policy_enabled', false);
select * from add_audit_log_action('get_is_snapshot_from_vmpp', false);
select * from add_audit_log_action('get_last_active', false);
select * from add_audit_log_action('get_last_boot_cpu_flags', false);
select * from add_audit_log_action('get_last_booted_record', false);
select * from add_audit_log_action('get_last_updated', false);
select * from add_audit_log_action('get_license_params', false);
select * from add_audit_log_action('get_license_server', false);
select * from add_audit_log_action('get_live', false);
select * from add_audit_log_action('get_local_cache_enabled', false);
select * from add_audit_log_action('get_local_cache_sr', false);
select * from add_audit_log_action('get_location', false);
select * from add_audit_log_action('get_log', false);
select * from add_audit_log_action('get_logging', false);
select * from add_audit_log_action('get_mac', false);
select * from add_audit_log_action('get_mac_autogenerated', false);
select * from add_audit_log_action('get_managed', false);
select * from add_audit_log_action('get_management', false);
select * from add_audit_log_action('get_master', false);
select * from add_audit_log_action('get_memory', false);
select * from add_audit_log_action('get_memory_actual', false);
select * from add_audit_log_action('get_memory_dynamic_max', false);
select * from add_audit_log_action('get_memory_dynamic_min', false);
select * from add_audit_log_action('get_memory_free', false);
select * from add_audit_log_action('get_memory_overhead', false);
select * from add_audit_log_action('get_memory_static_max', false);
select * from add_audit_log_action('get_memory_static_min', false);
select * from add_audit_log_action('get_memory_target', false);
select * from add_audit_log_action('get_memory_total', false);
select * from add_audit_log_action('get_message_rss_feed', false);
select * from add_audit_log_action('get_metrics', false);
select * from add_audit_log_action('get_mime_type', false);
select * from add_audit_log_action('get_missing', false);
select * from add_audit_log_action('get_mode', false);
select * from add_audit_log_action('get_model', false);
select * from add_audit_log_action('get_modelname', false);
select * from add_audit_log_action('get_mtu', false);
select * from add_audit_log_action('get_name_description', false);
select * from add_audit_log_action('get_name_label', false);
select * from add_audit_log_action('get_netmask', false);
select * from add_audit_log_action('get_network', false);
select * from add_audit_log_action('get_networks', false);
select * from add_audit_log_action('get_number', false);
select * from add_audit_log_action('get_on_boot', false);
select * from add_audit_log_action('get_os_version', false);
select * from add_audit_log_action('get_other', false);
select * from add_audit_log_action('get_other_config', false);
select * from add_audit_log_action('get_parent', false);
select * from add_audit_log_action('get_patches', false);
select * from add_audit_log_action('get_pbds', false);
select * from add_audit_log_action('get_pci_bus', false);
select * from add_audit_log_action('get_pci_bus_path', false);
select * from add_audit_log_action('get_permissions', false);
select * from add_audit_log_action('get_permissions_name_label', false);
select * from add_audit_log_action('get_physical', false);
select * from add_audit_log_action('get_physical_size', false);
select * from add_audit_log_action('get_physical_utilisation', false);
select * from add_audit_log_action('get_pifs', false);
select * from add_audit_log_action('get_platform', false);
select * from add_audit_log_action('get_pool', false);
select * from add_audit_log_action('get_pool_applied', false);
select * from add_audit_log_action('get_pool_patch', false);
select * from add_audit_log_action('get_pool_patch_download', false);
select * from add_audit_log_action('get_pool_xml_db_sync', false);
select * from add_audit_log_action('get_possible_hosts', false);
select * from add_audit_log_action('get_power_on_config', false);
select * from add_audit_log_action('get_power_on_mode', false);
select * from add_audit_log_action('get_power_state', false);
select * from add_audit_log_action('get_progress', false);
select * from add_audit_log_action('get_protection_policy', false);
select * from add_audit_log_action('get_protocol', false);
select * from add_audit_log_action('get_pv_args', false);
select * from add_audit_log_action('get_pv_bootloader', false);
select * from add_audit_log_action('get_pv_bootloader_args', false);
select * from add_audit_log_action('get_pv_drivers_up_to_date', false);
select * from add_audit_log_action('get_pv_drivers_version', false);
select * from add_audit_log_action('get_pv_kernel', false);
select * from add_audit_log_action('get_pv_legacy_args', false);
select * from add_audit_log_action('get_pv_ramdisk', false);
select * from add_audit_log_action('get_qos_algorithm_params', false);
select * from add_audit_log_action('get_qos_algorithm_type', false);
select * from add_audit_log_action('get_qos_supported_algorithms', false);
select * from add_audit_log_action('get_rbac_permissions', false);
select * from add_audit_log_action('get_read_only', false);
select * from add_audit_log_action('get_recent_alerts', false);
select * from add_audit_log_action('get_recommendations', false);
select * from add_audit_log_action('get_record', false);
select * from add_audit_log_action('get_redo_log_enabled', false);
select * from add_audit_log_action('get_redo_log_vdi', false);
select * from add_audit_log_action('get_required_api_version', false);
select * from add_audit_log_action('get_resident_on', false);
select * from add_audit_log_action('get_resident_vms', false);
select * from add_audit_log_action('get_restrictions', false);
select * from add_audit_log_action('get_result', false);
select * from add_audit_log_action('get_roles', false);
select * from add_audit_log_action('get_root', false);
select * from add_audit_log_action('get_rrd_updates', false);
select * from add_audit_log_action('get_runtime_properties', false);
select * from add_audit_log_action('get_sched_policy', false);
select * from add_audit_log_action('get_server_certificate', false);
select * from add_audit_log_action('get_server_localtime', false);
select * from add_audit_log_action('get_servertime', false);
select * from add_audit_log_action('get_sharable', false);
select * from add_audit_log_action('get_shared', false);
select * from add_audit_log_action('get_short_name', false);
select * from add_audit_log_action('get_since', false);
select * from add_audit_log_action('get_size', false);
select * from add_audit_log_action('get_slaves', false);
select * from add_audit_log_action('get_sm_config', false);
select * from add_audit_log_action('get_snapshot_info', false);
select * from add_audit_log_action('get_snapshot_metadata', false);
select * from add_audit_log_action('get_snapshot_of', false);
select * from add_audit_log_action('get_snapshot_time', false);
select * from add_audit_log_action('get_snapshots', false);
select * from add_audit_log_action('get_software_version', false);
select * from add_audit_log_action('get_speed', false);
select * from add_audit_log_action('get_sr', false);
select * from add_audit_log_action('get_start_time', false);
select * from add_audit_log_action('get_state', false);
select * from add_audit_log_action('get_status', false);
select * from add_audit_log_action('get_status_code', false);
select * from add_audit_log_action('get_status_detail', false);
select * from add_audit_log_action('get_stepping', false);
select * from add_audit_log_action('get_storage_lock', false);
select * from add_audit_log_action('get_subject', false);
select * from add_audit_log_action('get_subject_identifier', false);
select * from add_audit_log_action('get_subject_information_from_identifier', false);
select * from add_audit_log_action('get_subroles', false);
select * from add_audit_log_action('get_subtask_of', false);
select * from add_audit_log_action('get_subtasks', false);
select * from add_audit_log_action('get_supported_bootloaders', false);
select * from add_audit_log_action('get_supported_types', false);
select * from add_audit_log_action('get_suspend_image_sr', false);
select * from add_audit_log_action('get_suspend_vdi', false);
select * from add_audit_log_action('get_system_status', false);
select * from add_audit_log_action('get_system_status_capabilities', false);
select * from add_audit_log_action('get_tag', false);
select * from add_audit_log_action('get_tagged_pif', false);
select * from add_audit_log_action('get_tags', false);
select * from add_audit_log_action('get_tasks', false);
select * from add_audit_log_action('get_this_host', false);
select * from add_audit_log_action('get_this_user', false);
select * from add_audit_log_action('get_timestamp', false);
select * from add_audit_log_action('get_timestamp_applied', false);
select * from add_audit_log_action('get_transport_pif', false);
select * from add_audit_log_action('get_transportable_snapshot_id', false);
select * from add_audit_log_action('get_tunnel_access_pif_of', false);
select * from add_audit_log_action('get_tunnel_transport_pif_of', false);
select * from add_audit_log_action('get_type', false);
select * from add_audit_log_action('get_uncooperative_domains', false);
select * from add_audit_log_action('get_uncooperative_resident_vms', false);
select * from add_audit_log_action('get_unpluggable', false);
select * from add_audit_log_action('get_untagged_pif', false);
select * from add_audit_log_action('get_user_version', false);
select * from add_audit_log_action('get_userdevice', false);
select * from add_audit_log_action('get_utilisation', false);
select * from add_audit_log_action('get_uuid', false);
select * from add_audit_log_action('get_validation_time', false);
select * from add_audit_log_action('get_value', false);
select * from add_audit_log_action('get_vbds', false);
select * from add_audit_log_action('get_vcpus_at_startup', false);
select * from add_audit_log_action('get_vcpus_cpu', false);
select * from add_audit_log_action('get_vcpus_flags', false);
select * from add_audit_log_action('get_vcpus_max', false);
select * from add_audit_log_action('get_vcpus_number', false);
select * from add_audit_log_action('get_vcpus_params', false);
select * from add_audit_log_action('get_vcpus_utilisation', false);
select * from add_audit_log_action('get_vdi', false);
select * from add_audit_log_action('get_vdis', false);
select * from add_audit_log_action('get_vendor', false);
select * from add_audit_log_action('get_vendor_id', false);
select * from add_audit_log_action('get_vendor_name', false);
select * from add_audit_log_action('get_version', false);
select * from add_audit_log_action('get_vifs', false);
select * from add_audit_log_action('get_virtual_allocation', false);
select * from add_audit_log_action('get_virtual_size', false);
select * from add_audit_log_action('get_vlan', false);
select * from add_audit_log_action('get_vlan_master_of', false);
select * from add_audit_log_action('get_vlan_slave_of', false);
select * from add_audit_log_action('get_vm', false);
select * from add_audit_log_action('get_vm_connect', false);
select * from add_audit_log_action('get_vm_rrd', false);
select * from add_audit_log_action('get_vms', false);
select * from add_audit_log_action('get_vms_which_prevent_evacuation', false);
select * from add_audit_log_action('get_vncsnapshot', false);
select * from add_audit_log_action('get_vncsnapshot/host_console', false);
select * from add_audit_log_action('get_vswitch_controller', false);
select * from add_audit_log_action('get_vtpms', false);
select * from add_audit_log_action('get_wlb_diagnostics', false);
select * from add_audit_log_action('get_wlb_enabled', false);
select * from add_audit_log_action('get_wlb_report', false);
select * from add_audit_log_action('get_wlb_url', false);
select * from add_audit_log_action('get_wlb_username', false);
select * from add_audit_log_action('get_wlb_verify_cert', false);
select * from add_audit_log_action('get_xenstore_data', false);
select * from add_audit_log_action('ha_compute_hypothetical_max_host_failures_to_tolerate', false);
select * from add_audit_log_action('ha_compute_max_host_failures_to_tolerate', false);
select * from add_audit_log_action('ha_compute_vm_failover_plan', false);
select * from add_audit_log_action('ha_disable_failover_decisions', false);
select * from add_audit_log_action('ha_disarm_fencing', false);
select * from add_audit_log_action('ha_failover_plan_exists', false);
select * from add_audit_log_action('ha_join_liveset', false);
select * from add_audit_log_action('ha_prevent_restarts_for', false);
select * from add_audit_log_action('ha_release_resources', false);
select * from add_audit_log_action('ha_schedule_plan_recomputation', false);
select * from add_audit_log_action('ha_stop_daemon', false);
select * from add_audit_log_action('ha_wait_for_shutdown_via_statefile', false);
select * from add_audit_log_action('ha_xapi_healthcheck', false);
select * from add_audit_log_action('hard_reboot_internal', false);
select * from add_audit_log_action('hello', false);
select * from add_audit_log_action('initial_auth', false);
select * from add_audit_log_action('initialize_wlb', false);
select * from add_audit_log_action('insert', false);
select * from add_audit_log_action('introduce', false);
select * from add_audit_log_action('is_in_emergency_mode', false);
select * from add_audit_log_action('is_slave', false);
select * from add_audit_log_action('license_apply', false);
select * from add_audit_log_action('list_methods', false);
select * from add_audit_log_action('local_assert_healthy', false);
select * from add_audit_log_action('local_logout', false);
select * from add_audit_log_action('local_management_reconfigure', false);
select * from add_audit_log_action('login_with_password', false);
select * from add_audit_log_action('logout', false);
select * from add_audit_log_action('logout_subject_identifier', false);
select * from add_audit_log_action('lvhd_stop_using_these_vdis_and_call_script', false);
select * from add_audit_log_action('make', false);
select * from add_audit_log_action('management_disable', false);
select * from add_audit_log_action('management_reconfigure', false);
select * from add_audit_log_action('maximise_memory', false);
select * from add_audit_log_action('next', false);
select * from add_audit_log_action('notify', false);
select * from add_audit_log_action('pause', false);
select * from add_audit_log_action('plug', false);
select * from add_audit_log_action('pool_apply', false);
select * from add_audit_log_action('pool_introduce', false);
select * from add_audit_log_action('post_cli', false);
select * from add_audit_log_action('post_json', false);
select * from add_audit_log_action('post_remote_db_access', false);
select * from add_audit_log_action('post_remote_stats', false);
select * from add_audit_log_action('post_root', false);
select * from add_audit_log_action('power_on', false);
select * from add_audit_log_action('power_state_reset', false);
select * from add_audit_log_action('precheck', false);
select * from add_audit_log_action('preconfigure_ha', false);
select * from add_audit_log_action('probe', false);
select * from add_audit_log_action('propose_new_master', false);
select * from add_audit_log_action('protect_now', false);
select * from add_audit_log_action('provision', false);
select * from add_audit_log_action('put_blob', false);
select * from add_audit_log_action('put_host_restore', false);
select * from add_audit_log_action('put_import', false);
select * from add_audit_log_action('put_import_metadata', false);
select * from add_audit_log_action('put_import_raw_vdi', false);
select * from add_audit_log_action('put_oem_patch_stream', false);
select * from add_audit_log_action('put_pool_patch_upload', false);
select * from add_audit_log_action('put_pool_xml_db_sync', false);
select * from add_audit_log_action('put_rrd', false);
select * from add_audit_log_action('put_vm_connect', false);
select * from add_audit_log_action('query_data_source', false);
select * from add_audit_log_action('reconfigure_ip', false);
select * from add_audit_log_action('record_data_source', false);
select * from add_audit_log_action('recover_slaves', false);
select * from add_audit_log_action('refresh_pack_info', false);
select * from add_audit_log_action('register', false);
select * from add_audit_log_action('remove_from_alarm_config', false);
select * from add_audit_log_action('remove_from_archive_schedule', false);
select * from add_audit_log_action('remove_from_archive_target_config', false);
select * from add_audit_log_action('remove_from_backup_schedule', false);
select * from add_audit_log_action('remove_from_blocked_operations', false);
select * from add_audit_log_action('remove_from_gui_config', false);
select * from add_audit_log_action('remove_from_hvm_boot_params', false);
select * from add_audit_log_action('remove_from_license_server', false);
select * from add_audit_log_action('remove_from_logging', false);
select * from add_audit_log_action('remove_from_other_config', false);
select * from add_audit_log_action('remove_from_platform', false);
select * from add_audit_log_action('remove_from_qos_algorithm_params', false);
select * from add_audit_log_action('remove_from_roles', false);
select * from add_audit_log_action('remove_from_sm_config', false);
select * from add_audit_log_action('remove_from_status', false);
select * from add_audit_log_action('remove_from_vcpus_params', false);
select * from add_audit_log_action('remove_from_xenstore_data', false);
select * from add_audit_log_action('remove_tags', false);
select * from add_audit_log_action('request_backup', false);
select * from add_audit_log_action('request_config_file_sync', false);
select * from add_audit_log_action('reset_cpu_features', false);
select * from add_audit_log_action('reset_networking', false);
select * from add_audit_log_action('resize', false);
select * from add_audit_log_action('resize_online', false);
select * from add_audit_log_action('restart_agent', false);
select * from add_audit_log_action('resume', false);
select * from add_audit_log_action('resume_on', false);
select * from add_audit_log_action('retrieve_wlb_configuration', false);
select * from add_audit_log_action('retrieve_wlb_evacuate_recommendations', false);
select * from add_audit_log_action('retrieve_wlb_recommendations', false);
select * from add_audit_log_action('revert', false);
select * from add_audit_log_action('s3_resume', false);
select * from add_audit_log_action('s3_suspend', false);
select * from add_audit_log_action('scan', false);
select * from add_audit_log_action('scan_bios', false);
select * from add_audit_log_action('send_debug_keys', false);
select * from add_audit_log_action('send_sysrq', false);
select * from add_audit_log_action('send_test_post', false);
select * from add_audit_log_action('send_trigger', false);
select * from add_audit_log_action('send_wlb_configuration', false);
select * from add_audit_log_action('set_actions_after_crash', false);
select * from add_audit_log_action('set_actions_after_reboot', false);
select * from add_audit_log_action('set_actions_after_shutdown', false);
select * from add_audit_log_action('set_affinity', false);
select * from add_audit_log_action('set_alarm_config', false);
select * from add_audit_log_action('set_allow_caching', false);
select * from add_audit_log_action('set_archive_frequency', false);
select * from add_audit_log_action('set_archive_last_run_time', false);
select * from add_audit_log_action('set_archive_schedule', false);
select * from add_audit_log_action('set_archive_target_config', false);
select * from add_audit_log_action('set_archive_target_type', false);
select * from add_audit_log_action('set_backup_frequency', false);
select * from add_audit_log_action('set_backup_last_run_time', false);
select * from add_audit_log_action('set_backup_retention_value', false);
select * from add_audit_log_action('set_backup_schedule', false);
select * from add_audit_log_action('set_backup_type', false);
select * from add_audit_log_action('set_blocked_operations', false);
select * from add_audit_log_action('set_bootable', false);
select * from add_audit_log_action('set_cpu_features', false);
select * from add_audit_log_action('set_crash_dump_sr', false);
select * from add_audit_log_action('set_default_sr', false);
select * from add_audit_log_action('set_device_config', false);
select * from add_audit_log_action('set_disallow_unplug', false);
select * from add_audit_log_action('set_fullname', false);
select * from add_audit_log_action('set_gui_config', false);
select * from add_audit_log_action('set_ha_allow_overcommit', false);
select * from add_audit_log_action('set_ha_always_run', false);
select * from add_audit_log_action('set_ha_host_failures_to_tolerate', false);
select * from add_audit_log_action('set_ha_restart_priority', false);
select * from add_audit_log_action('set_hostname', false);
select * from add_audit_log_action('set_hostname_live', false);
select * from add_audit_log_action('set_hvm_boot_params', false);
select * from add_audit_log_action('set_hvm_boot_policy', false);
select * from add_audit_log_action('set_hvm_shadow_multiplier', false);
select * from add_audit_log_action('set_is_a_template', false);
select * from add_audit_log_action('set_is_alarm_enabled', false);
select * from add_audit_log_action('set_is_archive_running', false);
select * from add_audit_log_action('set_is_backup_running', false);
select * from add_audit_log_action('set_is_policy_enabled', false);
select * from add_audit_log_action('set_license_params', false);
select * from add_audit_log_action('set_license_server', false);
select * from add_audit_log_action('set_localdb_key', false);
select * from add_audit_log_action('set_logging', false);
select * from add_audit_log_action('set_managed', false);
select * from add_audit_log_action('set_memory_dynamic_max', false);
select * from add_audit_log_action('set_memory_dynamic_min', false);
select * from add_audit_log_action('set_memory_dynamic_range', false);
select * from add_audit_log_action('set_memory_limits', false);
select * from add_audit_log_action('set_memory_static_max', false);
select * from add_audit_log_action('set_memory_static_min', false);
select * from add_audit_log_action('set_memory_static_range', false);
select * from add_audit_log_action('set_memory_target_live', false);
select * from add_audit_log_action('set_missing', false);
select * from add_audit_log_action('set_mode', false);
select * from add_audit_log_action('set_mtu', false);
select * from add_audit_log_action('set_name_description', false);
select * from add_audit_log_action('set_name_label', false);
select * from add_audit_log_action('set_on_boot', false);
select * from add_audit_log_action('set_other_config', false);
select * from add_audit_log_action('set_pci_bus', false);
select * from add_audit_log_action('set_physical_size', false);
select * from add_audit_log_action('set_physical_utilisation', false);
select * from add_audit_log_action('set_platform', false);
select * from add_audit_log_action('set_power_on_mode', false);
select * from add_audit_log_action('set_protection_policy', false);
select * from add_audit_log_action('set_pv_args', false);
select * from add_audit_log_action('set_pv_bootloader', false);
select * from add_audit_log_action('set_pv_bootloader_args', false);
select * from add_audit_log_action('set_pv_kernel', false);
select * from add_audit_log_action('set_pv_legacy_args', false);
select * from add_audit_log_action('set_pv_ramdisk', false);
select * from add_audit_log_action('set_qos_algorithm_params', false);
select * from add_audit_log_action('set_qos_algorithm_type', false);
select * from add_audit_log_action('set_read_only', false);
select * from add_audit_log_action('set_recommendations', false);
select * from add_audit_log_action('set_shadow_multiplier_live', false);
select * from add_audit_log_action('set_sharable', false);
select * from add_audit_log_action('set_shared', false);
select * from add_audit_log_action('set_sm_config', false);
select * from add_audit_log_action('set_status', false);
select * from add_audit_log_action('set_suspend_image_sr', false);
select * from add_audit_log_action('set_tags', false);
select * from add_audit_log_action('set_type', false);
select * from add_audit_log_action('set_unpluggable', false);
select * from add_audit_log_action('set_user_version', false);
select * from add_audit_log_action('set_userdevice', false);
select * from add_audit_log_action('set_value', false);
select * from add_audit_log_action('set_vcpus_at_startup', false);
select * from add_audit_log_action('set_vcpus_max', false);
select * from add_audit_log_action('set_vcpus_number_live', false);
select * from add_audit_log_action('set_vcpus_params', false);
select * from add_audit_log_action('set_virtual_allocation', false);
select * from add_audit_log_action('set_virtual_size', false);
select * from add_audit_log_action('set_vswitch_controller', false);
select * from add_audit_log_action('set_wlb_enabled', false);
select * from add_audit_log_action('set_wlb_verify_cert', false);
select * from add_audit_log_action('set_xenstore_data', false);
select * from add_audit_log_action('shutdown_agent', false);
select * from add_audit_log_action('signal_networking_change', false);
select * from add_audit_log_action('slave_local_login', false);
select * from add_audit_log_action('slave_local_login_with_password', false);
select * from add_audit_log_action('slave_login', false);
select * from add_audit_log_action('slave_network_report', false);
select * from add_audit_log_action('sync_data', false);
select * from add_audit_log_action('sync_database', false);
select * from add_audit_log_action('syslog_reconfigure', false);
select * from add_audit_log_action('test_archive_target', false);
select * from add_audit_log_action('tickle_heartbeat', false);
select * from add_audit_log_action('unpause', false);
select * from add_audit_log_action('unplug', false);
select * from add_audit_log_action('unplug_force', false);
select * from add_audit_log_action('unplug_force_no_safety_check', false);
select * from add_audit_log_action('unregister', false);
select * from add_audit_log_action('update', false);
select * from add_audit_log_action('update_allowed_operations', false);
select * from add_audit_log_action('update_master', false);
select * from add_audit_log_action('update_pool_secret', false);
select * from add_audit_log_action('update_snapshot_metadata', false);
select * from add_audit_log_action('upload', false);
select * from add_audit_log_action('wait_memory_target_live', false);

-- Drop the temporary functions
DROP FUNCTION "WorkloadBalancing"."add_audit_log_object"
(  
  _name varchar(96),
  _enabled boolean,
  _description varchar(1024)
);
DROP FUNCTION "WorkloadBalancing"."add_audit_log_action"
(  
  _name varchar(96),
  _enabled boolean,
  _description varchar(1024)
);

-- Date utility functions
-- Rabin Karki
-- 3 Nov, 2010

-- Returns the timestamp at UTC
-- Parameters: None
-- Returns: 
--	Timestamp at UTC

DROP FUNCTION IF EXISTS "WorkloadBalancing".getutcdate() CASCADE;

create function "WorkloadBalancing".getutcdate()
returns timestamp as $$
begin
	return (select current_timestamp at time zone 'UTC');
end;
$$ language plpgsql;



-- Adds time interval from timestamp
-- Parameters:
--	timestamp: timestamp
--	diff: interval that is to be added to the timestamp. datatype is 'interval'. units should be 
--		second, minute, hour, day, week, month, year, decade, century, millennium
-- Examples:
-- select * from datetimeadd(current_timestamp::timestamp, '-1 hour')
-- select * from datetimeadd(getutcdate(), '30 minute')

DROP FUNCTION IF EXISTS "WorkloadBalancing".datetimeadd
(
	datetime timestamp,
	diff 	 interval
);

create function "WorkloadBalancing".datetimeadd(
	datetime timestamp,
	diff 	interval default '0 sec'
) returns timestamp as $$
declare
	_result timestamp;
begin
	_result := datetime + diff;
	return _result;
end;
$$ language plpgsql;



-- Returns integer value of date difference between timestamps
-- Parameters:
--	diffType	'year','month','day','hour','minute'
--	date1
--	date2
-- Examples:
-- 	select datetimediff('hour','1900-01-01 00:00:00',getutcdate())
--	select datetimediff('minute',getutcdate(), datetimeadd(getutcdate(),'1 day'))

DROP FUNCTION IF EXISTS "WorkloadBalancing".datetimediff 
(
	diffType 	varchar(15), 
	date1 		timestamp, 
	date2 		timestamp
);

CREATE FUNCTION "WorkloadBalancing".datetimediff 
(
	diffType 		varchar(15), 
	date1 			timestamp, 
	date2 			timestamp
) RETURNS integer AS $$
DECLARE
	diffInterval 		interval;
	diffDouble 	double precision := 0;
	diffInteger 		integer := 0;
BEGIN
	
	diffInterval := age(date2, date1);

	IF lower($1) = 'year' THEN
		diffDouble := date_part('year', diffInterval);
	ELSEIF lower($1) = 'month' THEN
		diffDouble := (date_part('year', diffInterval) * 12) + date_part('month', diffInterval);
	ELSEIF lower($1) = 'day' THEN
		diffDouble := date2 - date1;
	ELSEIF lower($1) = 'hour' THEN
		diffDouble := (date_part('day', date2 - date1) * 24) + (date_part('hour', date2 - date1));
	ELSEIF lower($1) = 'minute' THEN
		diffDouble := ((date_part('day', date2 - date1) * 24) * 60) + ((date_part('hour', date2 - date1)) * 60) + (date_part('minute', date2 - date1));
	END IF;

	diffInteger := cast(diffDouble as integer);

	RETURN diffInteger;
END;
$$ LANGUAGE plpgsql;



-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Create date: July 30, 2008
-- Updated:	Nov 26 2010
--		Converted to PostGreSQL
-- Description:	Populates the rs_hours table for use with reporting
-- Parameters:
--   None
-- Returns:
--   Nothing
-- ==========================================================================
CREATE OR REPLACE FUNCTION "WorkloadBalancing".core_data_rs_hours
(
	_label varchar(5)	
)	
RETURNS VOID AS $$
BEGIN

	if not exists(select * from rs_hours where hourlabel = _label) then
        	insert into rs_hours (hourlabel) values(_label);       		
	end if;

END;
$$ LANGUAGE plpgsql;

 
select * from "WorkloadBalancing".core_data_rs_hours('00:00');
select * from "WorkloadBalancing".core_data_rs_hours('01:00');
select * from "WorkloadBalancing".core_data_rs_hours('02:00');
select * from "WorkloadBalancing".core_data_rs_hours('03:00');
select * from "WorkloadBalancing".core_data_rs_hours('04:00');
select * from "WorkloadBalancing".core_data_rs_hours('05:00');
select * from "WorkloadBalancing".core_data_rs_hours('06:00');
select * from "WorkloadBalancing".core_data_rs_hours('07:00');
select * from "WorkloadBalancing".core_data_rs_hours('08:00');
select * from "WorkloadBalancing".core_data_rs_hours('09:00');
select * from "WorkloadBalancing".core_data_rs_hours('10:00');
select * from "WorkloadBalancing".core_data_rs_hours('11:00');
select * from "WorkloadBalancing".core_data_rs_hours('12:00');
select * from "WorkloadBalancing".core_data_rs_hours('13:00');
select * from "WorkloadBalancing".core_data_rs_hours('14:00');
select * from "WorkloadBalancing".core_data_rs_hours('15:00');
select * from "WorkloadBalancing".core_data_rs_hours('16:00');
select * from "WorkloadBalancing".core_data_rs_hours('17:00');
select * from "WorkloadBalancing".core_data_rs_hours('18:00');
select * from "WorkloadBalancing".core_data_rs_hours('19:00');
select * from "WorkloadBalancing".core_data_rs_hours('20:00');
select * from "WorkloadBalancing".core_data_rs_hours('21:00');
select * from "WorkloadBalancing".core_data_rs_hours('22:00');
select * from "WorkloadBalancing".core_data_rs_hours('23:00');

-- Drop the function
DROP FUNCTION "WorkloadBalancing".core_data_rs_hours("_label" varchar(5));

  
-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Create date: July 30, 2008
-- Updated:	Nov 26 2010
--		Converted to PostGreSQL
-- Description:	Populates the rs_calendar table for use with reporting
-- Parameters:
--   None
-- Returns:
--   Nothing
-- ==========================================================================
CREATE FUNCTION "WorkloadBalancing".core_data_add_calendar_dates
(
	_start_date	timestamp	
) 
RETURNS VOID AS $$
DECLARE
	_end_date	timestamp;
BEGIN

	create temporary table _hours
	( 
		hourid 		int,
		hourlabel 	varchar(5)
	)
	on commit drop;


	insert into _hours (hourid, hourlabel) values(0, '00:00');    
	insert into _hours (hourid, hourlabel) values(1, '01:00');    
	insert into _hours (hourid, hourlabel) values(2, '02:00');    
	insert into _hours (hourid, hourlabel) values(3, '03:00');    
	insert into _hours (hourid, hourlabel) values(4, '04:00');    
	insert into _hours (hourid, hourlabel) values(5, '05:00');    
	insert into _hours (hourid, hourlabel) values(6, '06:00');    
	insert into _hours (hourid, hourlabel) values(7, '07:00');    
	insert into _hours (hourid, hourlabel) values(8, '08:00');    
	insert into _hours (hourid, hourlabel) values(9, '09:00');    
	insert into _hours (hourid, hourlabel) values(10, '10:00');    
	insert into _hours (hourid, hourlabel) values(11, '11:00');    
	insert into _hours (hourid, hourlabel) values(12, '12:00');    
	insert into _hours (hourid, hourlabel) values(13, '13:00');    
	insert into _hours (hourid, hourlabel) values(14, '14:00');    
	insert into _hours (hourid, hourlabel) values(15, '15:00');    
	insert into _hours (hourid, hourlabel) values(16, '16:00');    
	insert into _hours (hourid, hourlabel) values(17, '17:00');    
	insert into _hours (hourid, hourlabel) values(18, '18:00');    
	insert into _hours (hourid, hourlabel) values(19, '19:00');    
	insert into _hours (hourid, hourlabel) values(20, '20:00');    
	insert into _hours (hourid, hourlabel) values(21, '21:00');    
	insert into _hours (hourid, hourlabel) values(22, '22:00');    
	insert into _hours (hourid, hourlabel) values(23, '23:00');

	_end_date := datetimeadd(getutcdate(), '10 year');


	if not exists (select * from rs_calendar) then

		while (_start_date < _end_date) loop

			insert into rs_calendar (dtperiod, hourid, hourlabel)
				select _start_date, h.hourid, h.hourlabel
				from _hours h;
                        
			_start_date := datetimeadd(_start_date, '1 day');

                end loop;


                update rs_calendar 
			set is_weekday = case when date_part('dow', dtperiod) in (0,6) then 0 else 1 end, 
                        year = date_part('year', dtperiod),  
                        quarter = case 
				when date_part('month', dtperiod) <= 3 then 1 
				when date_part('month', dtperiod) <= 6 then 2 
                                when date_part('month', dtperiod) <= 9 then 3 
                                else 4 end,  
                        month = date_part('month', dtperiod),  
                        day = date_part('day', dtperiod),  
                        day_of_week = date_part('dow', dtperiod) + 1,  
                        month_name = to_char(dtperiod, 'Month'),  
                        day_name = to_char(dtperiod, 'Day'),  
                        week_of_year = date_part('week', dtperiod);

        end if;

END;
$$ LANGUAGE plpgsql;

select * from "WorkloadBalancing"."core_data_add_calendar_dates"('2010-01-01 00:00:00.000');

-- Drop the function
DROP FUNCTION "WorkloadBalancing"."core_data_add_calendar_dates"("_start_date" timestamp);


-- This file stores the custom types that will be used in functions
drop type if exists host_runstate_counts cascade;
drop type if exists recommendations cascade;
drop type if exists host_free_cpus cascade;
drop type if exists host_free_memory cascade;
drop type if exists host_potential_free_memory cascade;
drop type if exists host_info cascade;
drop type if exists vms_info cascade;
drop type if exists pool_basic_info cascade;
drop type if exists name_id_pair cascade;
drop type if exists dc_status cascade;
drop type if exists host_metrics cascade;
drop type if exists host_pbd_metrics cascade;
drop type if exists vm_metrics cascade;
drop type if exists sched_task_details cascade;
drop type if exists action_param cascade;
drop type if exists bigint_tuple cascade;
drop type if exists recommendation_detail cascade;
drop type if exists array_table cascade;
drop type if exists rp_label_type cascade;
drop type if exists rp_pool_health_type cascade;
drop type if exists rp_pool_health_history_type cascade;
drop type if exists rp_host_health_history_type cascade;
drop type if exists rp_pool_optimization_history_type cascade;
drop type if exists rp_vm_movement_history_type cascade;
drop type if exists rp_vm_chargeback_history_type cascade;
drop type if exists rp_pool_audit_history_type cascade;
drop type if exists rp_vm_performance_history_type cascade;
drop type if exists rp_pool_optimization_performance_history_type cascade;


create type "WorkloadBalancing".host_runstate_counts as(hostid int, 
							poolid	int,
							full_contention_count bigint, 
							concurrency_hazard_count bigint, 
							partial_contention_count bigint, 
							fullrun_count bigint, 
							partial_run_count bigint, 
							blocked_count bigint);

create type "WorkloadBalancing".recommendations as(	
				event_id		int,
				recommendation_id	int,
				pool_id			int,
				severity		int,
				vm_id			int,
				vm_uuid			varchar(48),
				vm_name			varchar(256),
				move_to_host_id		int,
				move_to_host_uuid	varchar(48),
				move_to_host_name	varchar(256),
				move_from_host_id	int,
				move_from_host_uuid	varchar(48),
				move_from_host_name	varchar(256),
				reason_id		int,
				reason			varchar(20), 
				move_recommendation_time_stamp timestamp);


create type "WorkloadBalancing".host_free_cpus as (	hostid    int, 
							poolid	int,
							free_cpus bigint,
							vcpus	bigint);

create type "WorkloadBalancing".host_free_memory as (	hostid int, 
							poolid	int,
							free_mem bigint);
													 
create type "WorkloadBalancing".host_potential_free_memory as (	poolid int,
								hostid int, 
								potential_free_mem bigint,
								has_memory_ballooning boolean);
                       					   
create type "WorkloadBalancing".host_info as (  id                  int, 
                            name                varchar(256), 
                            uuid                varchar(48),
                            num_cpus            int, 
                            cpu_speed           int, 
                            num_pifs            int,
                            is_pool_master      boolean, 
                            avg_free_mem        bigint, 
                            avg_total_mem       bigint, 
                            avg_free_mem_con    bigint, 
                            avg_total_mem_con   bigint);

create type "WorkloadBalancing".vms_info as (   id                      int, 
                            name                    varchar(256), 
                            uuid                    varchar(48),
                            poolid                  int, 
                            description             varchar(1024), 
                            host_affinity           int, 
                            min_dynamic_memory      bigint,
                            max_dynamic_memory      bigint, 
                            min_static_memory       bigint, 
                            max_static_memory       bigint, 
                            target_memory           bigint,
                            memory_overhead         bigint, 
                            min_cpus                int, 
                            hv_memory_multiplier    numeric(7,2), 
                            required_memory         bigint,
                            is_control_domain       boolean, 
                            is_agile                boolean, 
                            drivers_up_to_date      boolean, 
                            hostid                  int, 
                            hostname                varchar(256), 
                            host_uuid               varchar(48), 
                            active                  boolean, 
                            status                  int, 
                            last_result             int, 
                            last_result_time        timestamp);
    
create type "WorkloadBalancing".pool_basic_info as (id                  int, 
                                hv_type             int, 
                                pool_master_1_addr  varchar(256), 
                                pool_master_1_port  int,
                                protocol            varchar(20), 
                                username            varchar(100), 
                                password            varchar(100));
    
create type "WorkloadBalancing".name_id_pair as (name   varchar(256), 
                             id     int);

create type "WorkloadBalancing".dc_status as (status    int, 
                          row_lock  bigint);

create type "WorkloadBalancing".host_metrics as (hostid         int,
							 poolid			int,
                             avg_free_mem   decimal(18,4),
                             avg_total_mem  decimal(18,4),
                             avg_cpu        decimal(9,8),
                             avg_read       decimal(18,4),
                             avg_write      decimal(18,4),
                             avg_load       decimal(9,3));

create type "WorkloadBalancing".host_pbd_metrics as (hostid         int,
							 poolid			int,
                             avg_disk_io_read 	decimal(18,4),
                             avg_disk_io_write 	decimal(18,4));							 
    
create type "WorkloadBalancing".vm_metrics as (vm_id                            int, 
                           avg_total_mem                    bigint,
                           avg_free_mem                     bigint,
                           avg_target_mem                   bigint,
                           avg_used_mem                     bigint,
                           avg_cpu                          decimal(9,8),
                           avg_block_read                   decimal(18,4),
                           avg_block_write                  decimal(18,4),
                           avg_net_read                     decimal(18,4),
                           avg_net_write                    decimal(18,4),
                           total_vbd_net_read               decimal(18,4),
                           total_vbd_net_write              decimal(18,4),
                           avg_runstate_full_contention     decimal(9,8),
                           avg_runstate_concurrency_hazard  decimal(9,8),
                           avg_runstate_partial_contention  decimal(9,8),
                           avg_runstate_fullrun             decimal(9,8),
                           avg_runstate_partial_run         decimal(9,8),
                           avg_runstate_blocked             decimal(9,8));

create type "WorkloadBalancing".sched_task_details as (taskid int, 
							poolid int, name varchar(50), 
							description varchar(255), 
							enabled boolean, 
							owner varchar(255), 
							last_run_result boolean, 
							last_touched_by varchar(128),
							last_touched timestamp, 
							trigger_type int, 
							days_of_week int, 
							execute_time timestamp, 
							enable_date timestamp, 
							disable_date timestamp, 
							last_run timestamp, 
							action_type int,
							action_name varchar(100), 
							action_description varchar(1024), 
							assembly varchar(255), 
							class varchar(255));

create type "WorkloadBalancing".action_param as(taskid int,
							param_name varchar(50), 
							param_value varchar(255));
							
create type "WorkloadBalancing".bigint_tuple as(id1 bigint, 
							id2 bigint);
							
create type "WorkloadBalancing".recommendation_detail as(
				event_id bigint,
				recommendation_id bigint,
				pool_id int,
				severity int,
				vm_id int,
				vm_uuid varchar(48),
				vm_name varchar(256),
				move_to_host_id int,
				move_to_host_uuid varchar(48),
				move_to_host_name varchar(256),
				move_from_host_id int,
				move_from_host_uuid varchar(48),
				move_from_host_name varchar(256),
				reason_id int,
				reason varchar(20), 
				move_recommendation_time_stamp timestamp,
				status int,
				end_time timestamp);	
				
create type "WorkloadBalancing".array_table as(fld varchar(500));					


create type "WorkloadBalancing".rp_label_type as
(
			name varchar(4000),
			description varchar(4000)
);

create type "WorkloadBalancing".rp_pool_health_type as
(
			hostid int, 
			name varchar(256), 
			uuid varchar(48), 
			start_time timestamp,
			host_cpu_threshold_critical numeric(9, 8),
			host_cpu_threshold_high numeric(9, 8),
			host_cpu_threshold_medium numeric(9, 8),
			host_cpu_threshold_low numeric(9, 8),
			host_memory_threshold_critical bigint,
			host_memory_threshold_high bigint,
			host_memory_threshold_medium bigint,
			host_memory_threshold_low bigint,
			host_net_read_threshold_critical numeric(18, 4),
			host_net_read_threshold_high numeric(18, 4),
			host_net_read_threshold_medium numeric(18, 4),
			host_net_read_threshold_low numeric(18, 4),
			host_net_write_threshold_critical numeric(18, 4),
			host_net_write_threshold_high numeric(18, 4),
			host_net_write_threshold_medium numeric(18, 4),
			host_net_write_threshold_low numeric(18, 4),
			cpu_threshold_percent varchar(256),
			memory_threshold_percent varchar(256),
			network_read_threshold_percent varchar(256),
			network_write_threshold_percent varchar(256),
			cpu_critical numeric(9, 8),
			cpu_high numeric(9, 8),
			cpu_medium numeric(9, 8),
			cpu_low numeric(9, 8),
			memory_critical bigint,
			memory_high bigint,
			memory_medium bigint,
			memory_low bigint,
			network_reads_critical numeric(18, 4),
			network_reads_high numeric(18, 4),
			network_reads_medium numeric(18, 4),
			network_reads_low numeric(18, 4),
			network_writes_critical numeric(18, 4),
			network_writes_high numeric(18, 4),
			network_writes_medium numeric(18, 4),
			network_writes_low numeric(18, 4)
);



create type "WorkloadBalancing".rp_pool_health_history_type as
(
			day timestamp, 
			hour varchar(5), 
			hostid int, 
			name varchar(256),
			start_time timestamp,
			host_cpu_threshold_critical numeric(9, 8),
			host_cpu_threshold_high numeric(9, 8),
			host_cpu_threshold_medium numeric(9, 8),
			host_cpu_threshold_low numeric(9, 8),
			host_memory_threshold_critical bigint,
			host_memory_threshold_high bigint,
			host_memory_threshold_medium bigint,
			host_memory_threshold_low bigint,
			host_net_read_threshold_critical numeric(18, 4),
			host_net_read_threshold_high numeric(18, 4),
			host_net_read_threshold_medium numeric(18, 4),
			host_net_read_threshold_low numeric(18, 4),
			host_net_write_threshold_critical numeric(18, 4),
			host_net_write_threshold_high numeric(18, 4),
			host_net_write_threshold_medium numeric(18, 4),
			host_net_write_threshold_low numeric(18, 4),
			avg_total_cpu numeric(9, 8),
			avg_free_mem bigint, 
			avg_total_pif_read_per_sec numeric(18, 4), 
			avg_total_pif_write_per_sec numeric(18, 4)
);


create type "WorkloadBalancing".rp_host_health_history_type as
(
			day timestamp, 
			hour varchar(5), 
			hostid int, 
			name varchar(256),
			start_time timestamp,
			host_cpu_threshold_critical numeric(9, 8),
			host_cpu_threshold_high numeric(9, 8),
			host_cpu_threshold_medium numeric(9, 8),
			host_cpu_threshold_low numeric(9, 8),
			host_memory_threshold_critical bigint,
			host_memory_threshold_high bigint,
			host_memory_threshold_medium bigint,
			host_memory_threshold_low bigint,
			host_net_read_threshold_critical numeric(18, 4),
			host_net_read_threshold_high numeric(18, 4),
			host_net_read_threshold_medium numeric(18, 4),
			host_net_read_threshold_low numeric(18, 4),
			host_net_write_threshold_critical numeric(18, 4),
			host_net_write_threshold_high numeric(18, 4),
			host_net_write_threshold_medium numeric(18, 4),
			host_net_write_threshold_low numeric(18, 4),
			avg_total_cpu numeric(9, 8),
			avg_free_mem bigint, 
			avg_total_pif_read_per_sec numeric(18, 4), 
			avg_total_pif_write_per_sec numeric(18, 4)
);


create type "WorkloadBalancing".rp_pool_optimization_history_type as
(
			day timestamp, 
			hour varchar(5), 
			id int, 
			vmid int,
			vmname varchar(256),
			from_hostid int,
			from_hostname varchar(256),
			to_hostid int,
			to_hostname varchar(256),
			recommendation_id int,
			reason int,
			status int,
			move_time timestamp
);


create type "WorkloadBalancing".rp_vm_movement_history_type as
(
			day timestamp, 
			hour varchar(5), 
			id int, 
			vmid int,
			vmname varchar(256),
			from_hostid int,
			from_hostname varchar(256),
			to_hostid int,
			to_hostname varchar(256),
			recommendation_id int,
			reason int,
			move_time timestamp
);


create type "WorkloadBalancing".rp_vm_chargeback_history_type as
(
			vm_id int,
			uuid varchar(48),
			vm_name varchar(256),
			uptime_minutes int,
			total_uptime_minutes int,
			cpu_count int,
			min_cpu_usage numeric(9, 8),
			max_cpu_usage numeric(9, 8),
			avg_cpu_usage numeric(9, 8),
			total_storage_allocation bigint,
			total_nic int,
			min_dynamic_memory bigint, 
			max_dynamic_memory bigint,
			current_total_memory bigint,
			avg_total_memory bigint,
			avg_vif_reads numeric(18, 4),
			avg_vif_writes numeric(18, 4),
			avg_total_vif numeric(18, 4),
			total_vif numeric(18, 4)
);


create type "WorkloadBalancing".rp_pool_audit_history_type as
(
			logtime timestamp,
			tstamp timestamp,
			id bigint,
			username varchar(96),
			usersid varchar(96),
			access boolean,
			eventobjectid int,
			eventobject varchar(96),
      eventobjectname varchar(1024),
			eventobjectuuid varchar(48),
			eventactionid int,
			eventaction varchar(96),
			succeeded boolean,
			error varchar(1024)
);


create type "WorkloadBalancing".rp_vm_performance_history_type as
(
			day timestamp, 
			hour varchar(5), 
			vmid int,
			name varchar(256),
			hostid int, 
			hostname varchar(256),
			avg_cpu numeric(9, 8),
			avg_free_mem bigint, 
			avg_vif_read numeric(18, 4), 
			avg_vif_write numeric(18, 4), 
			avg_vbd_read numeric(18, 4), 
			avg_vbd_write numeric(18, 4), 
			min_dynamic_memory bigint
);


create type "WorkloadBalancing".rp_pool_optimization_performance_history_type as
(
			day timestamp, 
			hour varchar(5), 
			hostid int, 
			name varchar(256),
			start_time timestamp,
			avg_total_cpu numeric(9, 8),
			avg_free_mem bigint, 
			avg_total_pif_read_per_sec numeric(18, 4), 
			avg_total_pif_write_per_sec numeric(18, 4), 
			optimized_moves int
);

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated:	Dec 14 2010
--		Converted to PostGreSQL
-- Description:	Populates the report_label table with label names
-- Parameters:
--	_label_name 		varchar(40),
--	_flags 			integer
-- Returns:
--   Nothing
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".dwm_data_add_report_label
(
	_label_name 		varchar(40)
);

CREATE FUNCTION "WorkloadBalancing".dwm_data_add_report_label
(
	_label_name 		varchar(40)
)
RETURNS VOID AS $$

BEGIN
	if not exists(	select * 
			from "WorkloadBalancing".report_label rl
    		 	where rl.label_name = _label_name
		     ) 
	then
		insert into "WorkloadBalancing".report_label(label_name)
		values (_label_name);
	end if;

END;
$$ LANGUAGE plpgsql;

-- These labels are included in every reporting services report
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_DATE');			
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_HOUR');			
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_HOST');	
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_POOL');	
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_FOOTER_GENERATED');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_FOOTER_SERVER');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_FOOTER_PAGE');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_FOOTER_LEFT');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_NO_DATA');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_MAX');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_MIN');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_POOL_HEALTH');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_CRIT_THRESH_PERCENT');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_HIGH_THRESH_PERCENT');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_MED_THRESH_PERCENT');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_LOW_THRESH_PERCENT');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_CPU_USAGE');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_MEMORY_USAGE');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_NETWORK_READS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_NETWORK_WRITES');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_HOST_HEALTH');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_POOL_HEALTH_HISTORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_CLICK_GROUPBY_DAY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_CLICK_GROUPBY_HOUR');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_CPU_USAGE');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_CPU_USAGE_PERCENT');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_CRIT_THRESH');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_HIGH_THRESH');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_MED_THRESH');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_LOW_THRESH');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_FREE_MEMORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_FREE_MEMORY_MB');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_NETWORK_READS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_BYTES_PER_SECOND');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_NETWORK_WRITES');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVERAGE_CPU_USAGE');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVERAGE_FREE_MEMORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVERAGE_NETWORK_READS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVERAGE_NETWORK_WRITES');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_HOST_HEALTH_HISTORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_POOL_OPT_PERF_HISTORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_OPTIMIZATION_EVENT');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_VM_MOTION_HISTORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_TOTAL_VM_MOVES');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_VM_NAME');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_OPTIMIZATION');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_REASON');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_FROM_HOST');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_TO_HOST');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_TIME');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_VM_PERF_HISTORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_VM');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_NETWORK_READS_BPS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_NETWORK_WRITES_BPS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_DISK_READS_BPS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_DISK_WRITES_BPS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVERAGE_MEMORY_USAGE');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVERAGE_NETWORK_ACTIVITY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVERAGE_DISK_ACTIVITY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_DISK_READS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_DISK_WRITES');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_BPS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_PERCENT');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_MB');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_POOL_AUDIT_HISTORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_HOST_NAME');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_USER_NAME');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_ACCESS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_CALL_TYPE');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_EVENT_OBJECT');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_EVENT_OBJECT_NAME');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_EVENT_OBJECT_UUID');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_EVENT_ACTION');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_SUCCEEDED');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_CPU');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_MEMORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_DISK');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_NETWORK');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_CONSOLIDATION');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_DISK_READS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_DISK_WRITES');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_LOAD_AVERAGE');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_POWER_ON');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_POWER_OFF');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_RUNSTATE');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_POOL_OPTIMIZATION_HISTORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_TOTAL_ACTIONS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_STATUS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AUTO_APPLIED');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_FAILED');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_MANUAL');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_YES');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_NO');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_VM_CHARGEBACK_HISTORY');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_VM_UPTIME_MIN');  
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_CPU_COUNT');  
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_MIN_CPU_USAGE_PERCENT');  
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_MAX_CPU_USAGE_PERCENT');  
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_CPU_USAGE_PERCENT_CB');  
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_TOTAL_STORAGE_GB');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_TOTAL_NIC');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_MIN_DYNAMIC_MEMORY_MB');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_MAX_DYNAMIC_MEMORY_MB');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_CURRENT_TOTAL_MEMORY_MB');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_TOTAL_MEMORY_MB');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_AVG_TOTAL_NETWORK_USAGE_BPS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_TOTAL_NETWORK_USAGE_BPS');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_METHOD');
select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_UNKNOWN');







-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated:	Dec 14 2010
--		Converted to PostGreSQL
-- Description:	Populates the report_label_locale table with label values
-- Parameters:
--	_name 				varchar(40),
--	_two_letter_code 		char(2),
--	_description 			varchar(255),
--	_long_description 		varchar(512) = null
-- Returns:
--   Nothing
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".dwm_data_add_update_report_label_value
(
	_name 				varchar(40),
	_two_letter_code 		char(2),
	_description 			varchar(255),
	_long_description 		varchar(512)
);

CREATE FUNCTION "WorkloadBalancing".dwm_data_add_update_report_label_value
(
	_name 				varchar(40),
	_two_letter_code 		char(2),
	_description 			varchar(255),
	_long_description 		varchar(512) = null
)
RETURNS VOID AS $$
DECLARE
	_rlid			integer;
BEGIN

	_rlid := (select rlid from report_label where label_name = _name);

	if (_rlid is null) then
		return;
	end if;

	if (_long_description is null) then
		_long_description := _description;
	end if;

	if exists(select * from report_label_locale where rlid = _rlid and two_letter_code = _two_letter_code) then

		update report_label_locale
			set description = _description,
			long_description = _long_description
		where rlid = _rlid 
		and two_letter_code = _two_letter_code;
	else

		insert into report_label_locale(rlid, two_letter_code, description, long_description)
		values (_rlid, _two_letter_code, _description, _long_description);

	end if;

END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated:	Dec 14 2010
--		Converted to PostGreSQL
-- Description:	Pass English labels to dwm_data_add_update_report_label_value
-- ==========================================================================
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DATE',				'en', 	'Date');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_HOUR',				'en', 	'Hour');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_HOST',				'en', 	'Host');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL',				'en', 	'Pool');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FOOTER_GENERATED',		'en', 	'Generated');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FOOTER_SERVER',			'en', 	'Server');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FOOTER_PAGE',			'en', 	'Page {0} of {1}');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FOOTER_LEFT',			'en', 	'{0} between {1} and {2}');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_NO_DATA',				'en', 	'There is currently insufficient data in the database to render this report.  Please try again later.');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MIN',				'en', 	'Min');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MAX',				'en', 	'Max');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG',				'en', 	'Avg');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL_HEALTH',			'en', 	'Pool Health');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_CRIT_THRESH_PERCENT',		'en', 	'Avg. Critical Threshold Percent');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_HIGH_THRESH_PERCENT',		'en', 	'Avg. High Threshold Percent');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_MED_THRESH_PERCENT',		'en', 	'Avg. Medium Threshold Percent');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_LOW_THRESH_PERCENT',		'en', 	'Avg. Low Threshold Percent');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CPU_USAGE',			'en', 	'CPU Usage');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MEMORY_USAGE',			'en', 	'Memory Usage');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_NETWORK_READS',			'en', 	'Network Reads');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_NETWORK_WRITES',			'en', 	'Network Writes');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_HOST_HEALTH',			'en', 	'Host Health');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL_HEALTH_HISTORY',		'en', 	'Pool Health History');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CLICK_GROUPBY_DAY',		'en', 	'Click to view report data grouped by day for the time period');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CLICK_GROUPBY_HOUR',		'en', 	'Click to view report data grouped by hour for the time period');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_CPU_USAGE',		'en', 	'Average CPU Usage');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_CPU_USAGE',			'en', 	'Avg CPU Usage');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_CPU_USAGE_PERCENT',		'en', 	'Avg CPU Usage (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_CRIT_THRESH',			'en', 	'Avg Critical Threshold');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_HIGH_THRESH',			'en', 	'Avg High Threshold');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_MED_THRESH',			'en', 	'Avg Medium Threshold');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_LOW_THRESH',			'en', 	'Avg Low Threshold');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_FREE_MEMORY',		'en', 	'Average Free Memory');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_FREE_MEMORY',			'en', 	'Avg Free Memory');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_FREE_MEMORY_MB',		'en', 	'Avg Free Memory (MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_NETWORK_READS',		'en', 	'Average Network Reads');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_NETWORK_READS',		'en', 	'Avg Network Reads');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_BYTES_PER_SECOND',		'en', 	'Avg Bytes per Second');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_NETWORK_WRITES',		'en', 	'Average Network Writes');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_NETWORK_WRITES',		'en', 	'Avg Network Writes');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_HOST_HEALTH_HISTORY',		'en', 	'Host Health History');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL_OPT_PERF_HISTORY',		'en', 	'Pool Optimization Performance History');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_OPTIMIZATION_EVENT',		'en', 	'Optimization Event');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM_MOTION_HISTORY',		'en', 	'Virtual Machine Motion History');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TOTAL_VM_MOVES',			'en', 	'Total VM Moves');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM_NAME',				'en', 	'VM Name');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_OPTIMIZATION',			'en', 	'Optimization');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_REASON',				'en', 	'Reason');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FROM_HOST',			'en', 	'From Host');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TO_HOST',				'en', 	'To Host');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TIME',				'en', 	'Time');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM_PERF_HISTORY',			'en', 	'Virtual Machine Performance History');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM',				'en', 	'VM');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_NETWORK_READS_BPS',		'en', 	'Average Network Reads (BPS)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_NETWORK_WRITES_BPS',		'en', 	'Average Network Writes (BPS)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DISK_READS_BPS',			'en', 	'Average Disk Reads (BPS)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DISK_WRITES_BPS',			'en', 	'Average Disk Writes (BPS)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_MEMORY_USAGE',		'en', 	'Average Memory Usage');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_NETWORK_ACTIVITY',	'en', 	'Average Network Activity');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_DISK_ACTIVITY',		'en', 	'Average Disk Activity');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_DISK_READS',			'en', 	'Avg Disk Reads');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_DISK_WRITES',			'en', 	'Avg Disk Writes');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_BPS',				'en', 	'(BPS)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_PERCENT',				'en', 	'(%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MB',				'en', 	'(MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL_AUDIT_HISTORY',		'en', 	'Pool Audit Trail');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_HOST_NAME',			'en', 	'Host Name');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_USER_NAME',			'en', 	'User Name');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_ACCESS',				'en', 	'Access');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CALL_TYPE',			'en', 	'Call Type');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_OBJECT',			'en', 	'Event Object');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_OBJECT_NAME',   'en',   'Object Name');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_OBJECT_UUID',		'en', 	'Object UUID');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_ACTION',			'en', 	'Event Action');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_SUCCEEDED',			'en', 	'Succeeded');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CPU',				'en', 	'CPU');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MEMORY',				'en', 	'Memory');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DISK',				'en', 	'Disk');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_NETWORK',				'en', 	'Network');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CONSOLIDATION',			'en', 	'Consolidation');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DISK_READS',			'en', 	'Disk Reads');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DISK_WRITES',			'en', 	'Disk Writes');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_LOAD_AVERAGE',			'en', 	'Load Average');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POWER_ON',			'en', 	'Power On');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POWER_OFF',			'en', 	'Power Off');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_RUNSTATE',			'en', 	'Runstate');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL_OPTIMIZATION_HISTORY', 	'en', 	'Pool Optimization History');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TOTAL_ACTIONS',			'en', 	'Total Actions');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_STATUS',				'en', 	'Status');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AUTO_APPLIED',			'en', 	'Auto Apply Success');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FAILED',				'en', 	'Auto Apply Failure');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MANUAL',				'en', 	'Manual');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_YES',				'en', 	'Yes');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_NO',				'en', 	'No');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM_CHARGEBACK_HISTORY',		'en', 	'Chargeback Utilization Analysis');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM_UPTIME_MIN',			'en', 	'VM Uptime (Minutes)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CPU_COUNT',			'en', 	'VCPU Allocation');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MIN_CPU_USAGE_PERCENT', 		'en', 	'Minimum CPU Usage (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MAX_CPU_USAGE_PERCENT', 		'en', 	'Maximum CPU Usage (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_CPU_USAGE_PERCENT_CB',	'en', 	'Average CPU Usage (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TOTAL_STORAGE_GB',		'en', 	'Total Storage Allocation (GB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TOTAL_NIC',			'en', 	'Virtual NIC Allocation');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MIN_DYNAMIC_MEMORY_MB',		'en', 	'Current Minimum Dynamic Memory (MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MAX_DYNAMIC_MEMORY_MB',		'en', 	'Current Maximum Dynamic Memory (MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CURRENT_TOTAL_MEMORY_MB',		'en', 	'Current Assigned Memory (MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_TOTAL_MEMORY_MB',		'en', 	'Average Assigned Memory (MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_TOTAL_NETWORK_USAGE_BPS', 	'en', 	'Average Network Usage (BPS)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TOTAL_NETWORK_USAGE_BPS', 	'en', 	'Total Network Usage (BPS)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_METHOD', 	'en', 	'Method');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_UNKNOWN',				'en', 	'Unknown');







-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated:	Dec 14 2010
--		Converted to PostGreSQL
-- Description:	Pass Japanese labels to dwm_data_add_update_report_label_value
-- ==========================================================================
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DATE',				'ja', 	'日付');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_HOUR',				'ja', 	'時間');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_HOST',				'ja', 	'ホスト');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL',				'ja', 	'プール');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FOOTER_GENERATED',		'ja', 	'生成');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FOOTER_SERVER',			'ja', 	'サーバー');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FOOTER_PAGE',			'ja', 	'{0}/{1} ページ');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FOOTER_LEFT',			'ja', 	'{1} ～ {2} の {0}');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_NO_DATA',				'ja', 	'現在、このレポートの生成に十分なデータがデータベースにありません。後で再試行してください。');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MIN',				'ja', 	'最小');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MAX',				'ja', 	'最大');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG',				'ja', 	'平均');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL_HEALTH',			'ja', 	'プール ヘルス');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_CRIT_THRESH_PERCENT',		'ja', 	'限界しきい値の平均 (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_HIGH_THRESH_PERCENT',		'ja', 	'高しきい値の平均 (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_MED_THRESH_PERCENT',		'ja', 	'中しきい値の平均 (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_LOW_THRESH_PERCENT',		'ja', 	'低しきい値の平均 (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CPU_USAGE',			'ja', 	'CPU 使用率');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MEMORY_USAGE',			'ja', 	'メモリ使用');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_NETWORK_READS',			'ja', 	'ネットワーク読み取り');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_NETWORK_WRITES',			'ja', 	'ネットワーク書き込み');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_HOST_HEALTH',			'ja', 	'ホスト ヘルス');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL_HEALTH_HISTORY',		'ja', 	'プール ヘルス履歴');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CLICK_GROUPBY_DAY',		'ja', 	'クリックして特定期間内の日別レポート データを表示します');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CLICK_GROUPBY_HOUR',		'ja', 	'クリックして特定期間内の時間別レポート データを表示します');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_CPU_USAGE',		'ja', 	'平均 CPU 使用率');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_CPU_USAGE',			'ja', 	'平均 CPU 使用率');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_CPU_USAGE_PERCENT',		'ja', 	'平均 CPU 使用率 (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_CRIT_THRESH',			'ja', 	'限界しきい値の平均');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_HIGH_THRESH',			'ja', 	'高しきい値の平均');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_MED_THRESH',			'ja', 	'中しきい値の平均');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_LOW_THRESH',			'ja', 	'低しきい値の平均');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_FREE_MEMORY',		'ja', 	'平均空きメモリ');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_FREE_MEMORY',			'ja', 	'平均空きメモリ');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_FREE_MEMORY_MB',		'ja', 	'平均空きメモリ (MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_NETWORK_READS',		'ja', 	'平均ネットワーク読み取り');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_NETWORK_READS',		'ja', 	'平均ネットワーク読み取り');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_BYTES_PER_SECOND',		'ja', 	'1 秒あたりの平均バイト数');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_NETWORK_WRITES',		'ja', 	'平均ネットワーク書き込み');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_NETWORK_WRITES',		'ja', 	'平均ネットワーク書き込み');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_HOST_HEALTH_HISTORY',		'ja', 	'ホスト ヘルス履歴');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL_OPT_PERF_HISTORY',		'ja', 	'プールの最適化パフォーマンス履歴');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_OPTIMIZATION_EVENT',		'ja', 	'最適化イベント');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM_MOTION_HISTORY',		'ja', 	'仮想マシン移動履歴');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TOTAL_VM_MOVES',			'ja', 	'VM 移動の総数');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM_NAME',				'ja', 	'VM 名');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_OPTIMIZATION',			'ja', 	'最適化');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_REASON',				'ja', 	'理由');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FROM_HOST',			'ja', 	'移動元');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TO_HOST',				'ja', 	'移動先');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TIME',				'ja', 	'時間');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM_PERF_HISTORY',			'ja', 	'仮想マシン パフォーマンス履歴');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM',				'ja', 	'VM');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_NETWORK_READS_BPS',		'ja', 	'平均ネットワーク読み取り (バイト/秒)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_NETWORK_WRITES_BPS',		'ja', 	'平均ネットワーク書き込み (バイト/秒)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DISK_READS_BPS',			'ja', 	'平均ディスク読み取り (バイト/秒)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DISK_WRITES_BPS',			'ja', 	'平均ディスク書き込み (バイト/秒)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_MEMORY_USAGE',		'ja', 	'平均メモリ使用');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_NETWORK_ACTIVITY',	'ja', 	'平均ネットワーク アクティビティ');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVERAGE_DISK_ACTIVITY',		'ja', 	'平均ディスク アクティビティ');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_DISK_READS',			'ja', 	'平均ディスク読み取り');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_DISK_WRITES',			'ja', 	'平均ディスク書き込み');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_BPS',				'ja', 	'(バイト/秒)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_PERCENT',				'ja', 	'(%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MB',				'ja', 	'(MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL_AUDIT_HISTORY',		'ja', 	'プール監査記録');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_HOST_NAME',			'ja', 	'ホスト名');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_USER_NAME',			'ja', 	'ユーザー名');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_ACCESS',				'ja', 	'アクセス');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CALL_TYPE',			'ja', 	'呼び出しの種類');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_OBJECT',			'ja', 	'イベント オブジェクト');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_OBJECT_NAME',   'ja',   'オブジェクト名');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_OBJECT_UUID',		'ja', 	'イベント UUIDは');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_ACTION',			'ja', 	'イベント アクション');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_SUCCEEDED',			'ja', 	'成功');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CPU',				'ja', 	'CPU');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MEMORY',				'ja', 	'メモリ');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DISK',				'ja', 	'ディスク');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_NETWORK',				'ja', 	'ネットワーク');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CONSOLIDATION',			'ja', 	'統合');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DISK_READS',			'ja', 	'ディスク読み取り');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_DISK_WRITES',			'ja', 	'ディスク書き込み');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_LOAD_AVERAGE',			'ja', 	'ロード平均');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POWER_ON',			'ja', 	'電源投入');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POWER_OFF',			'ja', 	'電源切断');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_RUNSTATE',			'ja', 	'実行状態');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_POOL_OPTIMIZATION_HISTORY', 	'ja', 	'プールの最適化履歴');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TOTAL_ACTIONS',			'ja', 	'アクション合計');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_STATUS',				'ja', 	'状態');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AUTO_APPLIED',			'ja', 	'自動');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_FAILED',				'ja', 	'失敗');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MANUAL',				'ja', 	'手動');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_YES',				'ja', 	'はい');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_NO',				'ja', 	'いいえ');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM_CHARGEBACK_HISTORY',		'ja', 	'チャージバック使用解析');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_VM_UPTIME_MIN',			'ja', 	'VM アップタイム (分)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CPU_COUNT',			'ja', 	'VCPU 割り当て');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MIN_CPU_USAGE_PERCENT', 		'ja', 	'最小 CPU 使用率 (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MAX_CPU_USAGE_PERCENT', 		'ja', 	'最大 CPU 使用率 (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_CPU_USAGE_PERCENT_CB',	'ja', 	'平均 CPU 使用率 (%)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TOTAL_STORAGE_GB',		'ja', 	'ストレージ割り当て合計 (GB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TOTAL_NIC',			'ja', 	'仮想 NIC 割り当て');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MIN_DYNAMIC_MEMORY_MB',		'ja', 	'現在の最小動的メモリ (MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_MAX_DYNAMIC_MEMORY_MB',		'ja', 	'現在の最大動的メモリ (MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_CURRENT_TOTAL_MEMORY_MB',		'ja', 	'現在のメモリ割り当て (MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_TOTAL_MEMORY_MB',		'ja', 	'平均メモリ割り当て (MB)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_AVG_TOTAL_NETWORK_USAGE_BPS', 	'ja', 	'平均ネットワーク使用 (バイト/秒)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_TOTAL_NETWORK_USAGE_BPS', 	'ja', 	'ネットワーク使用合計 (バイト/秒)');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_METHOD', 	'ja', 	'Method');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_UNKNOWN',				'ja', 	'不明');

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 18, 2011
-- Description:
--	 Obtains the label names & values for the specified report along with any
--	 common label names & values.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".rp_get_report_labels
( 
	_ReportName 		varchar(50),
	_LocaleCode 		char(2)
);

CREATE FUNCTION "WorkloadBalancing".rp_get_report_labels
( 
	_ReportName 		varchar(50),
	_LocaleCode 		char(2)
) 
RETURNS SETOF rp_label_type AS $$
DECLARE
	r 			rp_label_type%rowtype;
	_LabelNames 		varchar(4000) := null; 
	_LabelDescriptions 	varchar(4000) := null;
BEGIN

	-- Currently only english and japanese are supported
  if not exists(select * from report_label_locale where two_letter_code = lower(_LocaleCode))
  then
    _LocaleCode := 'en';
  end if;

  _LabelNames := (select array_to_string(array(select rl.label_name
      from report_label rl  
      join report_label_locale rll on (rll.rlid = rl.rlid and rll.two_letter_code = lower(_LocaleCode))  
      join report_label_map rlm on (rlm.rlid = rl.rlid)
      join report r on (r.repid = rlm.repid)
      where lower(r.report_file) = lower(_ReportName)
      order by rl.label_name),'|'));

  _LabelDescriptions := (select array_to_string(array(select rll.description
      from report_label rl  
      join report_label_locale rll on (rll.rlid = rl.rlid and rll.two_letter_code = lower(_LocaleCode))  
      join report_label_map rlm on (rlm.rlid = rl.rlid)
      join report r on (r.repid = rlm.repid)
      where lower(r.report_file) = lower(_ReportName)
      order by rl.label_name),'|'));
          
  for r in
    select _LabelNames as name, _LabelDescriptions as description
  loop
  return next r;
  end loop;

  RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: October 21, 2009
-- Modified for PosgtreSQL:	Deane Smith
-- On:				Jan 17, 2011
-- Description:	Updates a report's query_parameter and report_rdlc fields.
--              Used by the ReportUpload utility.
-- Parameters:
--     report_file - The internal name of the report
--     report_proc - The stored procedure used to populate the report
--     report_path - The physical path tot he report on the WLB server
--	   query_parameters - A comma-seperated list of query parameters required by the report
--     report_rdlc - the "RDLC" XML describing the report
--     localized_report_names - A comma separated list of localized report names
--          ** each report name is in the format [two letter code]|[report name]
--     report_labels - A comma separated list of label codes used in the report

-- Modified by: Barbara Li
-- Modified date: February 25, 2010
--     added: report_parameters
--	   report_parameters - A comma-seperated list of report parameters required by the report
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".report_upload_report
(
	_report_file 			varchar(255),
	_report_proc 			varchar(100),
	_report_path 			varchar(2048),
	_query_parameters 		varchar(2048),
	_report_parameters 		varchar (2048),
	_report_rdlc 			text,
	_report_name_label 		varchar(510),
	_report_labels 			varchar(4000)
);

create function "WorkloadBalancing".report_upload_report
(
	_report_file 			varchar(255),
	_report_proc 			varchar(100),
	_report_path 			varchar(2048),
	_query_parameters 		varchar(2048),
	_report_parameters 		varchar (2048),
	_report_rdlc 			text,
	_report_name_label 		varchar(510),
	_report_labels 			varchar(4000)
) 
RETURNS void AS
$$
declare _report_id int := null;
BEGIN

	if exists(select * from report where report_file = _report_file)
	then
	
		select repid into _report_id from report where report_file = _report_file;
		
		update report
		set report_path = _report_path,
			query_parameters = _query_parameters,
			report_parameters = _report_parameters,
			report_rdlc = _report_rdlc 
		where repid = _report_id;
	else
		insert into report 
		(
			report_file, 
			report_type,
	                report_proc,
	                report_path,
	                pid,
	                private,
	                custom,
	                req_features,
	                query_parameters,
	                report_parameters,
	                report_rdlc
		)
		values 
		(
			_report_file,
	                0,
	                _report_proc,
	                _report_path,
	                NULL,
	                0,
	                0,
	                0,
	                _query_parameters,
	                _report_parameters,
	                _report_rdlc
		)
		returning repid into _report_id;

	end if;

	-- Clean out existing labels
	delete from report_label_map where repid = _report_id;

	-- Add the supplied labels to the report label map
	insert into report_label_map (repid, rlid)
		select _report_id as repid, report_label.rlid
		from udf_core_array_to_table(_report_labels, ',') as report_labels
		join report_label on report_labels.fld = report_label.label_name;

	-- Clean out the existing report names
	delete from report_locale where repid = _report_id;


	-- Add the new report name(s)
	insert into report_locale (repid, two_letter_code, report_name_localized, report_desc_localized)
		select _report_id, rll.two_letter_code as two_letter_code, 
		rll.description as report_name_localized, '' as report_desc_localized	
		from report_label_locale rll
		join report_label rl on (rll.rlid = rl.rlid)
		where rl.label_name = _report_name_label;


END;
$$
LANGUAGE 'plpgsql';

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: October 21, 2009
-- Modified for PosgtreSQL:	Deane Smith
-- On:				Jan 17, 2011
-- Description:	Used to load the WlbReports collection object.
-- Returns:
--     Result set #1: Base data for each report
--     Result set #2: Localized report names for each report
--     Result set #3: Label names for each report
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".report_load_reports();

create function "WorkloadBalancing".report_load_reports
() 
RETURNS SETOF refcursor AS $$
DECLARE
	_ref_report 			refcursor;
	_ref_report_localized 		refcursor;
	_ref_report_labels 		refcursor;
BEGIN


	-- first result set is the base report data
	open _ref_report for
		select * from report;
	return next _ref_report;
    
	-- second result set is the localized report names
	open _ref_report_localized for
		select report_file,two_letter_code,report_name_localized
		from report
		join report_locale on (report.repid = report_locale.repid);
	return next _ref_report_localized;

	-- Thirs result set is the report labels   
	open _ref_report_labels for 
		select report_file,label_name
		from report
		join report_label_map on (report.repid = report_label_map.repid)
		join report_label on (report_label_map.rlid = report_label.rlid);
	return next _ref_report_labels;

END;
$$
LANGUAGE 'plpgsql';

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated:	Dec 1 2010
--		Converted to PostGreSQL
-- Description:	Converts string to table
-- Parameters:
--   None
-- Returns:
--   Nothing
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".udf_core_array_to_table
( 
	_array 			varchar(3000), 
	_delim 			varchar(6)
);

CREATE FUNCTION "WorkloadBalancing".udf_core_array_to_table
( 
	_array 			varchar(3000), 
	_delim 			varchar(6)
) 
RETURNS setof array_table AS $$
DECLARE
	r 			array_table%rowtype;
	_end_pos 		integer;
	_field_value 		varchar(500);
BEGIN

	_array := _array  || _delim;
	_end_pos := position(_delim in _array);

	create temp table _array_temp_table(fld varchar(500)) on commit drop;

	-- loop until we reach the end of the text 
	while (length(_array) > 0) loop 

		_field_value := cast(ltrim(rtrim(substring(_array, 0, _end_pos))) as varchar(500));

		-- did we find a valid element? 
		if (length(_field_value ) > 0) then
			insert into _array_temp_table(fld) 
			values (_field_value);
		end if;
 
		_array = substr(_array, _end_pos + 1);


		-- move the pointer
		_end_pos := position(_delim in _array); 

	end loop;

	for r in
		
		select fld from _array_temp_table

	loop
	return next r;
	end loop;

	RETURN;
	

END;
$$ LANGUAGE plpgsql;
-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated:	Dec 11 2010
--		Converted to PostGreSQL
-- Description:	Converts string to table
-- Parameters:
--   None
-- Returns:
--   Nothing
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".udf_getlocaltime
( 
	_dt 	timestamp, 
	_bias 	integer
);

CREATE FUNCTION "WorkloadBalancing".udf_getlocaltime
( 
	_dt 	timestamp, 
	_bias 	integer
) 
RETURNS timestamp AS $$
DECLARE
	_interval	interval;
BEGIN

	_interval := _bias || ' minute';
	return datetimeadd(_dt, _interval);

END;
$$ LANGUAGE plpgsql;
-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated:	Dec 11 2010
--		Converted to PostGreSQL
-- Description:	Gets the proper data based on UTC offset and then 
--		returns the proper day in YYYY-MM-DD 00:00:00 format
-- Parameters:
--	_dt 			timestamp, 
--	_bias 			integer
-- Returns:
--   	timestamp
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".udf_getlocaltime_nohour
( 
	_dt 	timestamp, 
	_bias 	integer
);

CREATE FUNCTION "WorkloadBalancing".udf_getlocaltime_nohour
( 
	_dt 	timestamp, 
	_bias 	integer
) 
RETURNS timestamp AS $$	
BEGIN

	_dt := (select udf_getlocaltime(_dt, _bias));	
	return cast(to_char(_dt, 'YYYY-MM-DD 00:00:00') as timestamp);

END;
$$ LANGUAGE plpgsql;
-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated:	Dec 12 2010
--		Converted to PostGreSQL
-- Description:	Offsets dates based on reporting parameter requirements
-- Parameters:
--	 _day_offset 		integer,
--	 _is_begin 		integer,
--	 _is_utc 		integer,
--	 _UTCNow 		timestamp,
--	 _tzoffset 		integer
-- Returns:
--   	timestamp
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".udf_core_get_offset_date
( 
	 _day_offset 		integer,
	 _is_begin 		integer,
	 _is_utc 		integer,
	 _UTCNow 		timestamp,
	 _tzoffset 		integer
);

CREATE FUNCTION "WorkloadBalancing".udf_core_get_offset_date
( 
	 _day_offset 		integer,
	 _is_begin 		integer,
	 _is_utc 		integer,
	 _UTCNow 		timestamp,
	 _tzoffset 		integer
) 
RETURNS timestamp AS $$	
DECLARE
	_return_date 		timestamp;
	_today 			timestamp;
	_interval		interval;
BEGIN

	-- Get today by adding the timezone bias minutes and daylight savings where applicable
	_today := (select udf_getlocaltime_nohour(_UTCNow, _tzoffset));


	-- If this is the beginning of the range then start at 00:00 of the current day
	-- If this is the end of the range then start at 23:59 of the next day
	if (_is_begin = 1) then
		_interval := _day_offset || ' day';
		_return_date := datetimeadd(_today, _interval);
	else
		if (_is_utc = 1) then

			_interval := '23 hour';
			_today := datetimeadd(_today, _interval);

			_interval := '59 minute';
			_today := datetimeadd(_today, _interval);			

			_interval := _day_offset || ' day';
			_return_date := datetimeadd(_today, _interval);

		else
			_interval := _day_offset || ' day';
			_return_date := datetimeadd(_today, _interval);

		end if;
	end if;


	-- Subtract the tzoffset to make the date and time in UTC
	if (_is_utc = 1) then

		_interval := (-1 * _tzoffset) || ' minute';
		_return_date := datetimeadd(_return_date, _interval);

	end if;


	return _return_date;

END;
$$ LANGUAGE plpgsql;
-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated:	Dec 12 2010
--		Converted to PostGreSQL
-- Description:	Offsets dates based on reporting parameter requirements
-- Parameters:
--	 _day_offset 		integer,
--	 _is_begin 		integer,
--	 _is_utc 		integer,
--	 _UTCNow 		timestamp,
--	 _tzoffset 		integer
-- Returns:
--   	timestamp
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".udf_get_interval_date
( 
	 _intervalid 	integer
) CASCADE;

CREATE FUNCTION "WorkloadBalancing".udf_get_interval_date
( 
	 _intervalid 	integer
)
RETURNS timestamp AS $$	
DECLARE
	_return_date 	timestamp;
BEGIN

	_return_date := (select datetimeadd(datetimeadd(datetimeadd('1900-01-01 00:00:00', cast((ci.year - 1900) || ' year' as interval)), cast((ci.day_of_year - 1) || ' day' as interval)), cast(ci.hour_interval || ' hour' as interval))
			 from consolidation_intervals ci
			 where ci.intervalid = _intervalid);


	return _return_date;

END;
$$ LANGUAGE plpgsql;
/*
 * (c) Copyright 2008 Citrix Systems, Inc.
 * ALL RIGHTS RESERVED
 *
 * Project:	SQL
 * Module:	Citrix DWM add historical views
 *
 * $LOG$
 *
 */
/******************************************************************************/

DROP VIEW IF EXISTS vw_host_metric_history;

CREATE VIEW vw_host_metric_history
AS
  select hmh.id
	,hvh.id as host_id
	,hvh.name as host_name
	,hvh.uuid as host_uuid
	,hvh.ip_address as host_ip_address
	,hvh.num_cpus as host_num_cpus
	,hvh.cpu_speed as host_cpu_speed
	,hvh.num_pifs
	,hvh.is_pool_master as host_is_pool_master
	,hmh.avg_total_mem
	,hmh.avg_free_mem
    ,hmh.max_total_mem
    ,hmh.max_free_mem
    ,hmh.min_total_mem
    ,hmh.min_free_mem
    ,hmh.avg_total_cpu
    ,hmh.min_total_cpu
    ,hmh.max_total_cpu
    ,hmh.avg_total_pif_read_per_sec
    ,hmh.min_total_pif_read_per_sec
    ,hmh.max_total_pif_read_per_sec
    ,hmh.avg_total_pif_write_per_sec
    ,hmh.min_total_pif_write_per_sec
    ,hmh.max_total_pif_write_per_sec
    ,hmh.avg_load_average
    ,hmh.min_load_average
    ,hmh.max_load_average
    ,udf_get_interval_date(intervalid) as date_time
  from host_metric_history hmh 
  join hv_host hvh on (hvh.id = hmh.hostid);



/**********************************************************
VM Metric History
**********************************************************/
DROP VIEW IF EXISTS vw_vm_metric_history CASCADE;

CREATE VIEW vw_vm_metric_history
AS
  select vmh.id
    ,vm.id as vm_id
    ,vm.name as vm_name
    ,vm.uuid as vm_uuid
    ,vmh.hostid as host_id
    ,vm.min_dynamic_memory
    ,vm.min_static_memory
    ,vm.min_cpus
    ,vmh.avg_total_mem
    ,vmh.avg_free_mem
    ,vmh.avg_target_mem
    ,vmh.avg_cpu
    ,vmh.avg_vif_read
    ,vmh.avg_vif_write
    ,vmh.avg_vbd_read
    ,vmh.avg_vbd_write
    ,vmh.total_vbd_net_read
    ,vmh.total_vbd_net_write
    ,vmh.max_total_mem
    ,vmh.max_free_mem
    ,vmh.max_target_mem
    ,vmh.max_cpu
    ,vmh.max_vif_read
    ,vmh.max_vif_write
    ,vmh.max_vbd_read
    ,vmh.max_vbd_write
    ,vmh.max_total_vbd_net_read
    ,vmh.max_total_vbd_net_write
    ,vmh.min_total_mem
    ,vmh.min_free_mem
    ,vmh.min_target_mem
    ,vmh.min_cpu
    ,vmh.min_vif_read
    ,vmh.min_vif_write
    ,vmh.min_vbd_read
    ,vmh.min_vbd_write
    ,vmh.min_total_vbd_net_read
    ,vmh.min_total_vbd_net_write
    ,vmh.avg_runstate_blocked
    ,vmh.avg_runstate_partial_run
    ,vmh.avg_runstate_fullrun
    ,vmh.avg_runstate_partial_contention
    ,vmh.avg_runstate_concurrency_hazard
    ,vmh.avg_runstate_full_contention
    ,udf_get_interval_date(intervalid) as date_time
  from vm_metric_history vmh 
  join virtual_machine vm on (vm.id = vmh.vmid);


/**********************************************************
Host VM History
**********************************************************/
DROP VIEW IF EXISTS vw_host_vm_history;

CREATE VIEW vw_host_vm_history
AS
  select hvmh.id
	,hvmh.vm_id as vm_id
	,vm.name as vm_name
	,vm.uuid as vm_uuid
	,hvmh.host_id
	,hvh.name as host_name
	,hvh.uuid as host_uuid
	,hvh.ip_address as host_ip_address		
	,hvmh.recommendation_id
	,hvmh.start_time
	,hvmh.end_time
  from host_vm_history hvmh 
	join hv_host hvh  on (hvh.id = hvmh.host_id)
	join virtual_machine vm on (vm.id = hvmh.vm_id);


/**********************************************************
VM Chargeback History
**********************************************************/
DROP VIEW IF EXISTS vw_vm_chargeback_history;

CREATE VIEW vw_vm_chargeback_history
AS	select 
		-- VM id from database
		vm_base.vm_id,
		-- VM uuid from XenServer
		vm_base.vm_uuid,
		-- VM name
		vm_base.vm_name,
		-- Total uptime for this VM since WLB has known about it (or back to the point where DB had been groomed off)
		datetimediff('minute', vm_base.start_time, vm_base.end_time) total_uptime_minutes,
		-- Current VCPU count
		min(vm_base.min_cpus) as cpu_count,   
		-- Min VCPU usage
		min(min_cpu) as min_cpu_usage, 
		-- Max VCPU usage			 
		max(max_cpu) as max_cpu_usage,
		-- Avg VCPU usage			  
		avg(vvmh.avg_cpu) as avg_cpu_usage, 
		-- Current storage allocation
		(select sum(vbd.size)
		from vm_vbd join vbd on vm_vbd.vbd_id = vbd.id
		where vm_vbd.vm_id = vm_base.vm_id) as total_storage_allocation, 
		-- Current vitual nic count
		(select count(distinct vif.device_number)
		from vm_vif join vif on vm_vif.vif_id = vif.id
		where vm_vif.vm_id = vm_base.vm_id) total_nic,
		-- Current min Dynamic Memory   
		min(vm_base.min_dynamic_memory) as min_dynamic_memory, 
		-- Current max Dynamic Memory               
		max(vm_base.max_dynamic_memory) as max_dynamic_memory,   
		-- Current gssigned memory 
		(select vmm.total_mem 
		from vm_metric vmm 
		where vmm.vmid = vm_base.vm_id
		order by id desc limit 1) as current_total_memory,
		-- Average gssigned memory 
		cast(avg(vvmh.avg_total_mem) as bigint) as avg_total_memory,                
		-- Network reads
		avg(vvmh.avg_vif_read) as avg_vif_reads,
		-- Network writes
		avg(vvmh.avg_vif_write) as avg_vif_writes,                                              
		-- Network average total network utilization (writes + reads)
		avg(vvmh.avg_vif_write)+avg(vvmh.avg_vif_read) as avg_total_vif,                                              
		-- Network total network utilization (writes + reads)
		(avg(vvmh.avg_vif_read) + avg(vvmh.avg_vif_write)) * datetimediff('minute', vm_base.start_time, vm_base.end_time) as total_vif                                              
                                  
	  from
	  (      
		select 
			hvmh.vm_id,
			vm.uuid as vm_uuid,
			vm.name as vm_name,
			vm.min_cpus,
			vm.min_dynamic_memory,
			vm.max_dynamic_memory,
			hvmh.start_time,
			datetimeadd('1900-01-01 00:00:00', cast(datetimediff('hour', '1900-01-01 00:00:00', hvmh.start_time) || ' hour' as interval)) metric_start_time,                                                                              
			coalesce(hvmh.end_time, getutcdate()) end_time,      
			datetimeadd('1900-01-01 00:00:00', cast(datetimediff('hour', '1900-01-01 00:00:00', coalesce(hvmh.end_time, getutcdate())) || ' hour' as interval)) as metric_end_time                                        
		from host_vm_history hvmh
			join virtual_machine vm on (hvmh.vm_id = vm.id)
			join hv_pool hp on (hp.id = vm.poolid)   
			and vm.is_control_domain = false
	  ) vm_base
	  left join vw_vm_metric_history vvmh on vvmh.vm_id = vm_base.vm_id
		and vvmh.date_time between vm_base.metric_start_time and vm_base.metric_end_time
	
	group by vm_base.vm_id, vm_base.vm_uuid, vm_base.vm_name, vm_base.start_time, vm_base.end_time, 
		vm_base.metric_start_time, vm_base.metric_end_time,
		vm_base.min_cpus, vm_base.min_dynamic_memory,vm_base.max_dynamic_memory;
-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:	Deane Smith
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 24, 2011
-- Description:	Returns dataset for the Host Health History report
-- Parameters:
--	_Start 	Start date for data query
--	_End 		End date for data query
--	_PoolID	uuid of pool
--	_UTCOffset 	UTC offset minutes
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".rp_host_health_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_HostID			varchar(96),
	_UTCOffset 		varchar(10)
);

CREATE FUNCTION "WorkloadBalancing".rp_host_health_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_HostID			varchar(96),
	_UTCOffset 		varchar(10)
) 
RETURNS SETOF rp_host_health_history_type AS $$
DECLARE
	 r 			rp_host_health_history_type%rowtype;
	_UTCNow			timestamp;
	_UTCStartDate		timestamp;
	_UTCEndDate		timestamp;
	_LocalStartDate		timestamp;
	_LocalEndDate		timestamp;
	_pStart 		int;
	_pEnd 			int;
	_pUTCOffset 		int;
BEGIN

	_pStart := cast(_Start as integer);
	_pEnd := cast(_End as integer);
	_pUTCOffset := cast(_UTCOffset as integer);

	_UTCNow := getutcdate();
	_UTCStartDate :=  udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
	_UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);
	_LocalStartDate = udf_core_get_offset_date(_pStart, 1, 0, _UTCNow, _pUTCOffset);
	_LocalEndDate = udf_core_get_offset_date(_pEnd, 0, 0, _UTCNow, _pUTCOffset);

	for r in

		select cal.dtperiod as day, cal.hourlabel as hour, hostid, name, start_time,
			host_cpu_threshold_critical, host_cpu_threshold_high, host_cpu_threshold_medium,
			host_cpu_threshold_low, host_memory_threshold_critical, host_memory_threshold_high,
			host_memory_threshold_medium, host_memory_threshold_low, host_net_read_threshold_critical,
			host_net_read_threshold_high, host_net_read_threshold_medium, host_net_read_threshold_low,
			host_net_write_threshold_critical, host_net_write_threshold_high, host_net_write_threshold_medium,
			host_net_write_threshold_low,
			avg_total_cpu, avg_free_mem, avg_total_pif_read_per_sec, avg_total_pif_write_per_sec									
		from rs_calendar cal		  
		left join
		(		
			select hmh.hostid, hh.name, hmh.start_time,		

				udf_getlocaltime_nohour(hmh.start_time, _pUTCOffset) as dtperiod,
				date_part('hour',udf_getlocaltime(hmh.start_time, _pUTCOffset)) as hour,				
			
				-- Threshold values
				hpth.host_cpu_threshold_critical,
				hpth.host_cpu_threshold_high,
				hpth.host_cpu_threshold_medium,
				hpth.host_cpu_threshold_low,
				hpth.host_memory_threshold_critical,
				hpth.host_memory_threshold_high,
				hpth.host_memory_threshold_medium,
				hpth.host_memory_threshold_low,
				hpth.host_net_read_threshold_critical,
				hpth.host_net_read_threshold_high,
				hpth.host_net_read_threshold_medium,
				hpth.host_net_read_threshold_low,
				hpth.host_net_write_threshold_critical,
				hpth.host_net_write_threshold_high,
				hpth.host_net_write_threshold_medium,
				hpth.host_net_write_threshold_low,

				-- Metrics
				hmh.avg_total_cpu,
				hmh.avg_free_mem,
				hmh.avg_total_pif_read_per_sec,
				hmh.avg_total_pif_write_per_sec				

			from host_metric_history hmh
				join hv_host hh on (hmh.hostid = hh.id)
				join hv_pool_host hph on (hph.hostid = hmh.hostid)
				join hv_pool hp on (hp.id = hph.poolid)
				join hv_pool_threshold_history hpth on (hpth.pool_id = hph.poolid and hmh.start_time between hpth.config_start_date and coalesce(hpth.config_end_date,getutcdate()))												
			where hmh.start_time between _UTCStartDate and _UTCEndDate 
				and hh.uuid = _HostID
				and hp.uuid = _PoolID			
		) p2  on (cal.dtperiod = p2.dtperiod and p2.hour = cal.hourid)
		where cal.dtperiod 
		between _LocalStartDate and _LocalEndDate	
		order by cal.dtperiod, cal.hourlabel

	loop
	return next r;
	end loop;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:	Deane Smith
-- Create date: December 9, 2008
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 18, 2011
-- Description:	Returns dataset for the Pool Health report
-- Parameters:
--	_pStart 	Start date for data query
--	_pEnd 		End date for data query
--	_pPoolID	uuid of pool
--	_pUTCOffset 	UTC offset minutes
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".rp_pool_health
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
);

CREATE FUNCTION "WorkloadBalancing".rp_pool_health
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
) 
RETURNS SETOF rp_pool_health_type AS $$
DECLARE
	 r 			rp_pool_health_type%rowtype;
	_UTCNow			timestamp;
	_UTCStartDate		timestamp;
	_UTCEndDate		timestamp;
	_pStart 		int;
	_pEnd 			int;
	_pUTCOffset 		int;
BEGIN

	_pStart := cast(_Start as integer);
	_pEnd := cast(_End as integer);
	_pUTCOffset := cast(_UTCOffset as integer);

	_UTCNow := getutcdate();
	_UTCStartDate :=  udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
	_UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);

	for r in

		select hmh.hostid, hh.name, hh.uuid, hmh.start_time,
		
			-- Actual threshold values
			hpth.host_cpu_threshold_critical,
			hpth.host_cpu_threshold_high,
			hpth.host_cpu_threshold_medium,
			hpth.host_cpu_threshold_low,
			hpth.host_memory_threshold_critical,
			hpth.host_memory_threshold_high,
			hpth.host_memory_threshold_medium,
			hpth.host_memory_threshold_low,
			hpth.host_net_read_threshold_critical,
			hpth.host_net_read_threshold_high,
			hpth.host_net_read_threshold_medium,
			hpth.host_net_read_threshold_low,
			hpth.host_net_write_threshold_critical,
			hpth.host_net_write_threshold_high,
			hpth.host_net_write_threshold_medium,
			hpth.host_net_write_threshold_low,
					
			-- CPU Percent
			(case when hmh.avg_total_cpu >= hpth.host_cpu_threshold_critical then 'Critical' 
				when (hmh.avg_total_cpu >= hpth.host_cpu_threshold_high) and (hmh.avg_total_cpu < hpth.host_cpu_threshold_critical) then 'High'
				when (hmh.avg_total_cpu >= hpth.host_cpu_threshold_medium) and (hmh.avg_total_cpu < hpth.host_cpu_threshold_high) then 'Medium'
				when (hmh.avg_total_cpu >= 0) and (hmh.avg_total_cpu < hpth.host_cpu_threshold_medium) then 'Low'
			end) as cpu_threshold_percent,

			-- Memory Percent
			(case when hmh.avg_free_mem <= hpth.host_memory_threshold_critical then 'Critical' 
				when (hmh.avg_free_mem <= hpth.host_memory_threshold_high) and (hmh.avg_free_mem > hpth.host_memory_threshold_critical) then 'High'
				when (hmh.avg_free_mem <= hpth.host_memory_threshold_medium) and (hmh.avg_free_mem > hpth.host_memory_threshold_high) then 'Medium'
				when (hmh.avg_free_mem > hpth.host_memory_threshold_medium) then 'Low' 
			end) as memory_threshold_percent,
			
			-- Network Reads Percent
			(case when hmh.avg_total_pif_read_per_sec >= hpth.host_net_read_threshold_critical then 'Critical'  
				when (hmh.avg_total_pif_read_per_sec >= hpth.host_net_read_threshold_high) and (hmh.avg_total_pif_read_per_sec < hpth.host_net_read_threshold_critical) then 'High' 
				when (hmh.avg_total_pif_read_per_sec >= hpth.host_net_read_threshold_medium) and (hmh.avg_total_pif_read_per_sec < hpth.host_net_read_threshold_high) then 'Medium'
				when (hmh.avg_total_pif_read_per_sec >= 0) and (hmh.avg_total_pif_read_per_sec < hpth.host_net_read_threshold_medium) then 'Low'
			end) as network_read_threshold_percent,
			
			-- Network Writes Percent
			(case when hmh.avg_total_pif_write_per_sec >= hpth.host_net_write_threshold_critical then 'Critical'  
				when (hmh.avg_total_pif_write_per_sec >= hpth.host_net_write_threshold_high) and (hmh.avg_total_pif_write_per_sec < hpth.host_net_write_threshold_critical) then 'High'  
				when (hmh.avg_total_pif_write_per_sec >= hpth.host_net_write_threshold_medium) and (hmh.avg_total_pif_write_per_sec < hpth.host_net_write_threshold_high) then 'Medium'
				when (hmh.avg_total_pif_write_per_sec >= 0) and (hmh.avg_total_pif_write_per_sec < hpth.host_net_write_threshold_medium) then 'Low'
			end) as network_write_threshold_percent,		
		
			-- CPU Critial Value
			(case when hmh.avg_total_cpu >= hpth.host_cpu_threshold_critical then hmh.avg_total_cpu else null end) as cpu_critical,
			(case when (hmh.avg_total_cpu >= hpth.host_cpu_threshold_high) and (hmh.avg_total_cpu < hpth.host_cpu_threshold_critical) then hmh.avg_total_cpu else null end) as cpu_high,
			(case when (hmh.avg_total_cpu >= hpth.host_cpu_threshold_medium) and (hmh.avg_total_cpu < hpth.host_cpu_threshold_high) then hmh.avg_total_cpu else null end) as cpu_medium,
			(case when (hmh.avg_total_cpu >= 0) and (hmh.avg_total_cpu < hpth.host_cpu_threshold_medium) then hmh.avg_total_cpu else null end) as cpu_low,

			-- Memory
			(case when hmh.avg_free_mem <= hpth.host_memory_threshold_critical then hmh.avg_free_mem else null end) as memory_critical,
			(case when (hmh.avg_free_mem <= hpth.host_memory_threshold_high) and (hmh.avg_free_mem > hpth.host_memory_threshold_critical) then hmh.avg_free_mem else null end) as memory_high,
			(case when (hmh.avg_free_mem <= hpth.host_memory_threshold_medium) and (hmh.avg_free_mem > hpth.host_memory_threshold_high) then hmh.avg_free_mem else null end) as memory_medium,
			(case when (hmh.avg_free_mem > hpth.host_memory_threshold_medium) then hmh.avg_free_mem else null end) as memory_low,

			-- Network Reads
			(case when hmh.avg_total_pif_read_per_sec >= hpth.host_net_read_threshold_critical then hmh.avg_total_pif_read_per_sec else null end) as network_reads_critical,
			(case when (hmh.avg_total_pif_read_per_sec >= hpth.host_net_read_threshold_high) and (hmh.avg_total_pif_read_per_sec < hpth.host_net_read_threshold_critical) then hmh.avg_total_pif_read_per_sec else null end) as network_reads_high,
			(case when (hmh.avg_total_pif_read_per_sec >= hpth.host_net_read_threshold_medium) and (hmh.avg_total_pif_read_per_sec < hpth.host_net_read_threshold_high) then hmh.avg_total_pif_read_per_sec else null end) as network_reads_medium,
			(case when (hmh.avg_total_pif_read_per_sec >= 0) and (hmh.avg_total_pif_read_per_sec < hpth.host_net_read_threshold_medium) then hmh.avg_total_pif_read_per_sec else null end) as network_reads_low,

			-- Network Writes
			(case when hmh.avg_total_pif_write_per_sec >= hpth.host_net_write_threshold_critical then hmh.avg_total_pif_write_per_sec else null end) as network_writes_critical,
			(case when (hmh.avg_total_pif_write_per_sec >= hpth.host_net_write_threshold_high) and (hmh.avg_total_pif_write_per_sec < hpth.host_net_write_threshold_critical) then hmh.avg_total_pif_write_per_sec else null end) as network_writes_high,
			(case when (hmh.avg_total_pif_write_per_sec >= hpth.host_net_write_threshold_medium) and (hmh.avg_total_pif_write_per_sec < hpth.host_net_write_threshold_high) then hmh.avg_total_pif_write_per_sec else null end) as network_writes_medium,
			(case when (hmh.avg_total_pif_write_per_sec >= 0) and (hmh.avg_total_pif_write_per_sec < hpth.host_net_write_threshold_medium) then hmh.avg_total_pif_write_per_sec else null end) as network_writes_low

		from host_metric_history hmh
			join hv_host hh on (hmh.hostid = hh.id)
			join hv_pool_host hph on (hph.hostid = hmh.hostid)
			join hv_pool hp on (hp.id = hph.poolid)
			join hv_pool_threshold_history hpth on (hpth.pool_id = hph.poolid and hmh.start_time between hpth.config_start_date and coalesce(hpth.config_end_date,getutcdate()))
		where hmh.start_time between _UTCStartDate and _UTCEndDate 
		and hp.uuid =_PoolID


	loop
	return next r;
	end loop;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:	Deane Smith
-- Create date: December 9, 2008
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 18, 2011
-- Description:	Returns dataset for the Pool Health History
-- Parameters:
--	_Start 	Start date for data query
--	_End 		End date for data query
--	_PoolID	uuid of pool
--	_UTCOffset 	UTC offset minutes
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".rp_pool_health_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
);

CREATE FUNCTION "WorkloadBalancing".rp_pool_health_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
) 
RETURNS SETOF rp_pool_health_history_type AS $$
DECLARE
	 r 			rp_pool_health_history_type%rowtype;
	_UTCNow			timestamp;
	_UTCStartDate		timestamp;
	_UTCEndDate		timestamp;
	_LocalStartDate		timestamp;
	_LocalEndDate		timestamp;
	_pStart 		int;
	_pEnd 			int;
	_pUTCOffset 		int;
BEGIN

	_pStart := cast(_Start as integer);
	_pEnd := cast(_End as integer);
	_pUTCOffset := cast(_UTCOffset as integer);

	_UTCNow := getutcdate();
	_UTCStartDate :=  udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
	_UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);
	_LocalStartDate = udf_core_get_offset_date(_pStart, 1, 0, _UTCNow, _pUTCOffset);
	_LocalEndDate = udf_core_get_offset_date(_pEnd, 0, 0, _UTCNow, _pUTCOffset);

	for r in

		select cal.dtperiod as day, cal.hourlabel as hour, hostid, name, start_time,
			host_cpu_threshold_critical, host_cpu_threshold_high, host_cpu_threshold_medium,
			host_cpu_threshold_low, host_memory_threshold_critical, host_memory_threshold_high,
			host_memory_threshold_medium, host_memory_threshold_low, host_net_read_threshold_critical,
			host_net_read_threshold_high, host_net_read_threshold_medium, host_net_read_threshold_low,
			host_net_write_threshold_critical, host_net_write_threshold_high, host_net_write_threshold_medium,
			host_net_write_threshold_low, avg_total_cpu, avg_free_mem, avg_total_pif_read_per_sec, 
			avg_total_pif_write_per_sec									
		from rs_calendar cal		  
		left join
		(		
			select hmh.hostid, hh.name, hmh.start_time,
			
				udf_getlocaltime_nohour(hmh.start_time, _pUTCOffset) as dtperiod,
				date_part('hour',udf_getlocaltime(hmh.start_time, _pUTCOffset)) as hour,				
			
				-- Threshold values
				hpth.host_cpu_threshold_critical,
				hpth.host_cpu_threshold_high,
				hpth.host_cpu_threshold_medium,
				hpth.host_cpu_threshold_low,
				hpth.host_memory_threshold_critical,
				hpth.host_memory_threshold_high,
				hpth.host_memory_threshold_medium,
				hpth.host_memory_threshold_low,
				hpth.host_net_read_threshold_critical,
				hpth.host_net_read_threshold_high,
				hpth.host_net_read_threshold_medium,
				hpth.host_net_read_threshold_low,
				hpth.host_net_write_threshold_critical,
				hpth.host_net_write_threshold_high,
				hpth.host_net_write_threshold_medium,
				hpth.host_net_write_threshold_low,

				-- Metrics
				hmh.avg_total_cpu,
				hmh.avg_free_mem,
				hmh.avg_total_pif_read_per_sec,
				hmh.avg_total_pif_write_per_sec				

			from host_metric_history hmh
				join hv_host hh on (hmh.hostid = hh.id)
				join hv_pool_host hph on (hph.hostid = hmh.hostid)
				join hv_pool hp on (hp.id = hph.poolid)
				join hv_pool_threshold_history hpth on (hpth.pool_id = hph.poolid and hmh.start_time between hpth.config_start_date and coalesce(hpth.config_end_date,getutcdate()))												
			where hmh.start_time between _UTCStartDate and _UTCEndDate 
				and hp.uuid = _PoolID
			
		) p2  on (cal.dtperiod = p2.dtperiod and p2.hour = cal.hourid)
		where cal.dtperiod 
		between _LocalStartDate and _LocalEndDate	
		order by cal.dtperiod, cal.hourlabel

	loop
	return next r;
	end loop;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:	Deane Smith
-- Create date: March, 2008
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 18, 2011
-- Description:	Returns dataset for the Pool Optimization History
-- Parameters:
--	_Start 	Start date for data query
--	_End 		End date for data query
--	_PoolID	uuid of pool
--	_UTCOffset 	UTC offset minutes
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".rp_pool_optimization_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
);

CREATE FUNCTION "WorkloadBalancing".rp_pool_optimization_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
) 
RETURNS SETOF rp_pool_optimization_history_type AS $$
DECLARE
	 r 			rp_pool_optimization_history_type%rowtype;
	_UTCNow			timestamp;
	_UTCStartDate		timestamp;
	_UTCEndDate		timestamp;
	_LocalStartDate		timestamp;
	_LocalEndDate		timestamp;
	_pStart 		int;
	_pEnd 			int;
	_pUTCOffset 		int;
BEGIN

	_pStart := cast(_Start as integer);
	_pEnd := cast(_End as integer);
	_pUTCOffset := cast(_UTCOffset as integer);

	_UTCNow := getutcdate();
	_UTCStartDate :=  udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
	_UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);
	_LocalStartDate = udf_core_get_offset_date(_pStart, 1, 0, _UTCNow, _pUTCOffset);
	_LocalEndDate = udf_core_get_offset_date(_pEnd, 0, 0, _UTCNow, _pUTCOffset);

	for r in

		select cal.dtperiod as day, cal.hourlabel as hour,
			id, vmid, vmname, from_hostid, from_hostname, to_hostid, to_hostname, 
			recommendation_id, reason, status, move_time		
		from rs_calendar cal		  
		left join
		(
			select udf_getlocaltime_nohour(hvmh2.start_time, _pUTCOffset) as dtperiod,
				date_part('hour',udf_getlocaltime(hvmh2.start_time, _pUTCOffset)) as hour,
				mrd.id as id, vm.id as vmid, vm.name as vmname, 
				hvmh.host_id as from_hostid, hvh.name as from_hostname, hvmh2.host_id as to_hostid, hvh2.name as to_hostname,
				mrd.recommendation_id, mrd.reason, mrd.status,				
				udf_getlocaltime(hvmh2.start_time, _pUTCOffset) as move_time
			from host_vm_history hvmh
				join host_vm_history hvmh2 on (hvmh2.vm_id = hvmh.vm_id and hvmh2.start_time = hvmh.end_time)
				join hv_host hvh on (hvh.id = hvmh.host_id)	
				join hv_host hvh2 on (hvh2.id = hvmh2.host_id)							
				join hv_pool_host hvph on (hvph.hostid = hvmh.host_id)					
				join hv_pool hvp on (hvp.id = hvph.poolid)					
				join virtual_machine vm on (vm.id = hvmh.vm_id)
				join move_recommendation_detail mrd on (mrd.id = hvmh2.recommendation_id)
			where hvmh.start_time between _UTCStartDate and _UTCEndDate
				and hvp.uuid = _PoolID
				and mrd.recommendation_id is not null
				and mrd.vm_id is not null
			union
			select udf_getlocaltime_nohour(mrd.tstamp, _pUTCOffset) as dtperiod,
				date_part('hour',udf_getlocaltime(mrd.tstamp, _pUTCOffset)) as hour,
				mrd.id as id, null as vmid, null as vmname,
				mrd.from_host_id as from_hostid, hh.name as from_hostname, null as to_hostid, null as to_hostname,
				mrd.recommendation_id, mrd.reason, mrd.status,
				udf_getlocaltime(mrd.tstamp, _pUTCOffset) as move_time
			from move_recommendation mr
				join move_recommendation_detail mrd on mrd.recommendation_id = mr.id
				join hv_host hh on (hh.id = mrd.from_host_id)
				join hv_pool hp on (hp.id = mr.poolid)
			where hp.uuid = _PoolID
				and (mrd.reason = 11 or mrd.reason = 12)	-- PowerOn and PowerOff (ResourceToOptimize enum)
				and (mrd.status = 1 or mrd.status = 2)		-- AutomaticallyApplied or AutomaticalApplicationFailed (RecommendationStatus enum)
				and mrd.vm_id is null	
		) p2 on (cal.dtperiod = p2.dtperiod and p2.hour = cal.hourid)
		where cal.dtperiod 
		between _LocalStartDate and _LocalEndDate	
		order by cal.dtperiod, cal.hourlabel


	loop
	return next r;
	end loop;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:	Deane Smith
-- Create date: December 9, 2008
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 18, 2011
-- Description:	Returns dataset for the Pool Health History
-- Parameters:
--	_Start 	Start date for data query
--	_End 		End date for data query
--	_PoolID	uuid of pool
--	_UTCOffset 	UTC offset minutes
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".rp_pool_optimization_performance_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
);

CREATE FUNCTION "WorkloadBalancing".rp_pool_optimization_performance_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
) 
RETURNS SETOF rp_pool_optimization_performance_history_type AS $$
DECLARE
	 r 			rp_pool_optimization_performance_history_type%rowtype;
	_UTCNow			timestamp;
	_UTCStartDate		timestamp;
	_UTCEndDate		timestamp;
	_LocalStartDate		timestamp;
	_LocalEndDate		timestamp;
	_pStart 		int;
	_pEnd 			int;
	_pUTCOffset 		int;
BEGIN

	_pStart := cast(_Start as integer);
	_pEnd := cast(_End as integer);
	_pUTCOffset := cast(_UTCOffset as integer);

	_UTCNow := getutcdate();
	_UTCStartDate :=  udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
	_UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);
	_LocalStartDate = udf_core_get_offset_date(_pStart, 1, 0, _UTCNow, _pUTCOffset);
	_LocalEndDate = udf_core_get_offset_date(_pEnd, 0, 0, _UTCNow, _pUTCOffset);

	for r in

		select cal.dtperiod as day, cal.hourlabel as hour, hostid, name, p2.start_time,
			avg_total_cpu, avg_free_mem, avg_total_pif_read_per_sec, avg_total_pif_write_per_sec,
			(select count(recommendation_id) from host_vm_history hvh
			 where hvh.host_id = p2.hostid
			 and recommendation_id is not null
			 and udf_getlocaltime_nohour(hvh.start_time, _pUTCOffset) = p2.dtperiod 
			 and date_part('hour',udf_getlocaltime(hvh.start_time, _pUTCOffset)) = p2.hour		 
			 ) as optimized_moves
		from rs_calendar cal		  
		left join
		(
			select hmh.hostid, hh.name, hmh.start_time,
				udf_getlocaltime_nohour(hmh.start_time, _pUTCOffset) as dtperiod,
				date_part('hour',udf_getlocaltime(hmh.start_time, _pUTCOffset)) as hour,			
				-- Metrics
				hmh.avg_total_cpu,
				hmh.avg_free_mem,
				hmh.avg_total_pif_read_per_sec,
				hmh.avg_total_pif_write_per_sec
			from host_metric_history hmh
				join hv_host hh on (hmh.hostid = hh.id)
				join hv_pool_host hph on (hph.hostid = hmh.hostid)
				join hv_pool hp on (hp.id = hph.poolid)				
			where hmh.start_time between _UTCStartDate and _UTCEndDate 
			and hp.uuid = _PoolID

		) p2 on (cal.dtperiod = p2.dtperiod and p2.hour = cal.hourid)	
		where cal.dtperiod 
		between _LocalStartDate and _LocalEndDate	
		order by cal.dtperiod, cal.hourlabel

	loop
	return next r;
	end loop;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:	Deane Smith
-- Create date: March, 2008
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 30, 2011
-- Description:	Returns dataset for the VM Performance History report
-- Parameters:
--	_Start 	Start date for data query
--	_End 		End date for data query
--	_PoolID	uuid of pool
--	_HostID uuid of host
--	_UTCOffset 	UTC offset minutes
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".rp_vm_performance_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_HostID 		varchar(96),
	_UTCOffset 		varchar(10)
);

CREATE FUNCTION "WorkloadBalancing".rp_vm_performance_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_HostID 		varchar(96),
	_UTCOffset 		varchar(10)
) 
RETURNS SETOF rp_vm_performance_history_type AS $$
DECLARE
	 r 			rp_vm_performance_history_type%rowtype;
	_UTCNow			timestamp;
	_UTCStartDate		timestamp;
	_UTCEndDate		timestamp;
	_LocalStartDate		timestamp;
	_LocalEndDate		timestamp;
	_pStart 		int;
	_pEnd 			int;
	_pUTCOffset 		int;
BEGIN

	_pStart := cast(_Start as integer);
	_pEnd := cast(_End as integer);
	_pUTCOffset := cast(_UTCOffset as integer);

	_UTCNow := getutcdate();
	_UTCStartDate :=  udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
	_UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);
	_LocalStartDate = udf_core_get_offset_date(_pStart, 1, 0, _UTCNow, _pUTCOffset);
	_LocalEndDate = udf_core_get_offset_date(_pEnd, 0, 0, _UTCNow, _pUTCOffset);

	for r in

		select cal.dtperiod as day, cal.hourlabel as hour, vmid, name, hostid, hostname,
			avg_cpu, avg_free_mem, avg_vif_read, avg_vif_write, avg_vbd_read, avg_vbd_write, min_dynamic_memory
		from rs_calendar cal		  
		left join
		(
			select vmh.vmid, vm.name, vmh.hostid, hvh.name as hostname, vmh.start_time,			
				udf_getlocaltime_nohour(vmh.start_time, _pUTCOffset) as dtperiod,
				date_part('hour',udf_getlocaltime(vmh.start_time, _pUTCOffset)) as hour,
				-- Metrics
				vmh.avg_cpu, vmh.avg_free_mem, vmh.avg_vif_read, vmh.avg_vif_write, 
				vmh.avg_vbd_read, vmh.avg_vbd_write, vm.min_dynamic_memory			
			from vm_metric_history vmh	
				join virtual_machine vm on (vmh.vmid = vm.id)		
				join hv_host hvh on (hvh.id = vmh.hostid)
				join hv_pool_host hph on (hph.hostid = hvh.id)
				join hv_pool hp on (hp.id = hph.poolid)				
			where vmh.start_time between _UTCStartDate and _UTCEndDate
				and vm.is_control_domain != true
				and hvh.uuid = _HostID
				and hp.uuid = _PoolID				
		) p2 on (cal.dtperiod = p2.dtperiod and p2.hour = cal.hourid)
		where cal.dtperiod 
		between _LocalStartDate and _LocalEndDate	
		order by cal.dtperiod, cal.hourlabel

	loop
	return next r;
	end loop;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:	Deane Smith
-- Create date: December 9, 2008
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 18, 2011
-- Description:	Returns dataset for the Pool Health History
-- Parameters:
--	_Start 	Start date for data query
--	_End 		End date for data query
--	_PoolID	uuid of pool
--	_UTCOffset 	UTC offset minutes
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".rp_vm_movement_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
);

CREATE FUNCTION "WorkloadBalancing".rp_vm_movement_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
) 
RETURNS SETOF rp_vm_movement_history_type AS $$
DECLARE
	 r 			rp_vm_movement_history_type%rowtype;
	_UTCNow			timestamp;
	_UTCStartDate		timestamp;
	_UTCEndDate		timestamp;
	_LocalStartDate		timestamp;
	_LocalEndDate		timestamp;
	_pStart 		int;
	_pEnd 			int;
	_pUTCOffset 		int;
BEGIN

	_pStart := cast(_Start as integer);
	_pEnd := cast(_End as integer);
	_pUTCOffset := cast(_UTCOffset as integer);

	_UTCNow := getutcdate();
	_UTCStartDate :=  udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
	_UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);
	_LocalStartDate = udf_core_get_offset_date(_pStart, 1, 0, _UTCNow, _pUTCOffset);
	_LocalEndDate = udf_core_get_offset_date(_pEnd, 0, 0, _UTCNow, _pUTCOffset);

	for r in

		select cal.dtperiod as day, cal.hourlabel as hour,
			id, vmid, vmname, from_hostid, from_hostname, to_hostid, to_hostname, 
			recommendation_id, reason, move_time		
		from rs_calendar cal		  
		left join
		(
				select udf_getlocaltime_nohour(hvmh2.start_time, _pUTCOffset) as dtperiod,
					date_part('hour', udf_getlocaltime(hvmh2.start_time, _pUTCOffset)) as hour,	
					hvmh.id as id, vm.id as vmid, vm.name as vmname, 
					hvmh.host_id as from_hostid, hvh.name as from_hostname, hvmh2.host_id as to_hostid, hvh2.name as to_hostname,
					hvmh2.recommendation_id, mrd.reason,					
					udf_getlocaltime(hvmh2.start_time, _pUTCOffset) as move_time
				from host_vm_history hvmh
					join host_vm_history hvmh2 on (hvmh2.vm_id = hvmh.vm_id and hvmh2.start_time = hvmh.end_time)
					join hv_host hvh on (hvh.id = hvmh.host_id)	
					join hv_host hvh2 on (hvh2.id = hvmh2.host_id)							
					join hv_pool_host hvph on (hvph.hostid = hvmh.host_id)					
					join hv_pool hvp on (hvp.id = hvph.poolid)					
					join virtual_machine vm on (vm.id = hvmh.vm_id)
					left join move_recommendation_detail mrd on (mrd.id = hvmh2.recommendation_id)
				where hvmh.start_time between _UTCStartDate and _UTCEndDate
					and hvp.uuid = _PoolID
		) p2  on (cal.dtperiod = p2.dtperiod and p2.hour = cal.hourid)
		where cal.dtperiod 
		between _LocalStartDate and _LocalEndDate	
		order by cal.dtperiod, cal.hourlabel


	loop
	return next r;
	end loop;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
-- Author:		Barbara Li
-- Create date: October 23, 2009
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 28, 2011
-- Description:	Returns dataset for the Pool Audit Trail History report
-- Parameters:
--	_pStart 	Start date for data query
--	_pEnd 		End date for data query
--	_pPoolID	uuid of pool
--	_pUTCOffset 	UTC offset minutes
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".rp_pool_audit_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
);

CREATE FUNCTION "WorkloadBalancing".rp_pool_audit_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
) 
RETURNS SETOF rp_pool_audit_history_type AS $$
DECLARE
	 r 			rp_pool_audit_history_type%rowtype;
	_UTCNow			timestamp;
	_UTCStartDate		timestamp;
	_UTCEndDate		timestamp;
	_pStart 		int;
	_pEnd 			int;
	_pFilter		int;
	_pUTCOffset 		int;
BEGIN

  _pStart := cast(_Start as double precision)::integer;
  _pEnd := cast(_End as double precision)::integer;
  _pUTCOffset := cast(_UTCOffset as integer);

  if (_pStart > 0) and (_pEnd > 0) then
    _UTCStartDate := to_timestamp(cast(_Start as double precision));
    _UTCEndDate := to_timestamp(cast(_End as double precision));
  else
    _UTCNow := getutcdate();
    _UTCStartDate :=  udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
    _UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);
  end if;

  for r in

    select  udf_getlocaltime(hal.log_tstamp, _pUTCOffset) as logtime, 
      udf_getlocaltime(hal.tstamp, _pUTCOffset) as tstamp, 
      hal.id as id, 
      hal.user_name as username, 
      hal.user_sid as usersid,
      hal.access_allowed as access,
      -- hal.call_type calltype,
      hal.event_object as eventobjectid, 
      haleo.name as eventobject,
      hal.event_object_name as eventobjectname, 
      hal.event_object_uuid as eventobjectuuid, 
      hal.event_action as eventactionid, 
      halea.name as eventaction,
      hal.succeeded as succeeded, 
      hal.error_info as error
    from hv_audit_log hal
      join hv_audit_log_event_object haleo on (hal.event_object = haleo.id)
      join hv_audit_log_event_action halea on (hal.event_action = halea.id)
      join hv_pool hp on (hal.pool_id = hp.id)       
    where hal.log_tstamp between _UTCStartDate and _UTCEndDate 
      and hp.uuid = _PoolID
  loop
  return next r;
  end loop;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Create date: August, 2010
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 27, 2011
-- Description:	Returns dataset for the VM Chargeback report
-- Parameters:
--	_Start 	Start date for data query
--	_End 		End date for data query
--	_PoolID	uuid of pool
--	_UTCOffset 	UTC offset minutes
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".rp_vm_chargeback_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
);

CREATE FUNCTION "WorkloadBalancing".rp_vm_chargeback_history
( 
	_Start 			varchar(10),
	_End 			varchar(10),
	_PoolID 		varchar(96),
	_UTCOffset 		varchar(10)
) 
RETURNS SETOF rp_vm_chargeback_history_type AS $$
DECLARE
	 r 			rp_vm_chargeback_history_type%rowtype;
	_UTCNow			timestamp;
	_UTCStartDate		timestamp;
	_UTCEndDate		timestamp;
	_LocalStartDate		timestamp;
	_LocalEndDate		timestamp;
	_pStart 		int;
	_pEnd 			int;
	_pUTCOffset 		int;
BEGIN

	_pStart := cast(_Start as integer);
	_pEnd := cast(_End as integer);
	_pUTCOffset := cast(_UTCOffset as integer);

	_UTCNow := getutcdate();
	_UTCStartDate :=  udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
	_UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);
	_LocalStartDate = udf_core_get_offset_date(_pStart, 1, 0, _UTCNow, _pUTCOffset);
	_LocalEndDate = udf_core_get_offset_date(_pEnd, 0, 0, _UTCNow, _pUTCOffset);

	for r in

	select 
		-- VM id from database
		vm_base.vm_id,
		-- VM uuid from XenServer
		vm_base.vm_uuid,
		-- VM name
		vm_base.vm_name,
		-- Uptime minutes during the query parameter range
		datetimediff('minute', vm_base.adjusted_start_time, vm_base.adjusted_end_time) uptime_minutes,
		-- Total uptime for this VM since WLB has known about it (or back to the point where DB had been groomed off)
		datetimediff('minute', vm_base.start_time, vm_base.end_time) total_uptime_minutes,
		-- Current VCPU count
		min(vm_base.min_cpus) as cpu_count,   
		-- Min VCPU usage
		min(min_cpu) as min_cpu_usage, 
		-- Max VCPU usage			 
		max(max_cpu) as max_cpu_usage,
		-- Avg VCPU usage			  
		avg(vvmh.avg_cpu) as avg_cpu_usage, 
		-- Current storage allocation
		(select sum(vbd.size)
		from vm_vbd join vbd on vm_vbd.vbd_id = vbd.id
		where vm_vbd.vm_id = vm_base.vm_id) as total_storage_allocation, 
		-- Current vitual nic count
		(select count(distinct vif.device_number)
		from vm_vif join vif on vm_vif.vif_id = vif.id
		where vm_vif.vm_id = vm_base.vm_id) as total_nic,
		-- Current min Dynamic Memory   
		min(vm_base.min_dynamic_memory) as min_dynamic_memory, 
		-- Current max Dynamic Memory               
		max(vm_base.max_dynamic_memory) as max_dynamic_memory,   
		-- Current assigned memory 
		(select vmm.total_mem 
		from vm_metric vmm 
		where vmm.vmid = vm_base.vm_id
		and tstamp > (datetimeadd(getutcdate(),'-120 second'))
		order by id desc limit 1) as current_total_memory,
		-- Average gssigned memory 
		cast(avg(vvmh.avg_total_mem) as bigint) as avg_total_memory,                
		-- Network reads
		avg(vvmh.avg_vif_read) as avg_vif_reads,
		-- Network writes
		avg(vvmh.avg_vif_write) as avg_vif_writes,                                              
		-- Network average total network utilization (writes + reads)
		avg(vvmh.avg_vif_write)+avg(vvmh.avg_vif_read) as avg_total_vif,                                              
		-- Network total network utilization (writes + reads)
		(avg(vvmh.avg_vif_read) + avg(vvmh.avg_vif_write)) * datetimediff('minute', vm_base.adjusted_start_time, vm_base.adjusted_end_time) as total_vif                                              
                                              
	  from
	  (      
		select 
			hvmh.vm_id,
			vm.uuid as vm_uuid,
			vm.name as vm_name,
			vm.min_cpus,
			vm.min_dynamic_memory,
			vm.max_dynamic_memory,
			hvmh.start_time,
			case when hvmh.start_time between _UTCStartDate and _UTCEndDate 
				then hvmh.start_time              
				else _UTCStartDate
				end as adjusted_start_time,       
			case when hvmh.start_time between _UTCStartDate and _UTCEndDate 
				then datetimeadd('1900-01-01 00:00:00', cast(datetimediff('hour', '1900-01-01 00:00:00', hvmh.start_time) || ' hour' as interval))                  
				else datetimeadd('1900-01-01 00:00:00', cast(datetimediff('hour', '1900-01-01 00:00:00', _UTCStartDate) || ' hour' as interval))
				end as metric_start_time,                                                                              
			coalesce(hvmh.end_time, getutcdate()) end_time,      
			case when coalesce(hvmh.end_time, getutcdate()) between _UTCStartDate and _UTCEndDate 
				then coalesce(hvmh.end_time, getutcdate())
				else datetimeadd(_UTCEndDate, '59 second')
				end as adjusted_end_time,
			case when coalesce(hvmh.end_time, getutcdate()) between _UTCStartDate and _UTCEndDate 
				then datetimeadd('1900-01-01 00:00:00', cast(datetimediff('hour', '1900-01-01 00:00:00', coalesce(hvmh.end_time, getutcdate())) || ' hour' as interval))                  
				else datetimeadd('1900-01-01 00:00:00', cast(datetimediff('hour', '1900-01-01 00:00:00',_UTCEndDate) || ' hour' as interval))
				end as metric_end_time                                        
		from host_vm_history hvmh
			join virtual_machine vm on (hvmh.vm_id = vm.id)
			join hv_pool hp on (hp.id = vm.poolid)   
			and ((hvmh.start_time <= _UTCEndDate) and ((coalesce(hvmh.end_time, getutcdate()))>= _UTCStartDate))
			and vm.is_control_domain = false
			and hp.uuid = _PoolID
	  ) vm_base
	left join vw_vm_metric_history vvmh on vvmh.vm_id = vm_base.vm_id
		and vvmh.date_time between vm_base.metric_start_time and vm_base.metric_end_time
	
	group by vm_base.vm_id, vm_base.vm_uuid, vm_base.vm_name, vm_base.start_time, vm_base.end_time, 
		vm_base.adjusted_start_time, vm_base.adjusted_end_time, 
		vm_base.metric_start_time, vm_base.metric_end_time,
		vm_base.min_cpus, vm_base.min_dynamic_memory,vm_base.max_dynamic_memory
		
	loop
	return next r;
	end loop;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Get the amount of free host memory required to run the specified VM.  The
--   required memory is dynamic max plus the hypervisor memory overhead for the
--   VM.
-- Parameters:
--   vm_id	- the database ID (id column of the virtual_machine table) of the
--            VM for which the required memory will be returned.
-- Returns:
--   Total memory in bytes.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_required_memory
( 
	_vm_id	bigint
);

CREATE FUNCTION "WorkloadBalancing".fn_required_memory
( 
	_vm_id	bigint
) RETURNS bigint AS $$

DECLARE 
	_required_memory bigint;

BEGIN

	_required_memory := (	select 	max_dynamic_memory + memory_overhead
				from 	virtual_machine
				where 	id = _vm_id);
	return _required_memory;
END;

$$ LANGUAGE plpgsql;

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--   Get the amount of total memory being used by the specified VM.  The total
--   memory includes the hypervisor memory overhead.  If the VM is not running,
--   total memory is zero..
-- Parameters:
--   vm_id - the database ID (id column of the virtual_machine table) of the
--           VM for which the total memory will be returned.
-- Returns:
--   Total memory in bytes.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_vm_total_memory
( 
	_vm_id	bigint
);

CREATE FUNCTION "WorkloadBalancing".fn_vm_total_memory
( 
	_vm_id	bigint
) 
RETURNS bigint AS $$

DECLARE
	_total_mem bigint = 0;

BEGIN
	select (vmm.total_mem + v.memory_overhead) into _total_mem
	from vm_metric vmm
		join host_vm hv on hv.vmid=vmm.vmid
		join virtual_machine v on v.id=vmm.vmid
	where vmm.vmid = _vm_id
	order by vmm.id
	limit 1;
	
	return _total_mem;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Date:		November 17, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Add a row to the vm_metric table, returning the vmmetricid.
-- Parameters:
--   vmid				   - The database ID (id column of the virtual_machine
--                           table) of the vm owning the metrics.
--   hostid				   - The database ID (id column of the hv_host table)
--                           of the host on which the VM is running.
--   total_mem             - Total memory on the vm in bytes
--   free_mem              - Free memory on the vm in bytes
--   target_mem            - Memory target for the vm in bytes.
--   avg_cpu               - Average utilization of all CPU in the vm.
--   avg_vif_read		   - Average reads/sec of all VIFs in the host.
--   avg_vif_write         - Average writes/sec of all VIFs in the host.
--   avg_vbd_read		   - Average reads/sec of all VBDs in the host.
--   avg_vbd_write         - Average writes/sec of all VBDs in the host.
--   total_vbd_net_read    - Total reads/sec of all VBDs in the host that are
--                           routed through the network.
--   total_vbd_net_write   - Total write/sec of all VBDs in the host that are
--                           routed through the network.
--	 runstate_blocked		- % of time all VCPUs are blocked
--   runstate_partial_run	- % of time VCPUs are running, others are blocked
--	 runstate_fullrun		- % of time all VCPUs are running
--	 runstate_partial_contention	- % of time some VCPUs are blocked, others are waiting for the CPU
--   runstate_concurrency_hazard	- % of time some VCPUs are running, others are waiting for the CPU
--	 runstate_full_contentionAverage - % of time all VCPUs are waiting for the CPU
--   tstamp                - UTC date and time stamp for the metrics.
--   interval_id		   - The database ID of the time interval pertaining to the metric data.
-- Returns:
--   int                   - The id of the new row, used for foreign-key inserts
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".vm_metric_add
(	
	_hour_interval 			int,
	_five_minute_interval 		int,
	_day_of_year 			int,
	_year 				int,
	_vmid 				int,
	_hostid 			int,
	_total_mem 			bigint,
	_free_mem 			bigint,
	_target_mem 			bigint,
	_avg_cpu 			decimal(9, 8),
	_avg_vif_read 			decimal(18, 4),
	_avg_vif_write 			decimal(18, 4),
	_avg_vbd_read 			decimal(18, 4),
	_avg_vbd_write 			decimal(18, 4),
	_total_vbd_net_read 		decimal(18, 4),
	_total_vbd_net_write 		decimal(18, 4),
	_runstate_blocked 		decimal(9, 8),
	_runstate_partial_run 		decimal(9, 8),
	_runstate_fullrun 		decimal(9, 8),
	_runstate_partial_contention 	decimal(9, 8),
	_runstate_concurrency_hazard 	decimal(9, 8),
	_runstate_full_contention 	decimal(9, 8),
	_cpu 				int[],
	_utilization 			numeric(9, 8)[],
	_vif 				int[],
	_io_vif_read_per_sec 		numeric(18, 4)[],
	_io_vif_write_per_sec 		numeric(18, 4)[],
	_vbd 				int[],
	_io_vbd_read_per_sec 		numeric(18, 4)[],
	_io_vbd_write_per_sec 		numeric(18, 4)[],
	_tstamp 			timestamp
);

create function "WorkloadBalancing".vm_metric_add
(	
	_hour_interval 			int,
	_five_minute_interval 		int,
	_day_of_year 			int,
	_year 				int,
	_vmid 				int,
	_hostid 			int,
	_total_mem 			bigint,
	_free_mem 			bigint,
	_target_mem 			bigint,
	_avg_cpu 			decimal(9, 8),
	_avg_vif_read 			decimal(18, 4),
	_avg_vif_write 			decimal(18, 4),
	_avg_vbd_read 			decimal(18, 4),
	_avg_vbd_write 			decimal(18, 4),
	_total_vbd_net_read 		decimal(18, 4),
	_total_vbd_net_write 		decimal(18, 4),
	_runstate_blocked 		decimal(9, 8),
	_runstate_partial_run 		decimal(9, 8),
	_runstate_fullrun 		decimal(9, 8),
	_runstate_partial_contention 	decimal(9, 8),
	_runstate_concurrency_hazard 	decimal(9, 8),
	_runstate_full_contention 	decimal(9, 8),
	_cpu 				int[],
	_utilization 			numeric(9, 8)[],
	_vif 				int[],
	_io_vif_read_per_sec 		numeric(18, 4)[],
	_io_vif_write_per_sec 		numeric(18, 4)[],
	_vbd 				int[],
	_io_vbd_read_per_sec 		numeric(18, 4)[],
	_io_vbd_write_per_sec 		numeric(18, 4)[],
	_tstamp 			timestamp
) returns int as $$
declare
	_insert_id 			int;
	_interval_id 			int;
begin

	-- Check to be sure the host exists before inserting metrics
	-- If it does not exist, return -1
	if (not exists(select uuid from virtual_machine where id = _vmid limit 1))
	then
		return -1;
	else
	
	_interval_id = (select * from get_consolidation_interval(_hour_interval, _five_minute_interval, _day_of_year, _year));

	insert into vm_metric 
	(	vmid,
		hostid,
		total_mem,
		free_mem,
		target_mem,
		avg_cpu,
		avg_vif_read,
		avg_vif_write,
		avg_vbd_read,
		avg_vbd_write,
		total_vbd_net_read,
		total_vbd_net_write,
		runstate_blocked,	
		runstate_partial_run,
		runstate_fullrun,
		runstate_partial_contention,
		runstate_concurrency_hazard,
		runstate_full_contention,															
		tstamp,
		intervalid 
	)
	values 
	(
		_vmid,
		_hostid,
		_total_mem,
		_free_mem,
		_target_mem,
		_avg_cpu,
		_avg_vif_read,
		_avg_vif_write,
		_avg_vbd_read,
		_avg_vbd_write,
		_total_vbd_net_read,
		_total_vbd_net_write,
		_runstate_blocked,	
		_runstate_partial_run,
		_runstate_fullrun,
		_runstate_partial_contention,
		_runstate_concurrency_hazard,
		_runstate_full_contention,							
		_tstamp,
		_interval_id 
	) returning id into _insert_id;


	insert into vm_cpu_metric (vm_metric_id, cpu, utilization )
		values( _insert_id, unnest(_cpu), unnest(_utilization));


	insert into vm_vif_metric (vm_metric_id, vif, io_read_per_sec, io_write_per_sec )
		values( _insert_id, unnest(_vif), unnest(_io_vif_read_per_sec), unnest(_io_vif_write_per_sec));


	insert into vm_vbd_metric (vm_metric_id, vbd, io_read_per_sec, io_write_per_sec )
		values( _insert_id, unnest(_vbd), unnest(_io_vbd_read_per_sec), unnest(_io_vbd_write_per_sec));


	return _insert_id;

	end if;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		August 20, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 18, 2010
-- Description:
--	 Add a row to the host_vm_history table if there is not a record for the
--   host and VM that does not have an ending time stamp.
-- Parameters:
--   host_id	- The database ID (id column of the hv_host table) of the host.
--   vm_id		- The database ID (id column of the virtual_machine table) of
--				  the virtual machine.
--   start_time - The UTC time the VM started running on the host
--   rec_id     - The database ID (id column of the move_recommendation_detail
--				  table) of the Kirkwood recommendation that caused the VM to
--                start or move
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_host_vm_history
(
	_host_id    int,
	_vm_id      int,
	_start_time timestamp,
	_rec_id     int
);

create function "WorkloadBalancing".add_host_vm_history
(
	_host_id    int,
	_vm_id      int,
	_start_time timestamp,
	_rec_id     int default null
) returns void
as $$
declare 
	_id int;
begin
	-- Look for a record that has not end time for this host and vm.
	select id into _id
		from host_vm_history 
		where host_id=_host_id and vm_id=_vm_id and end_time is null;

	if _id is null then
		insert into host_vm_history (host_id, vm_id, recommendation_id, start_time) 
			values (_host_id, _vm_id, _rec_id, _start_time);
	end if;

end;
$$ language plpgsql;
	
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			June 18, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 18, 2010	
-- Description:
--	 Add or update a record in the host_vm table to indicate a VM is running on
--   a physical host.
-- Parameters:
--   hostid     - The database ID (id column of the hv_host table) of the 
--                physical host on which the VM is running.
--   vmid       - The database ID (id column of the virtual_machine table) of 
--                the VM that is running on the physical host.
--   tstamp     - UTC date and time stamp the host/VM relationship was
--				  discoverd.
--   rec_id     - The database ID (id column of the move_recommendation_detail
--				  table) of the Kirkwood recommendation that caused the VM to
--                start or move
-- Returns:
--   None
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_host_vm(
	_hostid int,
	_vmid int,
	_tstamp timestamp,
	_rec_id int
);

create function "WorkloadBalancing".add_update_host_vm(
	_hostid int,
	_vmid int,
	_tstamp timestamp,
	_rec_id int default null
) returns void as $$

declare
	_id int := null;
	_move_from_host_id int := null;	

-- select * from host_vm

begin
	-- If the host ID is 0, the VM stopped.
	if _hostid is null or _hostid = 0 then
		begin
			-- Get the host the VM was running on.
			select hostid into _move_from_host_id from host_vm where vmid=_vmid;
			-- Remove this VM from the host_vm table.
			delete from host_vm where vmid = _vmid;
			-- Update the host_vm_history table.
			perform update_host_vm_history(_move_from_host_id, _vmid, _tstamp);
		end;
	else
		begin
			-- Do we have a record of the specified VM running on the specified host?

			select id into _id from host_vm where hostid=_hostid and vmid=_vmid;

			if _id is null then
				begin
				-- See if the VM was running on a different host.
				select hostid into _move_from_host_id from host_vm where vmid=_vmid;

				if _move_from_host_id is not null then
					begin
					-- VM was running on a different host.
					update host_vm set hostid=_hostid, tstamp=_tstamp where vmid=_vmid;

					-- Indicate that the VM has moved to a new host.
					insert into vm_movement (move_to_host_id, move_from_host_id, vm_id, tstamp)
						values(_hostid, _move_from_host_id, _vmid, _tstamp);

					-- Update the host_vm_history table.
					perform update_host_vm_history(_move_from_host_id, _vmid, _tstamp);
					end;
				else
					-- This is a new VM.
					insert into host_vm (hostid, vmid,tstamp) 
						values(_hostid, _vmid, _tstamp);
					
				end if;
				end;
			end if;
			-- See if we need to add a record to the host_vm_history table
			perform add_host_vm_history (_hostid, _vmid, _tstamp, _rec_id);
		end;		
	end if;
	
end;
$$ language plpgsql;




-- ========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Create date: 		June 18, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 18, 2010
-- Description:	
--	 Add or update information about a physical host in the hv_host table.
-- Parameters:
--	 _uuid		  - The unique identifier of the physical host.
--	 _name	      - The name of the physical host.
--   _pool_id     - The database ID (id column of the hv_pool table) of the 
--                  pool to which the host belongs.
--	 _description - Description of the physical host.
--	 _num_cpus    - The number of logical CPUs in the physical host.
--	 _cpu_speed	  - The speed, in mega-Hertz of the CPUs.
--	 _num_nics    - The number of physical network interface in the host.
--   _is_pool_master - Flag to indicate if the host is a pool master.
--   _ip_address - Primary TCP/IP address of the host.
--   _memory_overhead - The total memory (in bytes) consumed by DOM0
--   _enabled    - Flag to indicate if the host is enabled.
--   _power_state - Power state of the host.  1=on, 2=off.
-- Returns:
--   The ID column for the hv_host table representing the physical host.
-- ========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_hv_host
(
	_uuid		varchar(48),
	_name		varchar(256),
	_pool_id	int,
	_description	varchar(1024),
	_num_cpus	int,
	_cpu_speed	int,
	_num_nics	int,
	_is_pool_master	boolean,
	_ip_address     varchar(50),
	_memory_overhead bigint,
	_enabled         boolean,
	_power_state     int
);

create function "WorkloadBalancing".add_update_hv_host
(
	_uuid		varchar(48),
	_name		varchar(256),
	_pool_id	int,
	_description	varchar(1024),
	_num_cpus	int,
	_cpu_speed	int,
	_num_nics	int,
	_is_pool_master	boolean,
	_ip_address     varchar(50),
	_memory_overhead bigint,
	_enabled         boolean,
	_power_state     int
) returns int as $$


declare 
	_id int := null;
	_previous_power_state int;
begin
	
	select id into _id from hv_host where uuid=_uuid and poolid=_pool_id;
	
	_previous_power_state = (select power_state from hv_host where uuid=_uuid and poolid=_pool_id);

	if _memory_overhead = 0 then      
		select fn_get_pool_config_value(poolid, 'DefaultHostMemoryOverhead', null) into _memory_overhead
			from hv_pool_host
			where hostid = _id;
	end if;

	if _memory_overhead is null then
		_memory_overhead := 0;
	end if;
	
	-- Clear any other is_pool_master flags
	if _is_pool_master then
		update hv_host
			set is_pool_master = FALSE
			where poolid = _pool_id;
		update hv_host_config
			set value = FALSE
			where host_id = _id 
				and name = 'ParticipatesInPowerManagement';
	end if;

	-- Add or update the host
	if _id is not null then
		update hv_host
			set name=_name,
			description = _description,
			num_cpus = _num_cpus,
			cpu_speed = _cpu_speed,
			num_pifs = _num_nics,
			is_pool_master = _is_pool_master,
			ip_address = _ip_address,
			memory_overhead = _memory_overhead,
			enabled = _enabled,
			power_state = _power_state,
			active = TRUE
		   where id=_id;
	
	else
		insert into hv_host (uuid,
			name,
			poolid,
			description,
			num_cpus,
			cpu_speed,
			num_pifs,
			is_pool_master,
			ip_address,
                        memory_overhead,
			enabled,
			power_state,
			active)
		values (_uuid,
			_name,
			_pool_id,
			_description,
			_num_cpus,
			_cpu_speed,
			_num_nics,
			_is_pool_master,
			_ip_address,
                        _memory_overhead,
			_enabled,
			_power_state,
			TRUE);
	end if;
	
	_id := (select id from hv_host where uuid=_uuid and poolid=_pool_id);
	
	-- If the host is on, clear the flag that indicates it was powered off by WLB power management
	-- Do not clear the flag if the host was not off previously (_previous_power_state).
	if (_power_state = 1) and (_id is not null) and (_previous_power_state = 2) then
		perform set_host_powered_off_by_wlb (_id, 0);
	end if;
	return _id;
				
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			June 24, 2008
-- Modified for PosgtreSQL:	Deane Smith
-- On:				Oct 28, 2010
-- Description
--	Add or update a record in the hv_pool table.
-- Parameters:
--   uuid                       - The unique ID of the hypervisor pool to add 
--                                or update.
--   name                       - The name of the pool.
--   description                - Description of the pool.
--   hv_type                    - The type of hypervisor on which the pool runs.
--   protocol                   - The protocol (HTTP, HTTPS) used to retrieve performance metrics from the pool.
--   enabled                    - Flag to indicate if the pool is enabled.  If the pool is enabled, the WLB data 
-- 				  collector will collect metrics from the pool.
--   primary_pool_master_addr   - The host name or TCP/IP address of the computer that is the master of this pool.
--   primary_pool_master_port   - The port on which the primary pool master listens for requests.
--   secondary_pool_master_addr - The host name or TCP/IP address of the computer
--								  that is the backup master of this pool.
--   secondary_pool_master_port - The port on which the secondary pool master 
--								  listens for requests.
--   username                   - The user name used to connect to this pool.
--   password                   - The password used to connect to this pool.
--   touched_by					- The name of the user adding or updated the
--								  pool.
--   tstamp                     - UTC date and time stamp for the record.
-- Returns:
--   The database ID of the (hv_pool.id) of the record.
-- ============================================================================
DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_hv_pool
(
	"_uuid"           		varchar(48),
	"_name"           		varchar(256), 
	"_description"			varchar(1024),
	"_hv_type"        		int,
	"_enabled"        		boolean,
	"_protocol"			varchar(20),
	"_primary_pool_master_addr"   	varchar(256),
	"_primary_pool_master_port"   	int,
	"_secondary_pool_master_addr" 	varchar(256),
	"_secondary_pool_master_port" 	int,
	"_username"       		varchar(100),
	"_password"     		varchar(100),
	"_touched_by"     		varchar(50),
	"_tstamp"        		timestamp
);

create function "WorkloadBalancing".add_update_hv_pool
(
	"_uuid"           		varchar(48),
	"_name"           		varchar(256), 
	"_description"			varchar(1024),
	"_hv_type"        		int,
	"_enabled"        		boolean,
	"_protocol"			varchar(20),
	"_primary_pool_master_addr"   	varchar(256),
	"_primary_pool_master_port"   	int,
	"_secondary_pool_master_addr" 	varchar(256),
	"_secondary_pool_master_port" 	int,
	"_username"       		varchar(100),
	"_password"     		varchar(100),
	"_touched_by"     		varchar(50),
	"_tstamp"        		timestamp
) 
RETURNS INT AS
$$
declare _id bigint := null;
BEGIN

	-- Get the ID from the uuid.
	if ( _uuid is not null and char_length(_uuid) > 0)
	then
		select id into _id from hv_pool where uuid = _uuid;
	else 
		if ( _name is not null and char_length(_name) > 0)
		then
			select id into _id from hv_pool where name = _name;
		end if;
	end if;


	if ( _touched_by = '__XEN_DATA_COLLECTOR__')
	then
		select touched_by into _touched_by from hv_pool where id = _id;
		select tstamp into _tstamp from hv_pool where id = _id;
	end if;


	if ( _id is not null )
	then
		update hv_pool 
			set name = _name,
			description = _description,
			hv_type = _hv_type,
			protocol = _protocol,
			enabled = _enabled,
			pool_master_1_addr = _primary_pool_master_addr,
			pool_master_2_addr = _secondary_pool_master_addr,
			pool_master_1_port = _primary_pool_master_port,
			pool_master_2_port = _secondary_pool_master_port,
			username = _username,
			password = _password,
			touched_by = _touched_by,
			tstamp = _tstamp
		where id = _id;
	else
		-- See if the pool exists from the address and port, if so, get the ID and update.
		-- If not, insert the new pool
		select id into _id from hv_pool 
		where pool_master_1_addr = _primary_pool_master_addr 
		and pool_master_1_port = _primary_pool_master_port;

		if ( _id is not null)
		then
			update hv_pool 
				set uuid = _uuid,
				name = _name,
				description = _description,
				hv_type = _hv_type,
				protocol = _protocol,
				enabled = _enabled,
				pool_master_1_addr = _primary_pool_master_addr,
				pool_master_2_addr = _secondary_pool_master_addr,
				pool_master_1_port = _primary_pool_master_port,
				pool_master_2_port = _secondary_pool_master_port,
				username = _username,
				password = _password,
				touched_by = _touched_by,
				tstamp = _tstamp
				where id = _id;
		else
			insert into hv_pool
			(
				uuid,
				name, 
				description,
				hv_type,
				protocol,
				enabled,
				pool_master_1_addr,								
				pool_master_2_addr,
				pool_master_1_port,  
				pool_master_2_port,
				username, 
				password,
				touched_by,
				tstamp
			) 
			values
			( 
				_uuid,
				_name, 
				_description,
				_hv_type,
				_protocol,
				_enabled,
				_primary_pool_master_addr,
				_secondary_pool_master_addr,
				_primary_pool_master_port,  
				_secondary_pool_master_port,
				_username, 
				_password,
				_touched_by,
				_tstamp
			)
			returning id into _id;
		
		end if;
		
	end if;

	return _id;

END;
$$
LANGUAGE 'plpgsql';

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			June 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 19, 2010
-- Description:
--	 Add or update a record in the hv_pool_host table.
-- Parameters:
--   pool_id		- The database ID (id column of the hv_pool table) of the
--					  pool for which a host is being added of updated.
--   host_id        - The database ID (id column of the hv_host table) of the
--					  host.
-- Returns:
--   The database ID of the (hv_pool_host.id) of the pool/host record.
-- ============================================================================
DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_hv_pool_host
(
	_pool_id	int,
	_host_id	int
);

create function "WorkloadBalancing".add_update_hv_pool_host
(
	_pool_id	int,
	_host_id	int
) returns int  as $$
declare _id int := null;
begin
	select id into _id from hv_pool_host where poolid=_pool_id and hostid=_host_id;
	
	if _id is null then
	begin
		insert into hv_pool_host (poolid, hostid) values(_pool_id, _host_id) returning id into _id;
		--GET DIAGNOSTICS _id = RESULT_OID;
	end;
	end if;
	return _id;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		July 23, 2008
-- Modified for PgSQL	Oct 14, 2010
-- Description:
--	 Add or update a record in the hv_pool_threshold table.
-- Parameters:
--   MANY!
-- Returns:
--   None
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_hv_pool_threshold
(
	_pool_id int,

	--_opt_mode int,

	_host_cpu_threshold_critical decimal(9,8),
	_host_cpu_threshold_high     decimal(9,8),
	_host_cpu_threshold_medium   decimal(9,8),
	_host_cpu_threshold_low      decimal(9,8),

	_host_memory_threshold_critical bigint,
	_host_memory_threshold_high	bigint,
	_host_memory_threshold_medium	bigint,
	_host_memory_threshold_low	bigint,

	_host_net_read_threshold_critical bigint,
	_host_net_read_threshold_high	  bigint,
	_host_net_read_threshold_medium	  bigint,
	_host_net_read_threshold_low	  bigint,

	_host_net_write_threshold_critical bigint,
	_host_net_write_threshold_high     bigint,
	_host_net_write_threshold_medium   bigint,
	_host_net_write_threshold_low      bigint,

	_host_disk_read_threshold_critical bigint,
	_host_disk_read_threshold_high	   bigint,
	_host_disk_read_threshold_medium   bigint,
	_host_disk_read_threshold_low      bigint,

	_host_disk_write_threshold_critical bigint,
	_host_disk_write_threshold_high     bigint,
	_host_disk_write_threshold_medium   bigint,
	_host_disk_write_threshold_low      bigint,

	_host_load_avg_threshold_critical decimal(9,3),
	_host_load_avg_threshold_high     decimal(9,3),
	_host_load_avg_threshold_medium   decimal(9,3),
	_host_load_avg_threshold_low      decimal(9,3),

	_host_runstate_blocked_threshold_critical decimal(9,8),
	_host_runstate_blocked_threshold_high     decimal(9,8),
	_host_runstate_blocked_threshold_medium   decimal(9,8),
	_host_runstate_blocked_threshold_low      decimal(9,8),

	_host_runstate_partial_run_threshold_critical decimal(9,8),
	_host_runstate_partial_run_threshold_high     decimal(9,8),
	_host_runstate_partial_run_threshold_medium   decimal(9,8),
	_host_runstate_partial_run_threshold_low      decimal(9,8),

	_host_runstate_fullrun_threshold_critical decimal(9,8),
	_host_runstate_fullrun_threshold_high     decimal(9,8),
	_host_runstate_fullrun_threshold_medium   decimal(9,8),
	_host_runstate_fullrun_threshold_low      decimal(9,8),

	_host_runstate_partial_contention_threshold_critical decimal(9,8),
	_host_runstate_partial_contention_threshold_high     decimal(9,8),
	_host_runstate_partial_contention_threshold_medium   decimal(9,8),
	_host_runstate_partial_contention_threshold_low      decimal(9,8),

	_host_runstate_concurrency_hazard_threshold_critical decimal(9,8),
	_host_runstate_concurrency_hazard_threshold_high     decimal(9,8),
	_host_runstate_concurrency_hazard_threshold_medium   decimal(9,8),
	_host_runstate_concurrency_hazard_threshold_low      decimal(9,8),

	_host_runstate_full_contention_threshold_critical decimal(9,8),
	_host_runstate_full_contention_threshold_high     decimal(9,8),
	_host_runstate_full_contention_threshold_medium   decimal(9,8),
	_host_runstate_full_contention_threshold_low      decimal(9,8),

	_weight_current_metrics   decimal(9,8),
	_weight_last_30_metrics   decimal(9,8),
	_weight_yesterday_metrics decimal(9,8),

	--_over_commit_cpu_in_perf_mode    bit,
	--_over_commit_cpu_in_density_mode bit,

	_vm_cpu_threshold_high   decimal(9,8),
	_vm_cpu_threshold_medium decimal(9,8),
	_vm_cpu_threshold_low	 decimal(9,8),
	_vm_cpu_weight_high	 decimal(9,8),
	_vm_cpu_weight_medium	 decimal(9,8),
	_vm_cpu_weight_low	 decimal(9,8),

	_vm_memory_threshold_high   bigint,
	_vm_memory_threshold_medium bigint,
	_vm_memory_threshold_low    bigint,
	_vm_memory_weight_high      decimal(9,8),
	_vm_memory_weight_medium    decimal(9,8),
	_vm_memory_weight_low       decimal(9,8),

	_vm_net_read_threshold_high   bigint,
	_vm_net_read_threshold_medium bigint,
	_vm_net_read_threshold_low    bigint,
	_vm_net_read_weight_high      decimal(9,8),
	_vm_net_read_weight_medium    decimal(9,8),
	_vm_net_read_weight_low       decimal(9,8),

	_vm_net_write_threshold_high   bigint,
	_vm_net_write_threshold_medium bigint,
	_vm_net_write_threshold_low    bigint,
	_vm_net_write_weight_high      decimal(9,8),
	_vm_net_write_weight_medium    decimal(9,8),
	_vm_net_write_weight_low       decimal(9,8),

	_vm_disk_read_threshold_high   bigint,
	_vm_disk_read_threshold_medium bigint,
	_vm_disk_read_threshold_low    bigint,
	_vm_disk_read_weight_high      decimal(9,8),
	_vm_disk_read_weight_medium    decimal(9,8),
	_vm_disk_read_weight_low       decimal(9,8),

	_vm_disk_write_threshold_high   bigint,
	_vm_disk_write_threshold_medium bigint,
	_vm_disk_write_threshold_low    bigint,
	_vm_disk_write_weight_high      decimal(9,8),
	_vm_disk_write_weight_medium    decimal(9,8),
	_vm_disk_write_weight_low       decimal(9,8),

	_vm_runstate_weight_high	decimal(9,8),
	_vm_runstate_weight_medium	decimal(9,8),
	_vm_runstate_weight_low		decimal(9,8)
);


create function "WorkloadBalancing".add_update_hv_pool_threshold
(
	_pool_id int,

	--_opt_mode int,

	_host_cpu_threshold_critical decimal(9,8),
	_host_cpu_threshold_high     decimal(9,8),
	_host_cpu_threshold_medium   decimal(9,8),
	_host_cpu_threshold_low      decimal(9,8),

	_host_memory_threshold_critical bigint,
	_host_memory_threshold_high	bigint,
	_host_memory_threshold_medium	bigint,
	_host_memory_threshold_low	bigint,

	_host_net_read_threshold_critical bigint,
	_host_net_read_threshold_high	  bigint,
	_host_net_read_threshold_medium	  bigint,
	_host_net_read_threshold_low	  bigint,

	_host_net_write_threshold_critical bigint,
	_host_net_write_threshold_high     bigint,
	_host_net_write_threshold_medium   bigint,
	_host_net_write_threshold_low      bigint,

	_host_disk_read_threshold_critical bigint,
	_host_disk_read_threshold_high	   bigint,
	_host_disk_read_threshold_medium   bigint,
	_host_disk_read_threshold_low      bigint,

	_host_disk_write_threshold_critical bigint,
	_host_disk_write_threshold_high     bigint,
	_host_disk_write_threshold_medium   bigint,
	_host_disk_write_threshold_low      bigint,

	_host_load_avg_threshold_critical decimal(9,3),
	_host_load_avg_threshold_high     decimal(9,3),
	_host_load_avg_threshold_medium   decimal(9,3),
	_host_load_avg_threshold_low      decimal(9,3),

	_host_runstate_blocked_threshold_critical decimal(9,8),
	_host_runstate_blocked_threshold_high     decimal(9,8),
	_host_runstate_blocked_threshold_medium   decimal(9,8),
	_host_runstate_blocked_threshold_low      decimal(9,8),

	_host_runstate_partial_run_threshold_critical decimal(9,8),
	_host_runstate_partial_run_threshold_high     decimal(9,8),
	_host_runstate_partial_run_threshold_medium   decimal(9,8),
	_host_runstate_partial_run_threshold_low      decimal(9,8),

	_host_runstate_fullrun_threshold_critical decimal(9,8),
	_host_runstate_fullrun_threshold_high     decimal(9,8),
	_host_runstate_fullrun_threshold_medium   decimal(9,8),
	_host_runstate_fullrun_threshold_low      decimal(9,8),

	_host_runstate_partial_contention_threshold_critical decimal(9,8),
	_host_runstate_partial_contention_threshold_high     decimal(9,8),
	_host_runstate_partial_contention_threshold_medium   decimal(9,8),
	_host_runstate_partial_contention_threshold_low      decimal(9,8),

	_host_runstate_concurrency_hazard_threshold_critical decimal(9,8),
	_host_runstate_concurrency_hazard_threshold_high     decimal(9,8),
	_host_runstate_concurrency_hazard_threshold_medium   decimal(9,8),
	_host_runstate_concurrency_hazard_threshold_low      decimal(9,8),

	_host_runstate_full_contention_threshold_critical decimal(9,8),
	_host_runstate_full_contention_threshold_high     decimal(9,8),
	_host_runstate_full_contention_threshold_medium   decimal(9,8),
	_host_runstate_full_contention_threshold_low      decimal(9,8),

	_weight_current_metrics   decimal(9,8),
	_weight_last_30_metrics   decimal(9,8),
	_weight_yesterday_metrics decimal(9,8),

	--_over_commit_cpu_in_perf_mode    bit,
	--_over_commit_cpu_in_density_mode bit,

	_vm_cpu_threshold_high   decimal(9,8),
	_vm_cpu_threshold_medium decimal(9,8),
	_vm_cpu_threshold_low	 decimal(9,8),
	_vm_cpu_weight_high	 decimal(9,8),
	_vm_cpu_weight_medium	 decimal(9,8),
	_vm_cpu_weight_low	 decimal(9,8),

	_vm_memory_threshold_high   bigint,
	_vm_memory_threshold_medium bigint,
	_vm_memory_threshold_low    bigint,
	_vm_memory_weight_high      decimal(9,8),
	_vm_memory_weight_medium    decimal(9,8),
	_vm_memory_weight_low       decimal(9,8),

	_vm_net_read_threshold_high   bigint,
	_vm_net_read_threshold_medium bigint,
	_vm_net_read_threshold_low    bigint,
	_vm_net_read_weight_high      decimal(9,8),
	_vm_net_read_weight_medium    decimal(9,8),
	_vm_net_read_weight_low       decimal(9,8),

	_vm_net_write_threshold_high   bigint,
	_vm_net_write_threshold_medium bigint,
	_vm_net_write_threshold_low    bigint,
	_vm_net_write_weight_high      decimal(9,8),
	_vm_net_write_weight_medium    decimal(9,8),
	_vm_net_write_weight_low       decimal(9,8),

	_vm_disk_read_threshold_high   bigint,
	_vm_disk_read_threshold_medium bigint,
	_vm_disk_read_threshold_low    bigint,
	_vm_disk_read_weight_high      decimal(9,8),
	_vm_disk_read_weight_medium    decimal(9,8),
	_vm_disk_read_weight_low       decimal(9,8),

	_vm_disk_write_threshold_high   bigint,
	_vm_disk_write_threshold_medium bigint,
	_vm_disk_write_threshold_low    bigint,
	_vm_disk_write_weight_high      decimal(9,8),
	_vm_disk_write_weight_medium    decimal(9,8),
	_vm_disk_write_weight_low       decimal(9,8),

	_vm_runstate_weight_high	decimal(9,8),
	_vm_runstate_weight_medium	decimal(9,8),
	_vm_runstate_weight_low		decimal(9,8)
)
returns void as $$

declare
	_id int := null;
	_current_date timestamp := getutcdate();
	
begin
	select id into _id from hv_pool_threshold where pool_id=_pool_id;

	if _id is null then
	-- if starts here
		insert into hv_pool_threshold(
				pool_id,

				--opt_mode,

				host_cpu_threshold_critical,
				host_cpu_threshold_high,
				host_cpu_threshold_medium,
				host_cpu_threshold_low,

				host_memory_threshold_critical,
				host_memory_threshold_high,
				host_memory_threshold_medium,
				host_memory_threshold_low,

				host_net_read_threshold_critical,
				host_net_read_threshold_high,
				host_net_read_threshold_medium,
				host_net_read_threshold_low,

				host_net_write_threshold_critical,
				host_net_write_threshold_high,
				host_net_write_threshold_medium,
				host_net_write_threshold_low,

				host_disk_read_threshold_critical,
				host_disk_read_threshold_high,
				host_disk_read_threshold_medium,
				host_disk_read_threshold_low,

				host_disk_write_threshold_critical,
				host_disk_write_threshold_high,
				host_disk_write_threshold_medium,
				host_disk_write_threshold_low,

				host_load_avg_threshold_critical,
				host_load_avg_threshold_high,
				host_load_avg_threshold_medium,
				host_load_avg_threshold_low,

				host_runstate_blocked_threshold_critical,
				host_runstate_blocked_threshold_high,
				host_runstate_blocked_threshold_medium,
				host_runstate_blocked_threshold_low,
				
				host_runstate_partial_run_threshold_critical,
				host_runstate_partial_run_threshold_high,
				host_runstate_partial_run_threshold_medium,
				host_runstate_partial_run_threshold_low,

				host_runstate_fullrun_threshold_critical,
				host_runstate_fullrun_threshold_high,
				host_runstate_fullrun_threshold_medium,
				host_runstate_fullrun_threshold_low,

				host_runstate_partial_contention_threshold_critical,
				host_runstate_partial_contention_threshold_high,
				host_runstate_partial_contention_threshold_medium,
				host_runstate_partial_contention_threshold_low,

				host_runstate_concurrency_hazard_threshold_critical,
				host_runstate_concurrency_hazard_threshold_high,
				host_runstate_concurrency_hazard_threshold_medium,
				host_runstate_concurrency_hazard_threshold_low,

				host_runstate_full_contention_threshold_critical,
				host_runstate_full_contention_threshold_high,
				host_runstate_full_contention_threshold_medium,
				host_runstate_full_contention_threshold_low,

				weight_current_metrics,
				weight_last_30_metrics,
				weight_yesterday_metrics,

				--over_commit_cpu_in_perf_mode,
				--over_commit_cpu_in_density_mode,

				vm_cpu_threshold_high,
				vm_cpu_threshold_medium,
				vm_cpu_threshold_low,
				vm_cpu_weight_high,
				vm_cpu_weight_medium,
				vm_cpu_weight_low,

				vm_memory_threshold_high,
				vm_memory_threshold_medium,
				vm_memory_threshold_low,
				vm_memory_weight_high,
				vm_memory_weight_medium,
				vm_memory_weight_low,

				vm_net_read_threshold_high,
				vm_net_read_threshold_medium,
				vm_net_read_threshold_low,
				vm_net_read_weight_high,
				vm_net_read_weight_medium,
				vm_net_read_weight_low,

				vm_net_write_threshold_high,
				vm_net_write_threshold_medium,
				vm_net_write_threshold_low,
				vm_net_write_weight_high,
				vm_net_write_weight_medium,
				vm_net_write_weight_low,

				vm_disk_read_threshold_high,
				vm_disk_read_threshold_medium,
				vm_disk_read_threshold_low,
				vm_disk_read_weight_high,
				vm_disk_read_weight_medium,
				vm_disk_read_weight_low,

				vm_disk_write_threshold_high,
				vm_disk_write_threshold_medium,
				vm_disk_write_threshold_low,
				vm_disk_write_weight_high,
				vm_disk_write_weight_medium,
				vm_disk_write_weight_low,

				vm_runstate_weight_high,
				vm_runstate_weight_medium,
				vm_runstate_weight_low)
			values(_pool_id,

				--_opt_mode,

				_host_cpu_threshold_critical,
				_host_cpu_threshold_high,
				_host_cpu_threshold_medium,
				_host_cpu_threshold_low,

				_host_memory_threshold_critical,
				_host_memory_threshold_high,
				_host_memory_threshold_medium,
				_host_memory_threshold_low,

				_host_net_read_threshold_critical,
				_host_net_read_threshold_high,
				_host_net_read_threshold_medium,
				_host_net_read_threshold_low,

				_host_net_write_threshold_critical,
				_host_net_write_threshold_high,
				_host_net_write_threshold_medium,
				_host_net_write_threshold_low,

				_host_disk_read_threshold_critical,
				_host_disk_read_threshold_high,
				_host_disk_read_threshold_medium,
				_host_disk_read_threshold_low,

				_host_disk_write_threshold_critical,
				_host_disk_write_threshold_high,
				_host_disk_write_threshold_medium,
				_host_disk_write_threshold_low,

				_host_load_avg_threshold_critical,
				_host_load_avg_threshold_high,
				_host_load_avg_threshold_medium,
				_host_load_avg_threshold_low,

				_host_runstate_blocked_threshold_critical,
				_host_runstate_blocked_threshold_high,
				_host_runstate_blocked_threshold_medium,
				_host_runstate_blocked_threshold_low,

				_host_runstate_partial_run_threshold_critical,
				_host_runstate_partial_run_threshold_high,
				_host_runstate_partial_run_threshold_medium,
				_host_runstate_partial_run_threshold_low,

				_host_runstate_fullrun_threshold_critical,
				_host_runstate_fullrun_threshold_high,
				_host_runstate_fullrun_threshold_medium,
				_host_runstate_fullrun_threshold_low,

				_host_runstate_partial_contention_threshold_critical,
				_host_runstate_partial_contention_threshold_high,
				_host_runstate_partial_contention_threshold_medium,
				_host_runstate_partial_contention_threshold_low,

				_host_runstate_concurrency_hazard_threshold_critical,
				_host_runstate_concurrency_hazard_threshold_high,
				_host_runstate_concurrency_hazard_threshold_medium,
				_host_runstate_concurrency_hazard_threshold_low,

				_host_runstate_full_contention_threshold_critical,
				_host_runstate_full_contention_threshold_high,
				_host_runstate_full_contention_threshold_medium,
				_host_runstate_full_contention_threshold_low,

				_weight_current_metrics,
				_weight_last_30_metrics,
				_weight_yesterday_metrics,

				--_over_commit_cpu_in_perf_mode,
				--_over_commit_cpu_in_density_mode,

				_vm_cpu_threshold_high,
				_vm_cpu_threshold_medium,
				_vm_cpu_threshold_low,
				_vm_cpu_weight_high,
				_vm_cpu_weight_medium,
				_vm_cpu_weight_low,

				_vm_memory_threshold_high,
				_vm_memory_threshold_medium,
				_vm_memory_threshold_low,
				_vm_memory_weight_high,
				_vm_memory_weight_medium,
				_vm_memory_weight_low,

				_vm_net_read_threshold_high,
				_vm_net_read_threshold_medium,
				_vm_net_read_threshold_low,
				_vm_net_read_weight_high,
				_vm_net_read_weight_medium,
				_vm_net_read_weight_low,

				_vm_net_write_threshold_high,
				_vm_net_write_threshold_medium,
				_vm_net_write_threshold_low,
				_vm_net_write_weight_high,
				_vm_net_write_weight_medium,
				_vm_net_write_weight_low,

				_vm_disk_read_threshold_high,
				_vm_disk_read_threshold_medium,
				_vm_disk_read_threshold_low,
				_vm_disk_read_weight_high,
				_vm_disk_read_weight_medium,
				_vm_disk_read_weight_low,

				_vm_disk_write_threshold_high,
				_vm_disk_write_threshold_medium,
				_vm_disk_write_threshold_low,
				_vm_disk_write_weight_high,
				_vm_disk_write_weight_medium,
				_vm_disk_write_weight_low,
		
				_vm_runstate_weight_high,
				_vm_runstate_weight_medium,
				_vm_runstate_weight_low) returning id into _id;
				
				-- Insert the default 'other config' for this pool.
				insert into hv_pool_config (pool_id,
							   name,
							   value, 
							   default_value,
							   description,
							   tstamp)
					   (select _pool_id as pool_id, 
							   name,
							   value,
							   default_value, 
							   description,
							   getutcdate() as tstamp
						  from hv_pool_config 
						 where pool_id is null);
	-- if 
	-- else starts here
	else
		update hv_pool_threshold 
			   set  --opt_mode = _opt_mode,
 
				host_cpu_threshold_critical = _host_cpu_threshold_critical,
				host_cpu_threshold_high     = _host_cpu_threshold_high,
				host_cpu_threshold_medium   = _host_cpu_threshold_medium,
				host_cpu_threshold_low      = _host_cpu_threshold_low,

				host_memory_threshold_critical = _host_memory_threshold_critical,
				host_memory_threshold_high     = _host_memory_threshold_high,
				host_memory_threshold_medium   = _host_memory_threshold_medium,
				host_memory_threshold_low      = _host_memory_threshold_low,

				host_net_read_threshold_critical = _host_net_read_threshold_critical,
				host_net_read_threshold_high     = _host_net_read_threshold_high,
				host_net_read_threshold_medium   = _host_net_read_threshold_medium,
				host_net_read_threshold_low      = _host_net_read_threshold_low,

				host_net_write_threshold_critical = _host_net_write_threshold_critical,
				host_net_write_threshold_high     = _host_net_write_threshold_high,
				host_net_write_threshold_medium   = _host_net_write_threshold_medium,
				host_net_write_threshold_low      = _host_net_write_threshold_low,

				host_disk_read_threshold_critical = _host_disk_read_threshold_critical,
				host_disk_read_threshold_high     = _host_disk_read_threshold_high,
				host_disk_read_threshold_medium   = _host_disk_read_threshold_medium,
				host_disk_read_threshold_low      = _host_disk_read_threshold_low,

				host_disk_write_threshold_critical = _host_disk_write_threshold_critical,
				host_disk_write_threshold_high     = _host_disk_write_threshold_high,
				host_disk_write_threshold_medium   = _host_disk_write_threshold_medium,
				host_disk_write_threshold_low      = _host_disk_write_threshold_low,

				host_load_avg_threshold_critical  = _host_load_avg_threshold_critical,
				host_load_avg_threshold_high      = _host_load_avg_threshold_high,
				host_load_avg_threshold_medium    = _host_load_avg_threshold_medium,
				host_load_avg_threshold_low       = _host_load_avg_threshold_low,

				host_runstate_blocked_threshold_critical = _host_runstate_blocked_threshold_critical,
				host_runstate_blocked_threshold_high     = _host_runstate_blocked_threshold_high,
				host_runstate_blocked_threshold_medium   = _host_runstate_blocked_threshold_medium,
				host_runstate_blocked_threshold_low      = _host_runstate_blocked_threshold_low,
				
				host_runstate_partial_run_threshold_critical = _host_runstate_partial_run_threshold_critical,
				host_runstate_partial_run_threshold_high     = _host_runstate_partial_run_threshold_high,
				host_runstate_partial_run_threshold_medium   = _host_runstate_partial_run_threshold_medium,
				host_runstate_partial_run_threshold_low      = _host_runstate_partial_run_threshold_low,

				host_runstate_fullrun_threshold_critical = _host_runstate_fullrun_threshold_critical,
				host_runstate_fullrun_threshold_high     = _host_runstate_fullrun_threshold_high,
				host_runstate_fullrun_threshold_medium   = _host_runstate_fullrun_threshold_medium,
				host_runstate_fullrun_threshold_low      = _host_runstate_fullrun_threshold_low,

				host_runstate_partial_contention_threshold_critical = _host_runstate_partial_contention_threshold_critical,
				host_runstate_partial_contention_threshold_high     = _host_runstate_partial_contention_threshold_high,
				host_runstate_partial_contention_threshold_medium   = _host_runstate_partial_contention_threshold_medium,
				host_runstate_partial_contention_threshold_low      = _host_runstate_partial_contention_threshold_low,

				host_runstate_concurrency_hazard_threshold_critical = _host_runstate_concurrency_hazard_threshold_critical,
				host_runstate_concurrency_hazard_threshold_high     = _host_runstate_concurrency_hazard_threshold_high,
				host_runstate_concurrency_hazard_threshold_medium   = _host_runstate_concurrency_hazard_threshold_medium,
				host_runstate_concurrency_hazard_threshold_low      = _host_runstate_concurrency_hazard_threshold_low,

				host_runstate_full_contention_threshold_critical = _host_runstate_full_contention_threshold_critical,
				host_runstate_full_contention_threshold_high     = _host_runstate_full_contention_threshold_high,
				host_runstate_full_contention_threshold_medium   = _host_runstate_full_contention_threshold_medium,
				host_runstate_full_contention_threshold_low      = _host_runstate_full_contention_threshold_low,

				weight_current_metrics   = _weight_current_metrics,
				weight_last_30_metrics   = _weight_last_30_metrics,
				weight_yesterday_metrics = _weight_yesterday_metrics,

				--over_commit_cpu_in_perf_mode    = _over_commit_cpu_in_perf_mode,
				--over_commit_cpu_in_density_mode = _over_commit_cpu_in_density_mode,

				vm_cpu_threshold_high    = _vm_cpu_threshold_high,
				vm_cpu_threshold_medium  = _vm_cpu_threshold_medium,
				vm_cpu_threshold_low     = _vm_cpu_threshold_low,
				vm_cpu_weight_high       = _vm_cpu_weight_high,
				vm_cpu_weight_medium     = _vm_cpu_weight_medium,
				vm_cpu_weight_low        = _vm_cpu_weight_low,

				vm_memory_threshold_high   = _vm_memory_threshold_high,
				vm_memory_threshold_medium = _vm_memory_threshold_medium,
				vm_memory_threshold_low    = _vm_memory_threshold_low,
				vm_memory_weight_high      = _vm_memory_weight_high,
				vm_memory_weight_medium    = _vm_memory_weight_medium,
				vm_memory_weight_low       = _vm_memory_weight_low,

				vm_net_read_threshold_high   = _vm_net_read_threshold_high,
				vm_net_read_threshold_medium = _vm_net_read_threshold_medium,
				vm_net_read_threshold_low    = _vm_net_read_threshold_low,
				vm_net_read_weight_high      = _vm_net_read_weight_high,
				vm_net_read_weight_medium    = _vm_net_read_weight_medium,
				vm_net_read_weight_low       = _vm_net_read_weight_low,

				vm_net_write_threshold_high   = _vm_net_write_threshold_high,
				vm_net_write_threshold_medium = _vm_net_write_threshold_medium,
				vm_net_write_threshold_low    = _vm_net_write_threshold_low,
				vm_net_write_weight_high      = _vm_net_write_weight_high,
				vm_net_write_weight_medium    = _vm_net_write_weight_medium,
				vm_net_write_weight_low       = _vm_net_write_weight_low,

				vm_disk_read_threshold_high   = _vm_disk_read_threshold_high,
				vm_disk_read_threshold_medium = _vm_disk_read_threshold_medium,
				vm_disk_read_threshold_low    = _vm_disk_read_threshold_low,
				vm_disk_read_weight_high      = _vm_disk_read_weight_high,
				vm_disk_read_weight_medium    = _vm_disk_read_weight_medium,
				vm_disk_read_weight_low       = _vm_disk_read_weight_low,

				vm_disk_write_threshold_high   = _vm_disk_write_threshold_high,
				vm_disk_write_threshold_medium = _vm_disk_write_threshold_medium,
				vm_disk_write_threshold_low    = _vm_disk_write_threshold_low,
				vm_disk_write_weight_high      = _vm_disk_write_weight_high,
				vm_disk_write_weight_medium    = _vm_disk_write_weight_medium,
				vm_disk_write_weight_low       = _vm_disk_write_weight_low,

				vm_runstate_weight_high		   = _vm_runstate_weight_high,
				vm_runstate_weight_medium      = _vm_runstate_weight_medium,
				vm_runstate_weight_low         = _vm_runstate_weight_low
					
			where pool_id=_pool_id;
			
			update hv_pool_threshold_history set config_end_date = current_timestamp
			where config_start_date = (select config_start_date from hv_pool_threshold_history
										where pool_id = _pool_id
										and id = _id order by config_start_date desc limit 1)
				and pool_id = _pool_id
				and id = _id;
	--end if
	end if;

	-- Create an audit history for this event
	insert into hv_pool_threshold_history
	(
		id,
		pool_id,

		--opt_mode,

		host_cpu_threshold_critical,
		host_cpu_threshold_high,
		host_cpu_threshold_medium,
		host_cpu_threshold_low,

		host_memory_threshold_critical,
		host_memory_threshold_high,
		host_memory_threshold_medium,
		host_memory_threshold_low,

		host_net_read_threshold_critical,
		host_net_read_threshold_high,
		host_net_read_threshold_medium,
		host_net_read_threshold_low,

		host_net_write_threshold_critical,
		host_net_write_threshold_high,
		host_net_write_threshold_medium,
		host_net_write_threshold_low,

		host_disk_read_threshold_critical,
		host_disk_read_threshold_high,
		host_disk_read_threshold_medium,
		host_disk_read_threshold_low,

		host_disk_write_threshold_critical,
		host_disk_write_threshold_high,
		host_disk_write_threshold_medium,
		host_disk_write_threshold_low,

		host_load_avg_threshold_critical,
		host_load_avg_threshold_high,
		host_load_avg_threshold_medium,
		host_load_avg_threshold_low,

		host_runstate_blocked_threshold_critical,
		host_runstate_blocked_threshold_high,
		host_runstate_blocked_threshold_medium,
		host_runstate_blocked_threshold_low,
		
		host_runstate_partial_run_threshold_critical,
		host_runstate_partial_run_threshold_high,
		host_runstate_partial_run_threshold_medium,
		host_runstate_partial_run_threshold_low,

		host_runstate_fullrun_threshold_critical,
		host_runstate_fullrun_threshold_high,
		host_runstate_fullrun_threshold_medium,
		host_runstate_fullrun_threshold_low,

		host_runstate_partial_contention_threshold_critical,
		host_runstate_partial_contention_threshold_high,
		host_runstate_partial_contention_threshold_medium,
		host_runstate_partial_contention_threshold_low,

		host_runstate_concurrency_hazard_threshold_critical,
		host_runstate_concurrency_hazard_threshold_high,
		host_runstate_concurrency_hazard_threshold_medium,
		host_runstate_concurrency_hazard_threshold_low,

		host_runstate_full_contention_threshold_critical,
		host_runstate_full_contention_threshold_high,
		host_runstate_full_contention_threshold_medium,
		host_runstate_full_contention_threshold_low,

		weight_current_metrics,
		weight_last_30_metrics,
		weight_yesterday_metrics,

		--over_commit_cpu_in_perf_mode,
		--over_commit_cpu_in_density_mode,

		vm_cpu_threshold_high,
		vm_cpu_threshold_medium,
		vm_cpu_threshold_low,
		vm_cpu_weight_high,
		vm_cpu_weight_medium,
		vm_cpu_weight_low,

		vm_memory_threshold_high,
		vm_memory_threshold_medium,
		vm_memory_threshold_low,
		vm_memory_weight_high,
		vm_memory_weight_medium,
		vm_memory_weight_low,

		vm_net_read_threshold_high,
		vm_net_read_threshold_medium,
		vm_net_read_threshold_low,
		vm_net_read_weight_high,
		vm_net_read_weight_medium,
		vm_net_read_weight_low,

		vm_net_write_threshold_high,
		vm_net_write_threshold_medium,
		vm_net_write_threshold_low,
		vm_net_write_weight_high,
		vm_net_write_weight_medium,
		vm_net_write_weight_low,

		vm_disk_read_threshold_high,
		vm_disk_read_threshold_medium,
		vm_disk_read_threshold_low,
		vm_disk_read_weight_high,
		vm_disk_read_weight_medium,
		vm_disk_read_weight_low,

		vm_disk_write_threshold_high,
		vm_disk_write_threshold_medium,
		vm_disk_write_threshold_low,
		vm_disk_write_weight_high,
		vm_disk_write_weight_medium,
		vm_disk_write_weight_low,

		vm_runstate_weight_high,
		vm_runstate_weight_medium,
		vm_runstate_weight_low,

		config_start_date,
		config_end_date

	)			
	values
	(
		_id,						 
		_pool_id,

		--_opt_mode,

		_host_cpu_threshold_critical,
		_host_cpu_threshold_high,
		_host_cpu_threshold_medium,
		_host_cpu_threshold_low,

		_host_memory_threshold_critical,
		_host_memory_threshold_high,
		_host_memory_threshold_medium,
		_host_memory_threshold_low,

		_host_net_read_threshold_critical,
		_host_net_read_threshold_high,
		_host_net_read_threshold_medium,
		_host_net_read_threshold_low,

		_host_net_write_threshold_critical,
		_host_net_write_threshold_high,
		_host_net_write_threshold_medium,
		_host_net_write_threshold_low,

		_host_disk_read_threshold_critical,
		_host_disk_read_threshold_high,
		_host_disk_read_threshold_medium,
		_host_disk_read_threshold_low,

		_host_disk_write_threshold_critical,
		_host_disk_write_threshold_high,
		_host_disk_write_threshold_medium,
		_host_disk_write_threshold_low,

		_host_load_avg_threshold_critical,
		_host_load_avg_threshold_high,
		_host_load_avg_threshold_medium,
		_host_load_avg_threshold_low,

		_host_runstate_blocked_threshold_critical,
		_host_runstate_blocked_threshold_high,
		_host_runstate_blocked_threshold_medium,
		_host_runstate_blocked_threshold_low,

		_host_runstate_partial_run_threshold_critical,
		_host_runstate_partial_run_threshold_high,
		_host_runstate_partial_run_threshold_medium,
		_host_runstate_partial_run_threshold_low,

		_host_runstate_fullrun_threshold_critical,
		_host_runstate_fullrun_threshold_high,
		_host_runstate_fullrun_threshold_medium,
		_host_runstate_fullrun_threshold_low,

		_host_runstate_partial_contention_threshold_critical,
		_host_runstate_partial_contention_threshold_high,
		_host_runstate_partial_contention_threshold_medium,
		_host_runstate_partial_contention_threshold_low,

		_host_runstate_concurrency_hazard_threshold_critical,
		_host_runstate_concurrency_hazard_threshold_high,
		_host_runstate_concurrency_hazard_threshold_medium,
		_host_runstate_concurrency_hazard_threshold_low,

		_host_runstate_full_contention_threshold_critical,
		_host_runstate_full_contention_threshold_high,
		_host_runstate_full_contention_threshold_medium,
		_host_runstate_full_contention_threshold_low,

		_weight_current_metrics,
		_weight_last_30_metrics,
		_weight_yesterday_metrics,

		--_over_commit_cpu_in_perf_mode,
		--_over_commit_cpu_in_density_mode,

		_vm_cpu_threshold_high,
		_vm_cpu_threshold_medium,
		_vm_cpu_threshold_low,
		_vm_cpu_weight_high,
		_vm_cpu_weight_medium,
		_vm_cpu_weight_low,

		_vm_memory_threshold_high,
		_vm_memory_threshold_medium,
		_vm_memory_threshold_low,
		_vm_memory_weight_high,
		_vm_memory_weight_medium,
		_vm_memory_weight_low,

		_vm_net_read_threshold_high,
		_vm_net_read_threshold_medium,
		_vm_net_read_threshold_low,
		_vm_net_read_weight_high,
		_vm_net_read_weight_medium,
		_vm_net_read_weight_low,

		_vm_net_write_threshold_high,
		_vm_net_write_threshold_medium,
		_vm_net_write_threshold_low,
		_vm_net_write_weight_high,
		_vm_net_write_weight_medium,
		_vm_net_write_weight_low,

		_vm_disk_read_threshold_high,
		_vm_disk_read_threshold_medium,
		_vm_disk_read_threshold_low,
		_vm_disk_read_weight_high,
		_vm_disk_read_weight_medium,
		_vm_disk_read_weight_low,

		_vm_disk_write_threshold_high,
		_vm_disk_write_threshold_medium,
		_vm_disk_write_threshold_low,
		_vm_disk_write_weight_high,
		_vm_disk_write_weight_medium,
		_vm_disk_write_weight_low,

		_vm_runstate_weight_high,
		_vm_runstate_weight_medium,
		_vm_runstate_weight_low,

		current_timestamp,
		null
	);
	
end;

$$ language plpgsql;










-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			July 10, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 18, 2010
-- Description:
--	 Add or update a record in the hv_network table.
-- Parameters:
--   uuid        - The unique ID of the network.
--   name        - The friendly name of the network.
--   pool_id     - The database ID (id column of the hv_pool table) of the pool
--                 to which the network belongs.
--   description - A description of the network.
--   bridge      - The name of the bridge associated with the network.
--   tstamp      - UTC date and time stamp the network was discovered.
-- Returns:
--   The database ID (id column of the hv_network table) of the network that
--   was added or updated.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_network
(
	_uuid		varchar(48),
	_name		varchar(256),
	_pool_id	int,
	_description	varchar(256),
	_bridge      	varchar(256),
	_tstamp		timestamp
);

create function "WorkloadBalancing".add_update_network
(
	_uuid		varchar(48),
	_name		varchar(256),
	_pool_id	int,
	_description	varchar(256),
	_bridge      	varchar(256),
	_tstamp		timestamp
) returns int 
as $$

declare _id int;
	
begin
	select id into _id from hv_network where uuid=_uuid and poolid=_pool_id;

	if _id is not null then
		update hv_network
			set name=_name, 
			    description=_description,
			    bridge=_bridge
			where id=_id;
	else
		insert into hv_network (uuid, name,
			poolid,
			description,
			bridge,
			tstamp)
		   values (_uuid,
			_name,
			_pool_id,
			_description,
			_bridge,
			_tstamp);
	end if;

	select id into _id from hv_network where uuid=_uuid and poolid=_pool_id;
	return _id;
end;

$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			June 24, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 18, 2010
-- Description:
--	 Add or update a record in the hv_pbd table.
-- Parameters:
--   id          - The database ID (id column of the hv_pbd table) of the 
--                 physical block device.
--   uuid        - The unique ID of the physical block device.
--   name        - The friendly name of the physical block device.
--   pool_id     - The database ID (id column of the hv_pool table) of the 
--                 pool to which the phycical interface belongs.
--   description - A description of the physical block device.
--   sr_id       - The database ID (id column of the storage_respository table)
--                 of the storage repository to which the physical block device
--                 is attached.  If this parameter is not specified, the sr_uuid
--                 parameter must be specified.
--   sr_uuid     - The unique ID of the storage repository to which the physical
--                 block device is attached.  If this parameter is not specified, 
--				   the sr_id parameter must be specified.
--   tstamp      - UTC date and time stamp the physical block device was
--                 discovered.
-- Returns:
--   The database ID (id column of the hv_pbd table) of the physical block 
--   device that was added or updated.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_pbd
(
	_id		int,
	_uuid		varchar(48), 	
	_name		varchar(256),
	_pool_id     	int,
	_description 	varchar(256),
	_sr_id		int,
	_sr_uuid	varchar(48),
	_tstamp		timestamp
);

create function "WorkloadBalancing".add_update_pbd
(
	_id		int,
	_uuid		varchar(48), 	
	_name		varchar(256),
	_pool_id     	int,
	_description 	varchar(256),
	_sr_id		int,
	_sr_uuid	varchar(48),
	_tstamp		timestamp
) returns int as $$

begin

	-- Make sure we have the DB ID for the PBD.
	if _id is null then
		select id into _id from hv_pbd where uuid=_uuid and poolid=_pool_id;
	end if;

	-- Make sure we have the DB ID for the Storage Repository.
	if _sr_id is null then
		begin
			if _sr_uuid is not null then
				select id into _sr_id from storage_repository where uuid=_sr_uuid and poolid=_pool_id;
			
			else
				raise exception 'The Storage Repository ID or UUID must be specified';
			end if;
		end;
	end if;
	
	if _id is not null then
		begin
			update hv_pbd
				set name=_name, 
				description=_description,
				srid=_sr_id,
				tstamp=_tstamp 
			where id=_id;

			return _id;
		end;
	else
		begin
			insert into hv_pbd (uuid,
				name,
				poolid,
				description,
				srid,
				tstamp)
			  values(_uuid,
				_name,
				_pool_id,
				_description,
				_sr_id,
				_tstamp);

			select id into _id from hv_pbd where uuid=_uuid and poolid=_pool_id;
			return _id;
		end;
	end if;

	return _id;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			June 24, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Add or update a record in the hv_pif table.
-- Parameters:
--   uuid                    - The unique ID of the physical interface.
--   name                    - The friendly name of the physical interface
--   pool_id                 - The database ID (id column of the hv_pool table) of 
--                             the pool to which the physical interface belongs.
--   network_id              - The database ID (id column of the hv_network table)
--                             of the network associated with the physical interface.
--   description             - A description of the physical interface.
--   mac_address             - The media access control address associated 
--                             with the physical network interface.
--   is_management_interface - Flag that indicated if the physical interface is 
--                             the management interface for the host in which 
--                             it resides
--   is_physical             - Flag that indicated if the physical interface is 
--                             physical or a VLAN.
--   tstamp                  - UTC date and time stamp the physical interface was
--                             discovered.
-- Returns:
--   The database ID (id column of the hv_pif table) of the physical interface 
--   that was added or updated.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_pif
(
	_uuid		    	varchar(48), 	
	_name		        varchar(256),
	_pool_id	        int,
	_network_id             int,
	_description            varchar(256),
	_mac_address             varchar(64),
	_is_management_interface boolean,
	_is_physical             boolean,	
	_tstamp		         timestamp
);

create function "WorkloadBalancing".add_update_pif
(
	_uuid		    	varchar(48), 	
	_name		        varchar(256),
	_pool_id	        int,
	_network_id             int,
	_description            varchar(256),
	_mac_address             varchar(64),
	_is_management_interface boolean,
	_is_physical             boolean,	
	_tstamp		         timestamp
) returns int as $$
declare 
	_id int;
begin
	
	select id into _id from hv_pif where uuid=_uuid and poolid=_pool_id;

	if _id is not null then
		update hv_pif
		   set name=_name, 
		   description=_description,
		   mac_address=_mac_address,
		   is_management_interface=_is_management_interface,
		   is_physical=_is_physical
		where id=_id;
		
	else
		insert into hv_pif (uuid,
		   name,
		   poolid,
		   networkid,
		   description,	
		   mac_address,
		   is_management_interface,
		   is_physical,
		   tstamp)
		values (_uuid,
		   _name,
		   _pool_id,
		   _network_id,
		   _description,
		   _mac_address,
		   _is_management_interface,
		   _is_physical,
		   _tstamp);
	end if;

	select id into _id from hv_pif where uuid=_uuid and poolid=_pool_id;
	return _id;
end;
$$ language plpgsql;

-- ========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Create date: 		July 1, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:	
--	 Add or update information about a storage repository in the 
--   storage_repository table.
-- Parameters:
--	 _uuid		- The unique identifier of the storage repository.
--	 _name	    - The name of the storage repository.
--   pool_id    - The database ID (id column of the hv_pool table) of the 
--                pool to which the storage repository belongs.
--	 _size      - The size, in bytes, of the storage repository.
--	 _used  	- The number of bytes in the storage repository that are
--				  being used.
-- Returns:
--   The ID column for the storage_repository table representing the
--   storage repository that was added or updated.
-- ========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_storage_repository
(
	_uuid			varchar(48),
	_name       		varchar(256),
	_pool_id    		int,
	_size			bigint,
	_used			bigint,
	_pool_default_sr 	bool
);

create function "WorkloadBalancing".add_update_storage_repository
(
	_uuid			varchar(48),
	_name       		varchar(256),
	_pool_id    		int,
	_size			bigint,
	_used			bigint,
	_pool_default_sr 	bool
) returns int as $$
declare
	_id int := null;
begin
	
	select id into _id from storage_repository where uuid=_uuid and poolid=_pool_id;
	if _id is not null then
		update storage_repository 
			set name=_name,
			size=_size,
			used=_used,
			pool_default_sr = _pool_default_sr
		where id=_id;

		return _id;
	
	else
		insert into storage_repository (uuid, 
		   name,
		   poolid,
		   size,
		   used,
		   pool_default_sr)
		values(_uuid,
		   _name,
		   _pool_id,
		   _size,
		   _used,
		   _pool_default_sr);
	end if;
	select id into _id from storage_repository where uuid=_uuid and poolid=_pool_id;
	return _id;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			June 24, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Add or update a record in the vbd table.
-- Parameters:
--   id          - The database ID (id column of the vbd table) of the 
--                 virtual block device.
--   uuid        - The unique ID of the virtual block device.
--   name        - The friendly name of the virtual block device.
--   pool_id     - The database ID (id column of the hv_pool table) of the 
--                 pool to which the virtual block device belongs.
--   sr_id       - The database ID (id column of the storage_respository table)
--                 of the storage repository to which the virtual block device
--                 is attached.  If this parameter is not specified, the sr_uuid
--                 parameter must be specified.
--   sr_uuid     - The unique ID of the storage repository to which the virtual
--                 block device is attached.  If this parameter is not specified, 
--				   the sr_id parameter must be specified.
--   size        - The size, in bytes of the virtual block device.
--   used        - The number of bytes of the virtual block device that are being
--                 used.
--  device_name  - The name of the device represented by this virtual block
--                 device (hda->first IDE device, hdb->second IDE device, etc)
--  disk_type    - The type of disk represented by this virtual block
--                 device.  0=CD, 1=Disk, 2=Unknown.
--  disk_number  - The number of disk represented by this virtual block
--                 device (hda = disk 0, hdb - disk 1, etc).
-- Returns:
--   The database ID (id column of the vbd table) of the virtual block device
--   that was added or updated.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_vbd
(
	_id		int,
	_uuid		varchar(48), 	
	_name		varchar(256),
	_pool_id	int,
	_sr_id		int,
	_sr_uuid	varchar(48),
	_size		bigint,
	_used		bigint,
	_device_name 	varchar(256),
	_disk_type   int,
	_disk_number int
);

create function "WorkloadBalancing".add_update_vbd
(
	_id		int,
	_uuid		varchar(48), 	
	_name		varchar(256),
	_pool_id	int,
	_sr_id		int,
	_sr_uuid	varchar(48),
	_size		bigint,
	_used		bigint,
	_device_name 	varchar(256),
	_disk_type   int,
	_disk_number int
) returns int as $$

begin
	-- Make sure we have the DB ID for the VBD.
	if _id is null then
		select id into _id from vbd where uuid=_uuid and poolid=_pool_id;
	end if;

	-- Make sure we have the DB ID for the Storage Repository.
	if _sr_id is null then
		if _sr_uuid is not null then
			select id into _sr_id from storage_repository where uuid=_sr_uuid and poolid=_pool_id;
		end if;
	end if;
	
	if _id is not null then
		update vbd
			set name=_name, 
			srid=_sr_id,
			size=_size,
			used=_used,
			device_name=_device_name,
			disk_type=_disk_type,
			disk_number=_disk_number
			where id=_id;

			return _id;
	else
		insert into vbd (uuid,
			name,
			poolid,
			srid,
			size,
			used,
			device_name,
			disk_type,
			disk_number)
		 values (_uuid,
			_name,
			_pool_id,
			_sr_id,
			_size,
			_used,
			_device_name,
			_disk_type,
			_disk_number);

		select id into _id from vbd where uuid=_uuid and poolid=_pool_id;
	end if;
	return _id;
end;
$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			July 10, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Modified 
-- Description:
--	 Add or update a record in the vif table.
-- Parameters:
--   uuid           - The unique ID of the virtual interface.
--   pool_id        - The database ID (id column of the hv_pool table) of 
--                    the pool to which the virtual interface belongs.
--   network_id     - The database ID (id column of the hv_network table)
--                    of the network associated with the virtual interface.
--   mac_address    - The media access control address associated with the
--                    virtual network interface.
--   device_number  - The device number of the virtual network interface - eth0=0,
--                    eth1=1, etc.
--   tstamp         - UTC date and time stamp the virtual interface was
--                    discovered.
-- Returns:
--   The database ID (id column of the vif table) of the virtual interface 
--   that was added or updated.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_vif
(
	_uuid		varchar(48), 	
	_pool_id	int,
	_network_id    	int,
	_mac_address    varchar(64),
	_device_number 	varchar(12),
	_tstamp		timestamp
);

create function "WorkloadBalancing".add_update_vif
(
	_uuid		varchar(48), 	
	_pool_id	int,
	_network_id    	int,
	_mac_address    varchar(64),
	_device_number 	varchar(12),
	_tstamp		timestamp
) returns int as $$
declare
	_id int;

begin
	
	select id into _id from vif where uuid=_uuid and poolid=_pool_id;

	if _id is not null then 
		update vif
		  set mac_address=_mac_address,
		  device_number=_device_number
		where id=_id;
		
	else
		insert into vif (uuid,
		    poolid,
		    networkid,
		    mac_address,
		    device_number,
		    tstamp)
		  values (_uuid,					   
		    _pool_id,
		    _network_id,
		    _mac_address,
		    _device_number,
		    _tstamp);
	end if;

	select id into _id from vif where uuid=_uuid and poolid=_pool_id;
	return _id;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Create date: 		June 18, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Add or update a record in the virtual_machine table.
-- Parameters:
--   uuid                       - The unique ID of the virtual machine to add 
--                                or update.
--   name                       - The name of the virtual machine.
--   description                - Description of the virtual machine.
--   host_affinity              - The internal, database ID, of the host to 
--                                to which the virtual machine has affinity.
--   min_dynamic_memory         - The minimum amount of dynamic memory, in 
--                                bytes required by the VM.
--   max_dynamic_memory         - The maximum amount of dynamic memory, in 
--                                bytes that can be used by the VM.
--   min_static_memory          - The minimum amount of static memory, in 
--                                bytes required by the VM.
--   max_static_memory          - The maximum amount of static memory, in 
--                                bytes that can be used by VM.
--   target_memory              - The memory target, in bytes for the VM.
--   memory_overhead            - The amount of hypervisor memory overhead,
--                                in bytes, for the VM.
--   min_cpus                   - The minimum number of CPUs required by the VM.
--   hv_mem_multiplier          - The multiplier that needs to be applied to the 
--                                VM's hypervisor memory overhead.
--   poolid                     - The internal, database ID of the pool to 
--                                which the VM belongs.
--   is_control_domain			- Flag to indicate if the VM is a control
--								  domain or root partition.
--   is_agile                   - Flag to indicate if the VM can migrate between
--                                physical hosts.
--   drivers_up_to_date         - Flag to indicate if the virtual drivers are up
--                                to date for this VM.
--   active                     - Flag to indicate if the VM is still part of
--								  pool.  VMs that have been removed from a pool
--								  are not deleted from Kirkwood.  They are 
--								  marked as inactive.
-- Returns:
--   The database ID of the (virtual_machine.id) of the record.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_virtual_machine
(
	_uuid               varchar(48),
	_name               varchar(256), 
	_description        varchar(1024),
	_host_affinity      int,
	_min_dynamic_memory bigint,
	_max_dynamic_memory bigint,
	_min_static_memory  bigint,
	_max_static_memory  bigint,
	_target_memory      bigint,
	_memory_overhead    bigint,
	_hv_mem_multiplier  decimal(7,2),
	_min_cpus           int,
	_poolid             int,
	_is_control_domain  boolean,
	_is_agile           boolean,
	_drivers_up_to_date boolean,
	_active             boolean
);

create function "WorkloadBalancing".add_update_virtual_machine
(
	_uuid               varchar(48),
	_name               varchar(256), 
	_description        varchar(1024),
	_host_affinity      int,
	_min_dynamic_memory bigint,
	_max_dynamic_memory bigint,
	_min_static_memory  bigint,
	_max_static_memory  bigint,
	_target_memory      bigint,
	_memory_overhead    bigint,
	_hv_mem_multiplier  decimal(7,2),
	_min_cpus           int,
	_poolid             int,
	_is_control_domain  boolean,
	_is_agile           boolean,
	_drivers_up_to_date boolean,
	_active             boolean
) returns int as $$

declare
	_id int := null;
begin

	select id into _id from virtual_machine where uuid=_uuid and poolid=_poolid;

	if _id is not null then
		update virtual_machine set name=_name,
		   description=_description,
		   host_affinity=_host_affinity,
		   min_dynamic_memory=_min_dynamic_memory,
		   max_dynamic_memory=_max_dynamic_memory,
		   min_static_memory=_min_static_memory,
		   max_static_memory=_max_static_memory,
		   target_memory=_target_memory,
		   memory_overhead=_memory_overhead,
		   min_cpus=_min_cpus,
		   hv_memory_multiplier=_hv_mem_multiplier,
		   is_control_domain=_is_control_domain,
		   is_agile=_is_agile,
		   drivers_up_to_date=_drivers_up_to_date,
		   active=_active
		where id=_id;
	else
		insert into virtual_machine (name,
			uuid, 
			description,
			host_affinity,
			min_dynamic_memory,
			max_dynamic_memory,
			min_static_memory,
			max_static_memory,
			target_memory,
			memory_overhead,
			min_cpus,
			hv_memory_multiplier,
			poolid,
			is_control_domain,
			is_agile,
			drivers_up_to_date,
			active)
		   values(_name,
			_uuid,
			_description,
			_host_affinity,
			_min_dynamic_memory,
			_max_dynamic_memory,
			_min_static_memory,
			_max_static_memory,
			_target_memory,
			_memory_overhead,
			_min_cpus,
			_hv_mem_multiplier,
			_poolid,
			_is_control_domain,
			_is_agile,
			_drivers_up_to_date,
			_active);
	end if;
	
	select id into _id from virtual_machine where uuid=_uuid and poolid=_poolid;
	return _id;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			July 10, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Add or update a record in the vm_storage_repository table to indicate a
--   VM requires a storage repository.
-- Parameters:
--   vm_id       - The database ID (id column of the virtual_machine table) of 
--                 the VM.
--   sr_id       - The database ID (id column of the storage_repository) of 
--                 storage repository.
-- Returns:
--   None
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_vm_storage_repository
(
	_vm_id  int, 	
	_sr_id  int
);

create function "WorkloadBalancing".add_update_vm_storage_repository
(
	_vm_id  int, 	
	_sr_id  int
) returns void as $$
declare
	_id int := null;
begin
	
	select id into _id from vm_storage_repository where vm_id=_vm_id and sr_id=_sr_id;
	if _id is null then
		insert into vm_storage_repository (vm_id, sr_id)
			values(_vm_id, _sr_id);
	end if;
end;

$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			July 10, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Add or update a record in the vm_vif table to indicate a VM is associated
--	 with a virutal network interface.
-- Parameters:
--   vm_id       - The database ID (id column of the virtual_machine table) of 
--                 the VM.
--   vif_id      - The database ID (id column of the vbd table) of the virtual 
--				   network interface.
-- Returns:
--   None
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_vm_vif
(
	_vm_id   int, 	
	_vif_id  int
);

create function "WorkloadBalancing".add_update_vm_vif
(
	_vm_id   int, 	
	_vif_id  int
) returns void as $$
declare
	_id int := null;

begin
	
	select id into _id from vm_vif where vm_id=_vm_id and vif_id=_vif_id;
	if _id is null then
		insert into vm_vif (vm_id, vif_id) values(_vm_id, _vif_id);
	end if;
end;

$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			June 18, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Add or update a record in the vm_vbd table to indicate a VM is associated
--	 with a virutal block device (virtual disk).
-- Parameters:
--   vm_id       - The database ID (id column of the virtual_machine table) of 
--                the VM.
--   vbd_id      - The database ID (id column of the vbd table) of the virtual 
--				   block device.
-- Returns:
--   None
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".add_update_vm_vbd
(
	_vm_id   int, 	
	_vbd_id  int
);

create function "WorkloadBalancing".add_update_vm_vbd
(
	_vm_id   int, 	
	_vbd_id  int
) returns void as $$

declare 
	_id int := null;
begin

	select id into _id from vm_vbd where vm_id=_vm_id and vbd_id=_vbd_id;
	if _id is null then
		insert into vm_vbd (vm_id, vbd_id)
			 values(_vm_id, _vbd_id);
	end if;
end;
$$ language plpgsql;

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: August 4, 2008
-- Description:	Retrieve all the recent moves (within the past 12 hours) for
--				all VMs.
-- Parameters:
--   _pool_id	The database ID (id column of the hv_pool table) of the pool
--              for which recent VM moves is desired.
-- Returns:
--   If successful, a result set containing the information about the VMs
--   that have moved recently
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_recent_vm_moves_by_pool_id
(
	_pool_id int
); 

create function get_recent_vm_moves_by_pool_id
(
	_pool_id int
) returns refcursor as $$

	-- Get the number of minutes that is considered recent.  The default value
	-- is 120 minutes (2 hours).  If a VM has been moved 'recently', we will 
	-- not move it again.
declare _recent_move_minutes int;
	cur1 refcursor;

begin
	select into _recent_move_minutes cast(value as int) 
					from  hv_pool_config
					where pool_id = _pool_id and
						  "name" = 'RecentMoveMinutes';
	if _recent_move_minutes is null then
		_recent_move_minutes := 120;
	end if;							  

	open cur1 for 
		select	vmm.move_to_host_id, 
			h.name,
			vmm.move_from_host_id,
			hh.name,
			vmm.vm_id,
			v.name,
			vmm.tstamp
		from vm_movement vmm
		join hv_pool_host ph on ph.hostid=vmm.move_to_host_id
		join hv_host h on h.id=vmm.move_to_host_id
		left outer join hv_host hh on hh.id=vmm.move_from_host_id
		join virtual_machine v on v.id=vmm.vm_id		
		where ph.poolid=_pool_id and vmm.tstamp > (getutcdate() -_recent_move_minutes * interval '1 minute')
		order by vmm.vm_id;
	return cur1;
end;
$$ language plpgsql;

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: July 30, 2008
-- Updated:	Nov 24, 2010 -> Converted to PostGreSQL.  Fixed some issues.
-- 		Feb 14, 2012 (Rabin Karki): -> Breaking into pieces. Result Set 1 of ae_get_pool_data.
-- Description:	Retrieve the configuration and metrics data for the specified
--              hypervisor pool.
-- Parameters:
--   pool_id	The database ID (id column of the hv_pool table) of the pool
--              whose configuration and  metrics data is to be retrieved.
-- Returns:
--      The pool's configuration.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".ae_get_pool_data_pool_config
(
	_pool_id	int
);

CREATE FUNCTION "WorkloadBalancing".ae_get_pool_data_pool_config
(
	_pool_id	int
)
RETURNS SETOF refcursor AS $$
DECLARE	
	_ref_pool_config 		refcursor;	
BEGIN

	-- RESULT SET 1 - Get the pool's configuration.
	open _ref_pool_config for
		select	id,
			uuid,
			name, 
			hv_type,
			max_cpu_rating,
			is_licensed			
		from hv_pool
		where id = _pool_id;
	return next _ref_pool_config;
END; $$
language plpgsql;

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: July 30, 2008
-- Updated:	Nov 24, 2010 -> Converted to PostGreSQL.  Fixed some issues.
-- 		Feb 14, 2012 (Rabin Karki): -> Breaking into pieces. Result Set 2 of ae_get_pool_data.
-- Description:	Retrieve the configuration and metrics data for the specified
--              hypervisor pool.
-- Parameters:
--   pool_id	The database ID (id column of the hv_pool table) of the pool
--              whose configuration and  metrics data is to be retrieved.
-- Returns:
--      The pool's thresholds and weights.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".ae_get_pool_data_pool_thresholds
(
	_pool_id	int
); 

CREATE FUNCTION "WorkloadBalancing".ae_get_pool_data_pool_thresholds
(
	_pool_id	int
)
RETURNS SETOF refcursor AS $$
DECLARE 
	_ref_pool_thresholds 		refcursor;
BEGIN
	open _ref_pool_thresholds for
		select * from load_hv_pool_threshold_by_ids(array[_pool_id]);
	return next _ref_pool_thresholds;
END; $$
language plpgsql;
-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: July 30, 2008
-- Updated:	Nov 24, 2010 -> Converted to PostGreSQL.  Fixed some issues.
-- 		Feb 14, 2012(Rabin Karki): -> Breaking into pieces. Result Set 3 of ae_get_pool_data.
-- Description:	Retrieve the configuration and metrics data for the specified
--              hypervisor pool.
-- Parameters:
--   pool_id	The database ID (id column of the hv_pool table) of the pool
--              whose configuration and  metrics data is to be retrieved.
-- Returns:
--     The hosts, with metrics, in the pool.
-- Remarks:
--	Increase work_mem for this function from code. For 800 vm pool, 15 MB seems about right. On default 1MB work_mem, sorting takes place in disk, which slows down the query.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".ae_get_pool_data_hosts_with_metrics
(
	_pool_id	int
);

CREATE FUNCTION "WorkloadBalancing".ae_get_pool_data_hosts_with_metrics
(
	_pool_id	int
)
RETURNS SETOF refcursor AS $$
DECLARE
	_ref_hosts_with_metrics		refcursor;	

BEGIN	
	open _ref_hosts_with_metrics for
		select	h.id as host_id, 
			h.name,
			h.uuid,
			h.poolid,
			h.num_cpus, 
			h.cpu_speed,
			h.num_pifs,
			h.is_pool_master,
			h.enabled,
			h.power_state,
			h.memory_overhead,
			( select vmm.total_mem 
			  from vm_metric vmm 
			  join virtual_machine vm on (vm.id = vmm.vmid)
			  where vmm.hostid = h.id and vm.is_control_domain = true
			  order by vmm.id desc limit 1
			) as memory_actual,
			( select vm.memory_overhead 
			  from virtual_machine vm 
			  join host_vm hv on vm.id = hv.vmid 
			  where vm.is_control_domain = true and hv.hostid = h.id
			  order by vm.id desc limit 1			
			) as control_memory_overhead,
			cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ParticipatesInPowerManagement', 'false') as boolean) as can_power,
			cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPlacementRecommendations', 'false') as boolean) as exclude_placements,
			cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromEvacuationRecommendations', 'false') as boolean) as exclude_evacuations,				
			cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPoolOptimizationAcceptVMs', 'false') as boolean) as exclude_optimization_placements,					
			b.free_cpus,
			ph.fill_order,				
			hm2.free_mem,			
			cast(avg(hm1.total_mem) as bigint) as total_mem,	
			avg(hm1.avg_cpu_utilization) as cpu_util,
			avg(hm1.avg_pif_read_per_sec) as net_read,	
			avg(hm1.avg_pif_write_per_sec) as net_write,
			vrs.full_contention_count,
			vrs.concurrency_hazard_count,
			vrs.partial_contention_count,
			vrs.fullrun_count,
			vrs.partial_run_count,
			vrs.blocked_count
		from host_metric hm1 
		join hv_pool_host ph  on ph.hostid = hm1.hostid
		join hv_host      h   on h.id = ph.hostid
		join host_metric  hm2 on (hm2.hostid = hm1.hostid
					  and hm2.id = (select hm3.id 
							from host_metric hm3 
						        where hm3.hostid = hm2.hostid order by hm3.tstamp desc limit 1))
		join ( 	select h.id, h.num_cpus - sum(v.min_cpus) + h.num_cpus as free_cpus
			from virtual_machine v 
			left join host_vm hv  on hv.vmid=v.id
			join hv_host h  on h.id=hv.hostid
			group by h.id, h.num_cpus) b on h.id=b.id	
		join (  select  hostid,
				sum(full_contention) as full_contention_count,
				sum(concurrency_hazard) as concurrency_hazard_count,
				sum(partial_contention) as partial_contention_count,
				sum(fullrun) as fullrun_count,
				sum(partial_run) as partial_run_count,
				sum(blocked) as blocked_count
			from (	select	hv.hostid as hostid, 
					case when (avg(vmm.runstate_full_contention)> hpt.host_runstate_full_contention_threshold_high) then vm.min_cpus else 0 end as full_contention,
					case when (avg(vmm.runstate_concurrency_hazard)> hpt.host_runstate_concurrency_hazard_threshold_high) then vm.min_cpus else 0 end as concurrency_hazard,
					case when (avg(vmm.runstate_partial_contention)> hpt.host_runstate_partial_contention_threshold_high) then vm.min_cpus else 0 end as partial_contention,
					case when (avg(vmm.runstate_fullrun)> hpt.host_runstate_fullrun_threshold_high) then vm.min_cpus else 0 end as fullrun,
					case when (avg(vmm.runstate_partial_run)> hpt.host_runstate_partial_run_threshold_high) then vm.min_cpus else 0 end as partial_run,
					case when (avg(vmm.runstate_blocked)> hpt.host_runstate_blocked_threshold_high) then vm.min_cpus else 0 end as blocked
				from vm_metric vmm 
				join host_vm hv on vmm.vmid = hv.vmid
				join hv_pool_host hph on hv.hostid = hph.hostid
				join hv_pool_threshold hpt on hph.poolid = hpt.pool_id
				join virtual_machine vm on vmm.vmid = vm.id
				group by hv.hostid, vmm.vmid, vm.min_cpus, hpt.host_runstate_full_contention_threshold_high, 
					hpt.host_runstate_concurrency_hazard_threshold_high,
					hpt.host_runstate_partial_contention_threshold_high,
					hpt.host_runstate_fullrun_threshold_high,
					hpt.host_runstate_partial_run_threshold_high,
					hpt.host_runstate_blocked_threshold_high
				) runstate_base
				group by hostid
			) vrs on h.id = vrs.hostid												
		where ph.poolid = _pool_id 
		and hm1.hostid = ph.hostid
		group by h.id,
			h.name,
			h.uuid,
			h.poolid,
			h.num_cpus, 
			h.cpu_speed,
			h.num_pifs,
			h.is_pool_master,
			h.enabled,
			h.power_state,
			h.memory_overhead,
			cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ParticipatesInPowerManagement', 'false') as boolean),
			cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPlacementRecommendations', 'false') as boolean),
			cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromEvacuationRecommendations', 'false') as boolean),				
			cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPoolOptimizationAcceptVMs', 'false') as boolean),		
			ph.fill_order,
			b.free_cpus,
			hm2.free_mem,
			vrs.full_contention_count,
			vrs.concurrency_hazard_count,
			vrs.partial_contention_count,
			vrs.fullrun_count,
			vrs.partial_run_count,
			vrs.blocked_count
		order by ph.fill_order;
	return next _ref_hosts_with_metrics;	
END; $$
language plpgsql;
-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: July 30, 2008
-- Updated:	Nov 24, 2010 -> Converted to PostGreSQL.  Fixed some issues.
-- 		Feb 14, 2012 (Rabin Karki): -> Breaking into pieces. Result Set 4 of ae_get_pool_data.
-- Description:	Retrieve the configuration and metrics data for the specified
--              hypervisor pool.
-- Parameters:
--   pool_id	The database ID (id column of the hv_pool table) of the pool
--              whose configuration and  metrics data is to be retrieved.
-- Returns:
--      The storage repositories attached to each host.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".ae_get_pool_data_storage_repositories
(
	_pool_id	int
);

CREATE FUNCTION "WorkloadBalancing".ae_get_pool_data_storage_repositories
(
	_pool_id	int
)
RETURNS SETOF refcursor AS $$
DECLARE
	_ref_storage_repositories	refcursor;
BEGIN
	open _ref_storage_repositories for 
		select	h.id as host_id,
			h.uuid  as host_uuid,
			h.name  as host_name,
			sr.id   as sr_id,
			sr.uuid as sr_uuid, 
			sr.name as sr_name,
			sr.poolid
		from hv_host_storage_repository hsr
		join hv_host h on (h.id = hsr.host_id)
		join storage_repository sr on (sr.id = hsr.sr_id)
		join hv_pool_host ph on (ph.hostid = h.id)
		where ph.poolid = _pool_id;
	return next _ref_storage_repositories;

END; $$
language plpgsql;

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: July 30, 2008
-- Updated:	Nov 24, 2010 -> Converted to PostGreSQL.  Fixed some issues.
-- 		Feb 14, 2012 (Rabin Karki): -> Breaking into pieces. Result Set 5 of ae_get_pool_data.
-- Description:	Retrieve the configuration and metrics data for the specified
--              hypervisor pool.
-- Parameters:
--   pool_id	The database ID (id column of the hv_pool table) of the pool
--              whose configuration and  metrics data is to be retrieved.
-- Returns:
--      The physical interfaces attached to each host
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".ae_get_pool_data_pifs
(
	_pool_id	int
);

CREATE FUNCTION "WorkloadBalancing".ae_get_pool_data_pifs
(
	_pool_id	int
)
RETURNS SETOF refcursor AS $$
DECLARE
	_ref_pifs	refcursor;
BEGIN
	open _ref_pifs for
		select	h.id as host_id,
			h.uuid as host_uuid,
			h.name as host_name,
			pif.id as pif_id,
			pif.uuid as pif_uuid, 
			pif.name as pif_name,
			pif.networkid as networkid,
			pif.poolid,
			pif.is_management_interface
		from hv_host_pif hp
		join hv_host h on (h.id = hp.hostid)
		join hv_pif  pif on (pif.id = hp.pif_id)
		join hv_pool_host ph on (ph.hostid = h.id)
		where ph.poolid = _pool_id
		order by h.id;
	return next _ref_pifs;
END;
$$ language plpgsql;
-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: July 30, 2008
-- Updated:	Nov 24, 2010 -> Converted to PostGreSQL.  Fixed some issues.
-- 		Feb 14, 2012(Rabin Karki): -> Breaking into pieces. Result Set 6 of ae_get_pool_data.
-- Description:	Retrieve the configuration and metrics data for the specified
--              hypervisor pool.
-- Parameters:
--   pool_id	The database ID (id column of the hv_pool table) of the pool
--              whose configuration and  metrics data is to be retrieved.
-- Returns:
--		The VMs that are running on each host plus their metrics
-- Remarks:
--		Set work_mem to at least 15MB (tested for 800 vms) for this function too. Setting work_mem to larger value makes this function considerably faster.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".ae_get_pool_data_vm_metrics
(
	_pool_id	int
);

CREATE FUNCTION "WorkloadBalancing".ae_get_pool_data_vm_metrics
(
	_pool_id	int
)
RETURNS SETOF refcursor AS $$
DECLARE 
	_ref_host_vm_metrics		refcursor;	
BEGIN
	open _ref_host_vm_metrics for
		select	hv.hostid as host_id,
			m.vm_id,
			v.uuid, 
			v.name,
			v.poolid,
			v.host_affinity,
			v.min_dynamic_memory,
			v.max_dynamic_memory,
			v.min_static_memory,
			v.max_static_memory,
			v.target_memory,
			v.memory_overhead,
			"WorkloadBalancing".fn_required_memory(v.id) as required_memory,
			"WorkloadBalancing".fn_vm_total_memory(v.id) as total_memory,
			v.min_cpus,
			v.hv_memory_multiplier,
			v.is_agile,
			v.drivers_up_to_date,
			v.poolid,
			m.total_mem,
			m.free_mem,
			m.used_mem,
			m.target_mem,
			m.cpu_util,
			m.disk_read,
			m.disk_write,
			m.net_read,
			m.net_write,
			m.vbd_net_read,
			m.vbd_net_write,
			m.runstate_full_contention,
			m.runstate_concurrency_hazard,
			m.runstate_partial_contention,
			m.runstate_fullrun,
			m.runstate_partial_run,
			m.runstate_blocked
		from
		(
			select	m.vmid as vm_id, 
				avg(m.total_mem)			as total_mem,
				avg(m.free_mem)				as free_mem,				
				avg(m.total_mem-m.free_mem)		as used_mem,
				avg(m.target_mem)               	as target_mem,
				avg(m.avg_cpu)				as cpu_util,
				avg(m.avg_vbd_read)			as disk_read,
				avg(m.avg_vbd_write)			as disk_write,
				avg(m.avg_vif_read)			as net_read,
				avg(m.avg_vif_write)			as net_write,
				avg(m.total_vbd_net_read)		as vbd_net_read,
				avg(m.total_vbd_net_write)		as vbd_net_write,
				avg(m.runstate_full_contention)	   	as runstate_full_contention,
				avg(m.runstate_concurrency_hazard) 	as runstate_concurrency_hazard,
				avg(m.runstate_partial_contention) 	as runstate_partial_contention,
				avg(m.runstate_fullrun)			as runstate_fullrun,
				avg(m.runstate_partial_run)		as runstate_partial_run,
				avg(m.runstate_blocked)			as runstate_blocked
			from vm_metric m
			group by m.vmid
		) m
		join host_vm hv on (hv.vmid = m.vm_id)
		join hv_pool_host ph on (ph.hostid = hv.hostid)
		join virtual_machine v on (v.id = m.vm_id)
		where ph.poolid = _pool_id and v.is_control_domain = false
		order by hv.hostid;
	return next _ref_host_vm_metrics;

END;
$$ language plpgsql;
-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: July 30, 2008
-- Updated:	Nov 24, 2010 -> Converted to PostGreSQL.  Fixed some issues.
-- 		Feb 14, 2012(Rabin Karki): -> Breaking into pieces. Result Set 7 of ae_get_pool_data.
-- Description:	Retrieve the configuration and metrics data for the specified
--              hypervisor pool.
-- Parameters:
--   pool_id	The database ID (id column of the hv_pool table) of the pool
--              whose configuration and  metrics data is to be retrieved.
-- Returns:
--		Grab the storage repositories required by each VM.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".ae_get_pool_data_vm_storage_repositories
(
	_pool_id	int
);

CREATE FUNCTION "WorkloadBalancing".ae_get_pool_data_vm_storage_repositories
(
	_pool_id	int
)
RETURNS SETOF refcursor AS $$
DECLARE 
	_ref_vm_storage_repositories	refcursor;
BEGIN
	open _ref_vm_storage_repositories for
		select	hvm.hostid as host_id,
			vmsr.vm_id, 
			vmsr.sr_id,
			sr.uuid,
			sr.name, 
			sr.poolid
		from vm_storage_repository vmsr
		join host_vm hvm on (hvm.vmid = vmsr.vm_id)
		join hv_pool_host ph on (ph.hostid = hvm.hostid)
		join storage_repository sr on (sr.id = vmsr.sr_id)
		join virtual_machine v on (v.id = vmsr.vm_id)
		where ph.poolid = _pool_id and v.is_control_domain = false 
		order by hvm.hostid, vmsr.vm_id, vmsr.sr_id;
	return next _ref_vm_storage_repositories;
END;
$$ language plpgsql;
-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: July 30, 2008
-- Updated:	Nov 24, 2010 -> Converted to PostGreSQL.  Fixed some issues.
-- 		Feb 14, 2012(Rabin Karki): -> Breaking into pieces. Result Set 8 of ae_get_pool_data.
-- Description:	Retrieve the configuration and metrics data for the specified
--              hypervisor pool.
-- Parameters:
--   pool_id	The database ID (id column of the hv_pool table) of the pool
--              whose configuration and  metrics data is to be retrieved.
-- Returns:
--		Grab the virtual interfaces required by each VM.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".ae_get_pool_data_vm_vif
(
	_pool_id	int
);

CREATE FUNCTION "WorkloadBalancing".ae_get_pool_data_vm_vif
(
	_pool_id	int
)
RETURNS SETOF refcursor AS $$
DECLARE 
	_ref_vm_vif 		refcursor;
BEGIN
	open _ref_vm_vif for
		select hvm.hostid as host_id,
		       vvf.vm_id,
		       ph.poolid,
		       vvf.vif_id,
		       vf.uuid,
		       vf.networkid
		from vm_vif vvf
		join host_vm         hvm on (hvm.vmid = vvf.vm_id)
		join hv_pool_host    ph  on (ph.hostid = hvm.hostid)
		join vif             vf  on (vf.id = vvf.vif_id)
		join virtual_machine vm  on (vm.id = vvf.vm_id)
		where ph.poolid = _pool_id and vm.is_control_domain = false
		order by hvm.hostid, vvf.vm_id, vvf.vif_id;
	return next _ref_vm_vif;
END;
$$ language plpgsql;
-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: July 30, 2008
-- Updated:	Nov 24, 2010 -> Converted to PostGreSQL.  Fixed some issues.
-- 		Feb 14, 2012 (Rabin Karki): -> Breaking into pieces. Result Set 9 of ae_get_pool_data.
-- Description:	Retrieve the configuration and metrics data for the specified
--              hypervisor pool.
-- Parameters:
--   pool_id	The database ID (id column of the hv_pool table) of the pool
--              whose configuration and  metrics data is to be retrieved.
-- Returns:
--		Grab the list of VMs that have recently been moved.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".ae_get_pool_data_recent_moves
(
	_pool_id	int
);

CREATE FUNCTION "WorkloadBalancing".ae_get_pool_data_recent_moves
(
	_pool_id	int
)
RETURNS SETOF refcursor AS $$
DECLARE 
	_ref_recent_moves 		refcursor;
	_recent_move_minutes	int;
BEGIN
	-- Get the number of minutes that is considered recent.  The default value
	-- is 120 minutes (2 hours).  If a VM has been moved 'recently', we will 
	-- not move it again.

	select into _recent_move_minutes cast(value as int) 
		from  hv_pool_config
		where pool_id = _pool_id and "name" = 'RecentMoveMinutes';

	if _recent_move_minutes is null then
		_recent_move_minutes := 120;
	end if;

	open _ref_recent_moves for
		select	vmm.move_to_host_id, 
			h.name,
			vmm.move_from_host_id,
			hh.name,
			vmm.vm_id,
			v.name,
			vmm.tstamp
		from vm_movement vmm
		join hv_pool_host ph on (ph.hostid = vmm.move_to_host_id)
		join hv_host h on (h.id = vmm.move_to_host_id)
		left outer join hv_host hh on (hh.id = vmm.move_from_host_id)
		join virtual_machine v on (v.id = vmm.vm_id)
		where ph.poolid=_pool_id and vmm.tstamp > (getutcdate() -_recent_move_minutes * interval '1 minute')
		order by vmm.vm_id;
	return next _ref_recent_moves;
END;
$$ language plpgsql;
-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: July 30, 2008
-- Updated:	Nov 26 2010
--		Converted to PostGreSQL
--		Removed unused garbage variables and improved code flow.
-- Description:	Retrieve the list of pools that are under performace pressure
--              when their optimization mode is max performance or have idle
--              host when the optimization mode is max density.
-- Parameters:
--   None
-- Returns:
--   Result Set 1:
--      Configuration, threshold and weight information for each hypervisor pool.
--   Result Set 2:
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".ae_get_pools_in_trouble();

CREATE FUNCTION "WorkloadBalancing".ae_get_pools_in_trouble
() 
RETURNS SETOF refcursor AS $$

DECLARE
	_opt_mode_max_perf    		int := 0;
	_opt_mode_max_density 		int := 1;
	_poll_interval                 	interval;
	_ref_perf_pools_perf 		refcursor;
	_ref_density_pools_perf		refcursor;
	_ref_density_pools_consolidate	refcursor;
BEGIN

	create temporary table _host_metrics
	(	
		host_id       int,
		num_vms	      int,
		avg_free_mem  bigint,
		total_mem     bigint,
		avg_cpu       numeric,
		avg_net_read  numeric,
		avg_net_write numeric,
		avg_load      numeric
	)
	on commit drop;


	create temporary table _vms_with_runstate
	(
		poolid int, 
		hostid int, 
		vmid int
	)
	on commit drop;

							 
	create temporary table _pools_with_data
	(
		pool_id	   int
	)
	on commit drop;



	create temporary table _pool_density_perf_issue
	(
		poolid	       	int,
		pool_uuid      	varchar(48),
		pool_name      	varchar(256),
		hv_type        	int,
		pool_master_cpu_limit varchar(24),
		host_id        	int,
		host_uuid      	varchar(48),
		host_name    	varchar(256),
		is_pool_master 	boolean,
		can_power      	boolean,
		fill_order     	int,
		total_mem      	bigint,
		potential_free_mem bigint,
		avg_free_mem   	bigint,
		avg_cpu        	numeric(9,8),
		avg_net_read   	numeric(18,4),
		avg_net_write  	numeric(18,4),
		avg_load       	numeric(9,3),
		num_vms			int
	)
	on commit drop;


	-- Get the poll interval for the analysis engine.  We only care about
	-- pools that have data newer than the last poll interval.	
	_poll_interval := (select value
			   from "WorkloadBalancing".core_config 
			   where component_id = 4 
			   and category = 'Intervals'
			   and item_name = 'PollInterval');


	if _poll_interval is null then
		_poll_interval := '120';
	end if;	

	_poll_interval := '-' || _poll_interval || ' seconds';


	-- Grab the pools for which we have current data.
	insert into _pools_with_data (pool_id)
		select ph.poolid
		from host_metric hm
		join hv_pool_host ph on (ph.hostid = hm.hostid)
		where hm.tstamp >  datetimeadd(getutcdate(), _poll_interval)
		group by ph.poolid;


	-- Get the host metrics.  We have to look for max performance and max
	-- density issues but only want to get the metrics data once.
	insert into _host_metrics
		select	hm.hostid, 
			count(distinct hv.vmid) as num_vms,
			avg(hm.free_mem) as free_mem, 
			avg(hm.total_mem) as total_mem,
			avg(hm.avg_cpu_utilization) as cpu_util,
			avg(hm.avg_pif_read_per_sec) as net_read,
			avg(hm.avg_pif_write_per_sec) as net_write,
			avg(hm.load_average) as load_average
		from host_metric hm
		join hv_host h on h.id = hm.hostid
		join host_vm hv on (hm.hostid = hv.hostid)
		where h.active = true      
		and h.enabled = true 
		and h.power_state = 1
		group by hm.hostid;


	-- Get the vms with runstate issues
	insert into _vms_with_runstate
		select hph.poolid, hv.hostid, vm.vmid
		from vm_metric vm
		join host_vm hv on (vm.vmid = hv.vmid)
		join hv_pool_host hph on (hv.hostid = hph.hostid)
		join hv_pool_threshold hpt on (hph.poolid = hpt.pool_id)
		group by hph.poolid, hv.hostid, vm.vmid,
			hpt.host_runstate_full_contention_threshold_high,
			hpt.host_runstate_concurrency_hazard_threshold_high,
			hpt.host_runstate_partial_contention_threshold_high
		having 	avg(vm.runstate_full_contention) > hpt.host_runstate_full_contention_threshold_high
			or avg(vm.runstate_concurrency_hazard) > hpt.host_runstate_concurrency_hazard_threshold_high
			or avg(vm.runstate_partial_contention) > hpt.host_runstate_partial_contention_threshold_high;

	-- Put the pools with the optimization mode set to max density that have 
	-- performance issues into a table variable so we can filter them out of
	-- the query of density pools with density issues.
	insert into _pool_density_perf_issue
		select	ph.poolid,
			p.uuid,
			p.name,
			p.hv_type,
			pc1.value     as pool_master_cpu_limit,
			hm.host_id,
			h.uuid,
			h.name,
			h.is_pool_master,
			case lower(hc.value)
				when 'true'  then true
				when 'false' then false
				else false
			end as can_power,
			ph.fill_order,
			hm.total_mem,
			dmc.potential_free_mem,
			hm.avg_free_mem, 
			hm.avg_cpu,
			hm.avg_net_read,
			hm.avg_net_write,
			hm.avg_load,
			hm.num_vms
		from _host_metrics hm
		join hv_host           h   on (h.id = hm.host_id)
		join hv_pool_host      ph  on (ph.hostid = hm.host_id)
		join hv_pool_threshold pt  on (pt.pool_id = ph.poolid)
		join hv_pool           p   on (p.id = ph.poolid)
		join _pools_with_data  pd  on (pd.pool_id = p.id)
		join hv_pool_config    pc  on (pc.pool_id = p.id and pc.name = 'OptimizationMode')
		join hv_pool_config    pc1 on (pc1.pool_id = p.id and pc1.name = 'PoolMasterCpuLimit')
		left join hv_host_config hc on (hc.host_id = h.id and hc.name = 'ParticipatesInPowerManagement')
		left join _vms_with_runstate vrs on (h.id = vrs.hostid)
		left join "WorkloadBalancing".fn_get_host_potential_free_memory_dmc() dmc on (dmc.hostid = ph.hostid and dmc.poolid = ph.poolid)
		where cast(pc.value as int) = _opt_mode_max_density and
		--p.id in (select pool_id from @pools_with_data) and
		(  
			(hm.avg_cpu > pt.host_cpu_threshold_critical      or
			hm.avg_load > pt.host_load_avg_threshold_critical or
			-- use potential free memory snapshot for ballooning
			(dmc.has_memory_ballooning = true and dmc.potential_free_mem < pt.host_memory_threshold_critical) or
			(dmc.has_memory_ballooning = false and hm.avg_free_mem < pt.host_memory_threshold_critical) or
			hm.avg_net_read  > pt.host_net_read_threshold_critical or
			hm.avg_net_write > pt.host_net_write_threshold_critical)
			or (h.is_pool_master = true    -- pool master has exceed CPU limit
			and cast(pc1.value as decimal(9,5)) > 0 
			and hm.avg_cpu >  cast(pc1.value as decimal(9,5)))			    
			or  vrs.poolid is not null
		) -- exists in @vms_with_runstate
		and cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPoolOptimizations', 'false') as boolean) = false;


	-- RESULT SET 1 - Pools with the optimization mode set to max performance that have performance issues.
	open _ref_perf_pools_perf for
		select	ph.poolid,
			p.uuid as pool_uuid,
			p.name  as pool_name,
			p.hv_type,
			pc1.value as pool_master_cpu_limit,
			hm.host_id,
			h.uuid as host_uuid,
			h.name as host_name,
			h.is_pool_master, 
			case lower(hc.value)
				when 'true'  then true
				when 'false' then false
				else false
			end as can_power,
			ph.fill_order,
			hm.total_mem,
			hm.avg_free_mem, 
			hm.avg_cpu,
			hm.avg_net_read,
			hm.avg_net_write,
			hm.avg_load,
			hm.num_vms
		from _host_metrics hm
		join hv_host h 			on (h.id = hm.host_id)
		join hv_pool_host ph 		on (ph.hostid = hm.host_id)
		join hv_pool_threshold pt 	on (pt.pool_id = ph.poolid)
		join hv_pool p 			on (p.id = ph.poolid)
		join _pools_with_data pd 	on (pd.pool_id = p.id)
		join hv_pool_config pc  	on (pc.pool_id = p.id and pc.name = 'OptimizationMode')
		join hv_pool_config pc1 	on (pc1.pool_id = p.id and pc1.name = 'PoolMasterCpuLimit')
		left join hv_host_config hc 	on (hc.host_id = h.id and hc.name = 'ParticipatesInPowerManagement')
		left join _vms_with_runstate vrs on (h.id = vrs.hostid)
		where cast(pc.value as int) = _opt_mode_max_perf 
		and ((	hm.avg_cpu > pt.host_cpu_threshold_high or
			hm.avg_load      > pt.host_load_avg_threshold_high or
			hm.avg_free_mem  < pt.host_memory_threshold_high   or
			hm.avg_net_read  > pt.host_net_read_threshold_high or
			hm.avg_net_write > pt.host_net_write_threshold_high)
			-- pool master has exceed CPU limit		
			or (h.is_pool_master = true   
				and cast(pc1.value as numeric(9,5)) > 0 
				and hm.avg_cpu >  cast(pc1.value as numeric(9,5)))
			-- exists in _vms_with_runstate
			or  vrs.poolid is not null) 
		and cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPoolOptimizations', 'false') as boolean) = false;
	return next _ref_perf_pools_perf;


	
	-- RESULT SET 2 - Pools with the optimization mode set to max density that have performance issues.
	open _ref_density_pools_perf for 
		select  poolid,
			pool_uuid,
			pool_name,
			hv_type,
			pool_master_cpu_limit,
			host_id,
			host_uuid,
			host_name,
			is_pool_master,
			can_power,
			fill_order,
			total_mem,
			potential_free_mem,
			avg_free_mem,
			avg_cpu,
			avg_net_read,
			avg_net_write,
			avg_load,
			num_vms
		from _pool_density_perf_issue;
	return next _ref_density_pools_perf;


	-- RESULT SET 3- Pools with the optimization mode set to max density that have idle hosts.
	open _ref_density_pools_consolidate for
		select	distinct ph.poolid,
			p.uuid       as pool_uuid,
			p.name       as pool_name,
			p.hv_type,
			pc1.value    as pool_master_cpu_limit,
			hm.host_id,
			h.uuid       as host_uuid,
			h.name       as host_name,
			h.is_pool_master,
			case lower(hc.value)
				when 'true'  then true
				when 'false' then false
				else false
			end as can_power,
			ph.fill_order,
			hm.total_mem,
			hm.avg_free_mem, 
			hm.avg_cpu,
			hm.avg_net_read,
			hm.avg_net_write,
			hm.avg_load,
			hm.num_vms
		from _host_metrics hm
		join hv_host           h  on (h.id = hm.host_id)
		join hv_pool_host      ph on (ph.hostid = hm.host_id)
		join hv_pool_threshold pt on (pt.pool_id = ph.poolid)
		join host_vm           hv on (hv.hostid = hm.host_id) -- need to have VMs on the host.
		join hv_pool           p  on (p.id = ph.poolid)
		join _pools_with_data  pd on (pd.pool_id = p.id)
		join hv_pool_config    pc on (pc.pool_id = p.id and pc.name = 'OptimizationMode')
		join hv_pool_config    pc1 on (pc1.pool_id = p.id and pc1.name = 'PoolMasterCpuLimit')
		left join hv_host_config hc on (hc.host_id = h.id and hc.name = 'ParticipatesInPowerManagement')
		where cast(pc.value as int) = _opt_mode_max_density 
		--p.id in (select pool_id from @pools_with_data) and
		and ph.poolid not in (select poolid from _pool_density_perf_issue) 
		and (	hm.avg_cpu < pt.host_cpu_threshold_low or
			hm.avg_free_mem  > pt.host_memory_threshold_low or
			hm.avg_net_read  < pt.host_net_read_threshold_low or
			hm.avg_net_write < pt.host_net_write_threshold_low)
		and cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPoolOptimizations', 'false') as boolean) = false
		order by ph.fill_order desc;
	return next _ref_density_pools_consolidate;



	RETURN;
END;
$$ LANGUAGE plpgsql;

/*
begin;
select "WorkloadBalancing".ae_get_pools_in_trouble_bl();
fetch all from "<unnamed portal 24>";
*/

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: May 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 18, 2010	
-- Description:	
--   Assign a hypervisor pools to a data collection for monitoring.
-- Parameters:
--   host_id    - The database ID (id column of the collection_host table) 
--                of the data collection hosts to which the pool is being 
--                assigned.
--   pool_id    - The database ID (id column of the hv_pool table) of the
--                hypervisor pool.
--   state      - The current state of data collection:  active, inactive,
--                not collecting.
--   touched_by - The name of the user making the assignment.  Should be
--                NULL is the assignment is made by the system.
-- Returns:
--   The id column of the row in the collection_host_hv_pool tables that 
--   represents the data collection host/pool relationship.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".assign_pool_to_collection_host
(
	_host_id int,
	_pool_id int,
	_state int,
	_touched_by varchar(50)
);

create function "WorkloadBalancing".assign_pool_to_collection_host
(
	_host_id int,
	_pool_id int,
	_state int,
	_touched_by varchar(50) = null
) returns int as $$

declare _id int;
	_user_assigned boolean := false;

begin
	if _host_id is not null and _pool_id is not null then
		if _touched_by is not null and char_length(_touched_by) > 0 then
			_user_assigned := true;
		end if;

		select into _id id from collection_host_hv_pool where poolid=_pool_id;
		if _id is not null then
			update collection_host_hv_pool
				set collection_host_id=_host_id,
					state=_state,
					user_assigned=_user_assigned,
					touched_by=_touched_by,
					tstamp=getutcdate()
				where id=_id;
		else
			insert into collection_host_hv_pool(
				collection_host_id,
				poolid,
				state,
				user_assigned,
				touched_by,
				tstamp)
				values (_host_id,
				_pool_id,
				_state,
				_user_assigned,
				_touched_by,
				getutcdate()) returning id into _id;
		end if;
	end if;
	return _id;
end;
$$ language plpgsql;

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: May 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 18, 2010	
-- Description:	
--   Assign a hypervisor pools to a data collection for monitoring.
-- Parameters:
--   host_name  - name of the data collection hosts to which the pool is 
--                being assigned.
--   pool_uuid  - The unique ID (uuid column of the hv_pool table) of the
--                hypervisor pool.
--   state      - The current state of data collection:  active, inactive,
--                not collecting.
--   touched_by - The name of the user making the assignment.  Should be
--                NULL is the assignment is made by the system.
-- Returns:
--   If successful, the id column of the row in the collection_host_hv_pool 
--   tables that represents the data collection host/pool relationship.
--   -2 if the host_name is not valid.
--   -3 if the pool_uuid is not valid.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".assign_pool_to_collection_host_by_uuid
(
	_host_name varchar(256),
	_pool_uuid varchar(48),
	_state int,
	_touched_by varchar(50)
);

create function "WorkloadBalancing".assign_pool_to_collection_host_by_uuid
(
	_host_name varchar(256),
	_pool_uuid varchar(48),
	_state int,
	_touched_by varchar(50)
) returns int as $$

declare _pool_id int;
	_host_id int;
	_id int;
	_user_assigned boolean;
begin
	-- Get the database ID of the data collection host.
	select into _host_id id from collection_host where hostname=_host_name;
	if _host_id is null then
		_id = -2; -- Invalid host.
		return _id;
	end if;

	-- Get the database ID of the hypervisor pool.
	select into _pool_id id from hv_pool where uuid=_pool_uuid;
	if _pool_id is null then
		_id = -3; -- Invalid pool.
		return _id;
	end if;

	if _host_id is not null and _pool_id is not null then
		select into _id assign_pool_to_collection_host (_host_id, _pool_id, _state, _touched_by);
	end if;

	return _id;
end;
$$ language plpgsql;

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: 	November 18, 2008
-- Updated:		November 16, 2010
--			Conversion to PostGreSQL
-- Modified: Barbara Li, March 16, 2012
--			 Using temptable
-- Description:		Consolidate the 'real time' host metrics into 5 minute chunks.
-- Parameters:
--   None
-- Returns:
--   n/a
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".consolidate_host_metrics();

create function "WorkloadBalancing".consolidate_host_metrics
()
RETURNS VOID AS
$$
declare _maxdate timestamp;

BEGIN

	_maxdate := "WorkloadBalancing".datetimeadd((select max(host_metric.tstamp) from host_metric), '-7 minute');

	-- Consolidate everything older than five minutes into 5 minute chunks.
	insert into host_metric_con
	(	hostid,
		avg_total_mem,
		avg_free_mem,
		avg_total_cpu,
		avg_total_pif_read_per_sec,
		avg_total_pif_write_per_sec,
		avg_load_average,
		max_total_mem,
		max_free_mem,
		max_total_cpu,
		max_total_pif_read_per_sec,
		max_total_pif_write_per_sec,
		max_load_average,
		min_total_mem,
		min_free_mem,
		min_total_cpu,
		min_total_pif_read_per_sec,
		min_total_pif_write_per_sec,
		min_load_average,
		start_time,
		end_time,
		intervalid)
	select	
		hostid,
		avg(total_mem),
		avg(free_mem),
		avg(avg_cpu_utilization),
		avg(avg_pif_read_per_sec),
		avg(avg_pif_write_per_sec),
		avg(load_average),
		max(total_mem),
		max(free_mem),
		max(avg_cpu_utilization),
		max(avg_pif_read_per_sec),
		max(avg_pif_write_per_sec),
		max(load_average),
		min(total_mem),
		min(free_mem),
		min(avg_cpu_utilization),
		min(avg_pif_read_per_sec),
		min(avg_pif_write_per_sec),
		min(load_average),
		min(host_metric.tstamp), 
		max(host_metric.tstamp),
		host_metric.intervalid		   
	from host_metric 
		join consolidation_intervals on (host_metric.intervalid = consolidation_intervals.intervalid)
	where consolidation_intervals.tstamp < _maxdate
	group by hostid, host_metric.intervalid;

	
	create temporary table temptable
	as 
		select 	host_metric.id as host_metric_id, 
			host_metric_con.id as  host_metric_con_id
		from host_metric 
			inner join host_metric_con on (host_metric.hostid = host_metric_con.hostid and host_metric.intervalid = host_metric_con.intervalid)	
			inner join consolidation_intervals on (host_metric.intervalid = consolidation_intervals.intervalid)
		where consolidation_intervals.tstamp < _maxdate;
		

	insert into host_cpu_metric_con
	(	host_metric_id,
		cpu,
		avg_utilization,
		max_utilization,
		min_utilization	
	)
	select	temptable.host_metric_con_id,
		host_cpu_metric.cpu,
		avg(host_cpu_metric.utilization), 
		max(utilization), 
		min(utilization)
	from 	host_cpu_metric
		inner join temptable on (host_cpu_metric.host_metric_id = temptable.host_metric_id)
	group by temptable.host_metric_con_id, host_cpu_metric.cpu;


	insert into host_pif_metric_con
	(	host_metric_id,
		pif,
		avg_read_per_sec,
		avg_write_per_sec,
		max_read_per_sec,
		max_write_per_sec,
		min_read_per_sec,
		min_write_per_sec	
	)
	select temptable.host_metric_con_id,
		host_pif_metric.pif,
		avg(host_pif_metric.io_read_per_sec), 
		avg(host_pif_metric.io_write_per_sec), 
		max(host_pif_metric.io_read_per_sec), 
		max(host_pif_metric.io_write_per_sec), 
		min(host_pif_metric.io_read_per_sec), 
		min(host_pif_metric.io_write_per_sec)
	from host_pif_metric
		inner join temptable on (host_pif_metric.host_metric_id = temptable.host_metric_id)
	group by temptable.host_metric_con_id, host_pif_metric.pif;

	drop table temptable;

	-- Delete the all data older than 5 minutes from host_metric.
	-- host_cpu_metric and host_pif_metric data will also be deleted
	-- via the "cascade delete" property.
	delete from host_metric
	using consolidation_intervals
	where host_metric.intervalid = consolidation_intervals.intervalid
		and consolidation_intervals.tstamp < _maxdate;
	
END;
$$
LANGUAGE 'plpgsql';

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: 	May 16, 2008
-- Updated:		November 18, 2010
--			Conversion to PostGreSQL
-- Modified: Barbara Li, March 16, 2012
--			 Using temptable
-- Description:		Consolidate the 'real time' virtual machine metrics into 5
--              	minute chunks.
-- Parameters:
--   None
-- Returns:
--   n/a
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".consolidate_vm_metrics();

create function "WorkloadBalancing".consolidate_vm_metrics
()
RETURNS VOID AS
$$
declare _maxdate timestamp;

BEGIN

	_maxdate := "WorkloadBalancing".datetimeadd((select max(vm_metric.tstamp) from vm_metric), '-7 minute');

	insert into vm_metric_con
	(	vmid,
		hostid,
		avg_total_mem,
		avg_free_mem,
        avg_target_mem,
		avg_cpu,
		avg_vif_read,
		avg_vif_write,
		avg_vbd_read,
		avg_vbd_write,
		total_vbd_net_read,
		total_vbd_net_write,
		max_total_mem,
		max_free_mem,
        max_target_mem,
		max_cpu,
		max_vif_read,
		max_vif_write,
		max_vbd_read,
		max_vbd_write,
		max_total_vbd_net_read,
		max_total_vbd_net_write,
		min_total_mem,
		min_free_mem,
        min_target_mem,
		min_cpu,
		min_vif_read,
		min_vif_write,
		min_vbd_read,
		min_vbd_write,
		min_total_vbd_net_read,
		min_total_vbd_net_write,
		avg_runstate_blocked,	
		avg_runstate_partial_run,
		avg_runstate_fullrun,
		avg_runstate_partial_contention,
		avg_runstate_concurrency_hazard,
		avg_runstate_full_contention,								
		start_time,
		end_time,
		intervalid
	)
	select	vmid,
		hostid,
		avg(total_mem),
		avg(free_mem),
        avg(target_mem),
		avg(avg_cpu),
		avg(avg_vif_read),
		avg(avg_vif_write),
		avg(avg_vbd_read),
		avg(avg_vbd_write),
		avg(total_vbd_net_read),
		avg(total_vbd_net_write),
		max(total_mem),
		max(free_mem),
        max(target_mem),
		max(avg_cpu),
		max(avg_vif_read),
		max(avg_vif_write),
		max(avg_vbd_read),
		max(avg_vbd_write),
		max(total_vbd_net_read),
		max(total_vbd_net_write),
		min(total_mem),
		min(free_mem),
        min(target_mem),
		min(avg_cpu),
		min(avg_vif_read),
		min(avg_vif_write),
		min(avg_vbd_read),
		min(avg_vbd_write),
		min(total_vbd_net_read),
		min(total_vbd_net_write),
		avg(runstate_blocked),	
		avg(runstate_partial_run),
		avg(runstate_fullrun),
		avg(runstate_partial_contention),
		avg(runstate_concurrency_hazard),
		avg(runstate_full_contention),											
		min(vm_metric.tstamp), 
		max(vm_metric.tstamp),
		vm_metric.intervalid		   
	from vm_metric
		join consolidation_intervals on (vm_metric.intervalid = consolidation_intervals.intervalid)
	where consolidation_intervals.tstamp < _maxdate
	group by vmid, hostid, vm_metric.intervalid;


	create temporary table temptable
	as 
		select 	vm_metric.id as vm_metric_id, 
			vm_metric_con.id as  vm_metric_con_id
		from vm_metric 
			inner join consolidation_intervals on (vm_metric.intervalid = consolidation_intervals.intervalid)
			--get vm_metric_con.id
			inner join vm_metric_con  on (vm_metric.vmid = vm_metric_con.vmid and vm_metric.intervalid = vm_metric_con.intervalid)
		where consolidation_intervals.tstamp < _maxdate;
			

	insert into vm_cpu_metric_con
	( 	vm_metric_id,
		cpu,
		avg_utilization,
		max_utilization,
		min_utilization	
	)
	select 	temptable.vm_metric_con_id,
		vm_cpu_metric.cpu,
		avg(vm_cpu_metric.utilization), 
		max(vm_cpu_metric.utilization), 
		min(vm_cpu_metric.utilization)
	from	vm_cpu_metric
		inner join temptable on vm_cpu_metric.vm_metric_id = temptable.vm_metric_id
	group by temptable.vm_metric_con_id, vm_cpu_metric.cpu;


	insert into vm_vif_metric_con
	(	vm_metric_id,
		vif,
		avg_read_per_sec,
		avg_write_per_sec,
		max_read_per_sec,
		max_write_per_sec,
		min_read_per_sec,
		min_write_per_sec	
	)
	select 	temptable.vm_metric_con_id,
		vm_vif_metric.vif,
		avg(vm_vif_metric.io_read_per_sec), 
		avg(vm_vif_metric.io_write_per_sec), 
		max(vm_vif_metric.io_read_per_sec), 
		max(vm_vif_metric.io_write_per_sec), 
		min(vm_vif_metric.io_read_per_sec), 
		min(vm_vif_metric.io_write_per_sec)
	from vm_vif_metric 
		inner join temptable on vm_vif_metric.vm_metric_id = temptable.vm_metric_id
	group by temptable.vm_metric_con_id, vm_vif_metric.vif;


	insert into vm_vbd_metric_con
	(	vm_metric_id,
		vbd,
		avg_read_per_sec,
		avg_write_per_sec,
		max_read_per_sec,
		max_write_per_sec,
		min_read_per_sec,
		min_write_per_sec	
	)
	select 	temptable.vm_metric_con_id,
		vm_vbd_metric.vbd,
		avg(vm_vbd_metric.io_read_per_sec), 
		avg(vm_vbd_metric.io_write_per_sec), 
		max(vm_vbd_metric.io_read_per_sec), 
		max(vm_vbd_metric.io_write_per_sec), 
		min(vm_vbd_metric.io_read_per_sec), 
		min(vm_vbd_metric.io_write_per_sec)
	from	vm_vbd_metric 
		inner join temptable on vm_vbd_metric.vm_metric_id = temptable.vm_metric_id
	group by temptable.vm_metric_con_id, vm_vbd_metric.vbd;

	drop table temptable;

	-- Delete the all data older than 5 minutes from vm_metric.
	-- vm_cpu_metric and vm_pif_metric data will also be deleted
	-- via the "cascade delete" property.
	delete from vm_metric
	using consolidation_intervals
	where vm_metric.intervalid = consolidation_intervals.intervalid
		and consolidation_intervals.tstamp < _maxdate;

END;
$$
LANGUAGE 'plpgsql';

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: 	November 20, 2008
-- Updated:		November 17, 2010
-- 			Converted to PostGreSQL
-- Modified: Barbara Li, March 16, 2012
--			 Using temptable
-- Description:		Consolidate the 5-minute consolidated host metrics into 60 minute chunks.
-- Parameters:
--   None
-- Returns:
--   n/a
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".consolidate_host_metrics_history();

create  function "WorkloadBalancing".consolidate_host_metrics_history
()
RETURNS VOID AS
$$
declare _maxdate timestamp;
BEGIN

	_maxdate := "WorkloadBalancing".datetimeadd("WorkloadBalancing".getutcdate(), '-60 minute');

	-- Consolidate everything older than five minutes into 5 minute chunks.
	insert into host_metric_history
	(	hostid,
		avg_total_mem,
		avg_free_mem,
		avg_total_cpu,
		avg_total_pif_read_per_sec,
		avg_total_pif_write_per_sec,
		avg_load_average,
		max_total_mem,
		max_free_mem,
		max_total_cpu,
		max_total_pif_read_per_sec,
		max_total_pif_write_per_sec,
		max_load_average,
		min_total_mem,
		min_free_mem,
		min_total_cpu,
		min_total_pif_read_per_sec,
		min_total_pif_write_per_sec,
		min_load_average,
		start_time,
		end_time,
		intervalid
	)
	select	host_metric_con.hostid,
		avg(host_metric_con.avg_total_mem),
		avg(host_metric_con.avg_free_mem),
		avg(host_metric_con.avg_total_cpu),
		avg(host_metric_con.avg_total_pif_read_per_sec),
		avg(host_metric_con.avg_total_pif_write_per_sec),
		avg(host_metric_con.avg_load_average),
		max(host_metric_con.max_total_mem),
		max(host_metric_con.max_free_mem),
		max(host_metric_con.max_total_cpu),
		max(host_metric_con.max_total_pif_read_per_sec),
		max(host_metric_con.max_total_pif_write_per_sec),
		max(host_metric_con.max_load_average),
		min(host_metric_con.min_total_mem),
		min(host_metric_con.min_free_mem),
		min(host_metric_con.min_total_cpu),
		min(host_metric_con.min_total_pif_read_per_sec),
		min(host_metric_con.min_total_pif_write_per_sec),
		min(host_metric_con.min_load_average),
		min(host_metric_con.start_time),
		max(host_metric_con.end_time),
		min(host_metric_con.intervalid)
	from	host_metric_con
		inner join consolidation_intervals on (host_metric_con.intervalid = consolidation_intervals.intervalid)
	where	host_metric_con.is_compacted = false
	group by host_metric_con.hostid, consolidation_intervals.hour_interval
	having max(consolidation_intervals.tstamp) < _maxdate;
	
	
	create temporary table temptable
	as 
		select 	host_metric_history.id as host_metric_history_id, 
			host_metric_con.id as  host_metric_con_id
		from host_metric_con 
			--get host_metric_history.id
			inner join host_metric_history on (host_metric_con.hostid = host_metric_history.hostid
					   and host_metric_con.intervalid = host_metric_history.intervalid)
			-- then get the hour_interval
			inner join consolidation_intervals on (host_metric_history.intervalid = consolidation_intervals.intervalid);

			
	insert into host_cpu_metric_history
	(	host_metric_id,
		cpu,
		avg_utilization,
		max_utilization,
		min_utilization 
	)
	select	temptable.host_metric_history_id,
		host_cpu_metric_con.cpu,
		avg(host_cpu_metric_con.avg_utilization),
		max(host_cpu_metric_con.max_utilization),
		max(host_cpu_metric_con.min_utilization)
	from	host_cpu_metric_con
		inner join temptable on (host_cpu_metric_con.host_metric_id = temptable.host_metric_con_id)
	group by temptable.host_metric_history_id, host_cpu_metric_con.cpu;


	insert into host_pif_metric_history
	(	host_metric_id,
		pif,
		avg_read_per_sec,
		avg_write_per_sec,
		max_read_per_sec,
		max_write_per_sec,
		min_read_per_sec,
		min_write_per_sec	
	)
	select 	temptable.host_metric_history_id,
		host_pif_metric_con.pif,
		avg(host_pif_metric_con.avg_read_per_sec),
		avg(host_pif_metric_con.avg_write_per_sec),
		max(host_pif_metric_con.max_read_per_sec),
		max(host_pif_metric_con.max_write_per_sec),
		min(host_pif_metric_con.min_read_per_sec),
		min(host_pif_metric_con.min_write_per_sec)
	from	host_pif_metric_con
		inner join temptable on (host_pif_metric_con.host_metric_id = temptable.host_metric_con_id)
	group by temptable.host_metric_history_id, host_pif_metric_con.pif;

	drop table temptable;

	update host_metric_con
		set is_compacted = true
	from consolidation_intervals
	where host_metric_con.intervalid = consolidation_intervals.intervalid
		and consolidation_intervals.tstamp < _maxdate;

	delete from host_metric_con
	using consolidation_intervals
	where host_metric_con.intervalid = consolidation_intervals.intervalid
		and is_compacted = true
		and consolidation_intervals.tstamp < "WorkloadBalancing".datetimeadd(_maxdate, '-30 hour');

END;
$$
LANGUAGE 'plpgsql';


-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: 	November 20, 2008
-- Updated:		November 19, 2010
-- 			Converted to PostGreSQL
-- Modified: Barbara Li, March 16, 2012
--			 Using temptable
-- Description:		Consolidate the 5-minute consolidated virtual machine metrics into 60 minute chunks.
-- Parameters:
--   None
-- Returns:
--   n/a
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".consolidate_vm_metrics_history();

create function "WorkloadBalancing".consolidate_vm_metrics_history
()
RETURNS VOID AS
$$
declare _maxdate timestamp;
BEGIN

	_maxdate := "WorkloadBalancing".datetimeadd("WorkloadBalancing".getutcdate(), '-60 minute');

	insert into vm_metric_history
	(	vmid,
		hostid,
		avg_total_mem,
		avg_free_mem,
        avg_target_mem,
		avg_cpu,
		avg_vif_read,
		avg_vif_write,
		avg_vbd_read,
		avg_vbd_write,
		total_vbd_net_read,
		total_vbd_net_write,
		max_total_mem,
		max_free_mem,
        max_target_mem,
		max_cpu,
		max_vif_read,
		max_vif_write,
		max_vbd_read,
		max_vbd_write,
		max_total_vbd_net_read,
		max_total_vbd_net_write,
		min_total_mem,
		min_free_mem,
        min_target_mem,
		min_cpu,
		min_vif_read,
		min_vif_write,
		min_vbd_read,
		min_vbd_write,
		min_total_vbd_net_read,
		min_total_vbd_net_write,
		avg_runstate_blocked,	
		avg_runstate_partial_run,
		avg_runstate_fullrun,
		avg_runstate_partial_contention,
		avg_runstate_concurrency_hazard,
		avg_runstate_full_contention,								
		start_time,
		end_time,
		intervalid
	) 
	select	vm_metric_con.vmid,
		vm_metric_con.hostid,
		avg(vm_metric_con.avg_total_mem),
		avg(vm_metric_con.avg_free_mem),
        avg(vm_metric_con.avg_target_mem),
		avg(vm_metric_con.avg_cpu),
		avg(vm_metric_con.avg_vif_read),
		avg(vm_metric_con.avg_vif_write),
		avg(vm_metric_con.avg_vbd_read),
		avg(vm_metric_con.avg_vbd_write),
		avg(vm_metric_con.total_vbd_net_read),
		avg(vm_metric_con.total_vbd_net_write),
		max(vm_metric_con.max_total_mem),
		max(vm_metric_con.max_free_mem),
        max(vm_metric_con.max_target_mem),
		max(vm_metric_con.max_cpu),
		max(vm_metric_con.max_vif_read),
		max(vm_metric_con.max_vif_write),
		max(vm_metric_con.max_vbd_read),
		max(vm_metric_con.max_vbd_write),
		max(vm_metric_con.total_vbd_net_read),
		max(vm_metric_con.total_vbd_net_write),
		min(vm_metric_con.min_total_mem),
		min(vm_metric_con.min_free_mem),
        min(vm_metric_con.min_free_mem),
		min(vm_metric_con.min_cpu),
		min(vm_metric_con.min_vif_read),
		min(vm_metric_con.min_vif_write),
		min(vm_metric_con.min_vbd_read),
		min(vm_metric_con.min_vbd_write),
		min(vm_metric_con.total_vbd_net_read),
		min(vm_metric_con.total_vbd_net_write),
		avg(avg_runstate_blocked),	
		avg(avg_runstate_partial_run),
		avg(avg_runstate_fullrun),
		avg(avg_runstate_partial_contention),
		avg(avg_runstate_concurrency_hazard),
		avg(avg_runstate_full_contention),							
		min(vm_metric_con.start_time),
		max(vm_metric_con.end_time),
		min(vm_metric_con.intervalid)
	from 	vm_metric_con
		inner join consolidation_intervals on (vm_metric_con.intervalid = consolidation_intervals.intervalid)
	where vm_metric_con.is_compacted = false
	group by vm_metric_con.vmid, vm_metric_con.hostid, consolidation_intervals.hour_interval
	having max(consolidation_intervals.tstamp) < _maxdate;


	create temporary table temptable
	as 
		select 	vm_metric_history.id as vm_metric_history_id, 
			vm_metric_con.id as  vm_metric_con_id
		from vm_metric_con 
			--get vm_metric_history.id
			inner join vm_metric_history on	(vm_metric_con.vmid = vm_metric_history.vmid
					 and vm_metric_con.intervalid = vm_metric_history.intervalid)
			-- then get the hour_interval
			inner join consolidation_intervals on (vm_metric_history.intervalid = consolidation_intervals.intervalid);
			
	
	insert into vm_cpu_metric_history
	( 	vm_metric_id,
		cpu,
		avg_utilization,
		max_utilization,
		min_utilization	
	)
	select	temptable.vm_metric_history_id,
		vm_cpu_metric_con.cpu,
		avg(vm_cpu_metric_con.avg_utilization),
		max(vm_cpu_metric_con.max_utilization),
		min(vm_cpu_metric_con.min_utilization)
	from	vm_cpu_metric_con
		inner join temptable on (vm_cpu_metric_con.vm_metric_id = temptable.vm_metric_con_id)
	group by temptable.vm_metric_history_id, vm_cpu_metric_con.cpu;


	insert into vm_vif_metric_history
	(	vm_metric_id,
		vif,
		avg_read_per_sec,
		avg_write_per_sec,
		max_read_per_sec,
		max_write_per_sec,
		min_read_per_sec,
		min_write_per_sec	
	)
	select	temptable.vm_metric_history_id,
		vm_vif_metric_con.vif,
		avg(vm_vif_metric_con.avg_read_per_sec),
		avg(vm_vif_metric_con.avg_write_per_sec),
		max(vm_vif_metric_con.max_read_per_sec),
		max(vm_vif_metric_con.max_write_per_sec),
		min(vm_vif_metric_con.min_read_per_sec),
		min(vm_vif_metric_con.min_write_per_sec)
	from	vm_vif_metric_con
		inner join temptable on (vm_vif_metric_con.vm_metric_id = temptable.vm_metric_con_id)
	group by temptable.vm_metric_history_id, vm_vif_metric_con.vif;


	insert into vm_vbd_metric_history
	(	vm_metric_id,
		vbd,
		avg_read_per_sec,
		avg_write_per_sec,
		max_read_per_sec,
		max_write_per_sec,
		min_read_per_sec,
		min_write_per_sec	
	)
	select	temptable.vm_metric_history_id,
		vm_vbd_metric_con.vbd,
		avg(vm_vbd_metric_con.avg_read_per_sec),
		avg(vm_vbd_metric_con.avg_write_per_sec),
		max(vm_vbd_metric_con.max_read_per_sec),
		max(vm_vbd_metric_con.max_write_per_sec),
		min(vm_vbd_metric_con.min_read_per_sec),
		min(vm_vbd_metric_con.min_write_per_sec)
	from	vm_vbd_metric_con
		inner join temptable on (vm_vbd_metric_con.vm_metric_id = temptable.vm_metric_con_id)
	group by temptable.vm_metric_history_id, vm_vbd_metric_con.vbd;

	drop table temptable;
	
	update vm_metric_con
	set is_compacted = true 
	from consolidation_intervals
	where vm_metric_con.intervalid = consolidation_intervals.intervalid
		and consolidation_intervals.tstamp < _maxdate;

	delete from vm_metric_con
	using consolidation_intervals
	where vm_metric_con.intervalid = consolidation_intervals.intervalid
		and is_compacted = true
		and consolidation_intervals.tstamp <  "WorkloadBalancing".datetimeadd(_maxdate, '-30 hour');

END;
$$
LANGUAGE 'plpgsql';

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:        Sept 19, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 29, 2010
-- Description:
--	 Retrieve the list of data collection host - hypervisor pools to monitor
--	 assignments.
-- Parameters:
--   None
-- Returns:
--   One result set.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_get_assignments();

create function "WorkloadBalancing".data_collection_get_assignments
(
)
returns setof name_id_pair as $$

declare 
	r name_id_pair%rowtype;
begin

	for r in 
		select ch.hostname,
			chp.poolid 
		from collection_host ch
			left join collection_host_hv_pool chp on chp.collection_host_id=ch.id
		order by ch.hostname loop
		return next r;
	end loop;
	return;
end; $$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			June 1, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 23, 2010	
-- Description:
--	 Retrieve and hypervisor pools, data collection hosts or pool hosts
--   relationships that have changed since the specified time stamp.
-- Parameters:
--   tstamp  - UTC date and time after which changes should be returned.
-- Returns:
--   Two result sets -
--		1.  The hypervisor pools that have been added since _tstamp.
--		2.  Pool/host relationships that have been added or changed since
--		    _tstamp.  This will include new collection hosts that have not 
--		    been assigned hypervisor pools to monitor.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_get_new_resources
(
	_tstamp	timestamp
);

create function "WorkloadBalancing".data_collection_get_new_resources
(
	_tstamp	timestamp
) returns setof refcursor as $$

declare 
	_num_new_assignments int;
	_num_deletes int;
	cur1 refcursor;
	cur2 refcursor;
	cur3 refcursor;

begin
	create temp table _deleted_pools (id int, pool_id int) on commit drop;

	-- Get any pool that have been deleted.
	insert into _deleted_pools
		select id, pool_id 
		from hv_deleted_pool
		where status=1;

	_num_deletes := (select count(*) from _deleted_pools);

	-- Get any new hypervisor pools that have not been assigned a data
	-- collection host.
	open cur1 for
		select id 
		from hv_pool 
		where tstamp > _tstamp and 
		  id not in(select chp.poolid 
					from collection_host_hv_pool chp
					left join collection_host ch 
						on chp.collection_host_id=ch.id);
	return next cur1;
	
	-- Check to see if there are any new or updated collection host/pool
	-- relationships
	if (_num_deletes = 0) then
		select into _num_new_assignments count(*)
			from collection_host_hv_pool 	
			where user_assigned=true and tstamp>_tstamp;
	end if;

	-- If there are new or updated assignments or a pool has been deleted,
	-- get all the assignments.
	if (_num_new_assignments> 0 or _num_deletes > 0) then
		open cur2 for
			select ch.hostname, chp.poolid
			from collection_host ch
			left join collection_host_hv_pool chp 
				on chp.collection_host_id=ch.id;
		return next cur2;
	end if;

	if(_num_deletes > 0) then
		open cur3 for
			select id, pool_id from
			_deleted_pools;
		return next cur3;
	end if;
	
	if (_num_deletes > 0) then
		update hv_deleted_pool
			set status=0
			where id in (select id from _deleted_pools);
	end if;

	
	
	return;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Retrieve the hypervisor pools that are not assigned to a collection host.
-- Parameters:
--   None
-- Returns:
--   One result set.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_get_unassigned_pools();

create function "WorkloadBalancing".data_collection_get_unassigned_pools
(
) returns setof refcursor as $$

declare 
	_ids	refcursor;

begin
	open _ids for 
		select p.id 
		from hv_pool p 
			left outer join collection_host_hv_pool chp on chp.poolid=p.id
		where chp.id is null;
	return next _ids;
	return;
end;
$$ language plpgsql;

/*
drop function "WorkloadBalancing".data_collection_get_unassigned_pools()

select "WorkloadBalancing".data_collection_get_unassigned_pools()
*/

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:        Sept 19, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 29, 2010
-- Description:
--	 Retrieve the list of Hypervisor pools that will be monitor by the 
--   specified data collection host computer.
-- Parameters:
--   _hostname         - The name of the data collection computer whose pools
--                       are to be retrieved.
--   _collection_state - The collection state of the pool to retrieve
-- Returns:
--   One result set.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_get_pools
(
	_hostname         	varchar(256),
	_collection_state 	int
);


create function "WorkloadBalancing".data_collection_get_pools
(
	_hostname         	varchar(256),
	_collection_state 	int
) returns setof pool_basic_info as $$

declare
	r pool_basic_info%rowtype;
begin
	FOR r IN SELECT p.id,
		   p.hv_type,
		   p.pool_master_1_addr,
		   p.pool_master_1_port,
		   p.protocol,
		   p.username,
		   p.password
	FROM collection_host ch
	JOIN collection_host_hv_pool chp on chp.collection_host_id=ch.id
	JOIN hv_pool p on p.id=chp.poolid
	WHERE ch.hostname=_hostname and
		  chp.state>=_collection_state and
		  p.active = TRUE LOOP
		RETURN NEXT r;
		END LOOP;
	RETURN;

end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:        Dec 2, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 29, 2010
-- Description:
--	 Retrieve basic connection information for all Hypervisor pools 
--	 that are being monitored.
-- Parameters:
--   none
-- Returns:
--   One result set.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_get_all_pools();

create function "WorkloadBalancing".data_collection_get_all_pools()
returns setof pool_basic_info as $$
declare 
	r pool_basic_info%rowtype;
begin
	for r in select id,
		   hv_type,
		   pool_master_1_addr,
		   pool_master_1_port,
		   protocol,
		   username,
		   password
	from hv_pool 
	where active=TRUE loop
	return next r;
	end loop;
	return;
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:        		Sept 19, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 29, 2010
-- Description:
--	 Attempt to become the new data collection master.
-- Parameters:
--   _old_master  - The name of the current data collection master computer.
--   _new_master  - The name of the new data collection master computer.
-- Returns:
--   Name of the computer that is the data collection master.  That name may
--   not be _new_master
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_become_master
(
	_old_master varchar(256),
	_new_master varchar(256)
);

create function "WorkloadBalancing".data_collection_become_master
(
	_old_master varchar(256),
	_new_master varchar(256)
) returns varchar(256) as $$

declare
	_numrows int;
	_host varchar(256);
	_row_lock bytea;

begin
	select count(*) into _numrows from collection_master;
	if _numrows = 0 then		
		insert into collection_master (id) select id from collection_host where hostname=_new_master;
	else	
          select into _host, _row_lock ch.hostname, cm.row_lock 
			from collection_host ch
		join collection_master cm on ch.id=cm.id;

		if _host=_old_master then
			update collection_master
				set id=(select id from collection_host where hostname=_new_master)
				where row_lock=_row_lock;
		end if;
       end if;

	select ch.hostname into _host from collection_host ch
		join collection_master cm on ch.id=cm.id;
	return _host;

end;

$$ language plpgsql;




-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:        Sept 19, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 19, 2010
-- Description:
--	 Retrieve the name of the computer that is the data collection master
-- Parameters:
--   none
-- Returns:
--   Name of the computer that is the data collection master
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_get_master();

create function "WorkloadBalancing".data_collection_get_master() 
returns varchar(256) as $$
declare 
	_name varchar(256);
begin
	select ch.hostname into _name
		from collection_host ch
	    join collection_master cm on ch.id=cm.id;
	return _name;
end;
$$ language plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:	Register a computer that will act as a WorkloadBalancing data
--              collector.
-- Parameters:
--     @hostname    - The name of the computer on which the data collector 
--		      is running.
--     @domain_name - The name of the domain to which the computer belongs.
--                    whose physical hosts are to be retrieved.
--     @tstamp      - The current UTC date and time.
-- Returns:
--   The database ID (id column of the collection_host table) data collection
--   computer.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_register
(
	_hostname    varchar(256),
	_domain_name varchar(256),
	_tstamp      timestamp
);

create function "WorkloadBalancing".data_collection_register
(
	_hostname    varchar(256),
	_domain_name varchar(256),
	_tstamp      timestamp
) returns int as $$

declare 
	_id 	int;

begin

	_id := (select id from collection_host where hostname=_hostname and domain_name=_domain_name);

	if _id is null then
		insert into collection_host (hostname, domain_name, tstamp)
			values (_hostName, _domain_name, _tstamp);
	end if;

	_id := (select id from collection_host where hostname=_hostname and domain_name=_domain_name);

	return _id;
end;
$$ language plpgsql; 

/*
select data_collection_register('bosdbarbarali00','CITRITE','2010-12-06T22:18:51.024')
*/


-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:        Oct 7, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 29, 2010
-- Description:
--	 Retrieve the status of the data collection and analysis subsystem.
-- Parameters:
--   none
-- Returns:
--   Status of the data collection and analysis subsystem.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_get_status();

create function "WorkloadBalancing".data_collection_get_status() 
returns setof dc_status as $$

declare
	r dc_status%rowtype;
	_count int;
begin
	select into _count count(*) from collection_status;

	IF _count = 0 THEN
		for r in select * from  data_collection_set_status(0, 0) loop
		return next r;
		end loop;
	ELSE
		for r in select status, row_lock from collection_status 
			order by id desc limit 1 loop
		RETURN NEXT r;
		END LOOP;
	END IF;
	RETURN;
	
END;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:        Sept 19, 2008
-- Description:
--	 Set the status of the data collection subsystem.
-- Parameters:
--   _status   - the status to set
--	 _row_lock - the database lock returned by data_collection_get_status
-- Returns:
--   The status of the data collection subsystem.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_set_status
(
	_status   int,
	_row_lock bigint
);

create function "WorkloadBalancing".data_collection_set_status
(
	_status   int,
	_row_lock bigint
) returns setof dc_status as $$

declare 
	r dc_status;
	_numrows int;
begin
	select into _numrows count(*) from collection_status;

	if _numrows = 0 then
		insert into collection_status (status) values (_status);
	else
		update collection_status set status=_status where row_lock=_row_lock;
	end if;

	for r in select * from data_collection_get_status() loop
	return next r;
	end loop;
	return;
end;
$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Deane Smith
-- Date:        April 19, 2010
-- Converted on: 5 Jan, 2011 
-- By: Rabin Karki
-- Description:
--	 Delete's status of the data collection subsystem.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".data_collection_reset_status();

create or replace function "WorkloadBalancing".data_collection_reset_status()
returns void as
$$
begin
	delete from collection_status;
end;
$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Create date: 		February 5 ,2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 21, 2010
-- Description:
--	 Delete the specified physical host by setting it's active flag to false.
-- Parameters:
--   pool_id     - The database ID (id column of the hv_pool table) of the
--				   pool containing the host to delete.
--   host_id     - The database ID (id column of the hv_host table) of the
--				   host to delete.
--   tstamp      - The UTC date and time the host was deleted

-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".delete_hv_host
(	
	_pool_id  int,
	_host_id  int,
	_tstamp timestamp
);

create function "WorkloadBalancing".delete_hv_host
(	
	_pool_id  int,
	_host_id  int,
	_tstamp timestamp
) returns void as $$

declare 
	_is_active boolean;
begin
	select active into _is_active from hv_host where id=_host_id;
	
	if _is_active then
		begin
			-- Mark the host as being delete.
			update hv_host set active=FALSE where id=_host_id;
			
			-- Delete the record that tracks this hosts entry in the pool.
			delete from hv_pool_host where poolid=_pool_id and hostid=_host_id;
			
			-- Regenerate the order that the hosts will be filled with 
			-- virtual machines when the optimization mode is max density.
			perform generate_fill_order (_pool_id);
		end;
	end if;
end;
$$ language plpgsql;



-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		June 16, 2008
-- Modified for PgSQL	Oct 14, 2010
-- Description:
--	 Delete all the pool-host relationship records for the specified pool
-- Parameters:
--   pool_id		- The database ID (id column of the hv_pool table) of the
--					  pool for which the pool-host relationship will be deleted.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".delete_hv_pool_host
( 
	_pool_id 	int
);

create function "WorkloadBalancing".delete_hv_pool_host ( _pool_id int) 
returns void as $$
begin
	delete from hv_pool_host where poolid=_pool_id;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			Sept 25, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Delete the specified hypervisor pool.
-- Parameters:
--   pool_id	- The database ID (id column of the hv_pool table) of the pool
--                to delete
-- Returns:
--   The number of row affected - non zero indicates sucdess.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".delete_pool_by_pool_id
(
	_pool_id int
);

create function "WorkloadBalancing".delete_pool_by_pool_id
(
	_pool_id int
) returns int as $$

declare 
	_touched_by  varchar(50);
	_deleted_id  int;
	_pool_uuid   varchar(48);
	_pool_name   varchar(256);
	_hv_type     int;
	_pool_addr   varchar(256);
	_description varchar(256);
	_deletedrowcount	 int;
	UTCTimestamp timestamp;

begin
	select into _deleted_id, _pool_uuid, _pool_name, _hv_type, _pool_addr, _description 
			id, uuid, name, hv_type, pool_master_1_addr, description
		from hv_pool where id=_pool_id;


	-- Delete the pool and ALL data associated with the pool
	delete from hv_audit where pool_id = _pool_id;
	delete from move_recommendation where poolid = _pool_id;
	delete from virtual_machine where poolid=_pool_id;
	delete from hv_host where poolid = _pool_id;
	delete from sched_task where poolid = _pool_id;
	delete from hv_pool where id = _pool_id;

	GET DIAGNOSTICS _deletedrowcount = ROW_COUNT;
	UTCTimestamp := (select current_timestamp at time zone 'UTC');

	if _deletedrowcount > 0 then
		-- Add a record to hv_deleted_pool and set the status such that
		-- the data collector will know this pool was just deleted.
		insert into hv_deleted_pool (pool_id, 
			pool_name,
			pool_uuid, 
			hv_type,
			pool_addr,
			description,
			status,
			touched_by,
			tstamp)									
			values (_deleted_id,
			_pool_name,
			_pool_uuid,
			_hv_type,
			_pool_addr,
			_description,
			1,
			_touched_by,
			UTCTimestamp);
	end if;

	-- Return the number of row affected.  Greater than 0 indicates success.
	return _deletedrowcount;

end;

$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			Sept 25, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Delete the specified hypervisor pool.
-- Parameters:
--   pool_uuid	- The unique identifier (uuid column of the hv_pool table) of 
--                the pool to delete
-- Returns:
--   The database ID of the deleted pool - non zero indicates success.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".delete_pool_by_pool_uuid
(
	_pool_uuid varchar(48)
);

create function "WorkloadBalancing".delete_pool_by_pool_uuid
(
	_pool_uuid varchar(48)
) returns int as $$
declare
	_num_rows bigint;
	_pool_id  int := null;

begin
	select into _pool_id id from hv_pool where uuid=_pool_uuid;

	if _pool_id is not null then
		select delete_pool_by_pool_id (_pool_id) into _num_rows;
		if (_num_rows > 0) then
			return _pool_id;
		end if;
	else
		return 0;
	end if;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Create date: November 	21, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Delete the specified VM by setting it's active flag to false.
-- Parameters:
--   vmid        - The database ID (id column of the virtual_machine table) of
--				   VM to delete.
--   tstamp      - The UTC date and time the VM was deleted

-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".delete_virtual_machine
(	
	_vm_id  int,
	_tstamp timestamp
);

create function "WorkloadBalancing".delete_virtual_machine
(	
	_vm_id  int,
	_tstamp timestamp
) returns void as $$
begin
	update virtual_machine set active=FALSE where id=_vm_id;

end;

$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		July 7, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 29, 2010
-- Description:
--	 Generate the order the order in which physical hosts or a hypervisor pool
--   will be filled with virtual machines
-- Parameters:
--   pool_id     - The database ID (id column of the hv_pool table) of the 
--                 hypervisor pool for which the fill order will be generated.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".generate_fill_order
(
	_pool_id	int
);

create function "WorkloadBalancing".generate_fill_order
(
	_pool_id	int
) returns void as $$
declare
	_hostid         int;
	_is_pool_master boolean;
	_num_vms        int;
	_i		int := 0;
	_pool_master_id int := null;
	_can_power      boolean;
	fill_order_cursor refcursor;
	
begin
	-- Get the hosts in the pool.
	create temporary table _hosts (hostid int, 
		 name           varchar(256), 
		 uuid           varchar(48),
		 num_cpus       int,
		 cpu_speed      int, 
		 num_pifs       int,
		 can_power      boolean, 
		 is_pool_master boolean) on commit drop;
	
	insert into _hosts
		select	h.id,
			h.name,
			h.uuid, 
			h.num_cpus,
			h.cpu_speed,
			h.num_pifs, 
			case hc.value
				when 'true'  then TRUE
				when 'TRUE'  then TRUE
				when '1'     then TRUE
				when 'false' then FALSE
				when 'FALSE' then FALSE
				when '0'     then FALSE
				else FALSE
			end,
			h.is_pool_master
		from hv_host h 
		join hv_pool_host ph on h.id=ph.hostid 
		left join hv_host_config hc on h.id=hc.host_id and hc.name='ParticipatesInPowerManagement'
		where ph.poolid=_pool_id;		

-- select * from _vms _hosts
-- select * from hv_pool_host
-- update hv_pool_host set fill_order = 0

	-- Get the number of VMs running on each host.
	create temporary table _vms (hostid int, num_vms int) on commit drop;
	insert into _vms 
		select	hostid,	count(*) 
			from host_vm 
			where hostid in (select hostid from _hosts)
			group by hostid;

	

	-- The hosts are first sorted by power management.  The hosts that don't 
	-- participate in power management will be filled first.  Within each
	-- group, the host most VMs is filled first.  The pool master is always
	-- filled last.
	open fill_order_cursor for
		select h.hostid, h.is_pool_master, h.can_power, v.num_vms from _hosts h
			join _vms v on h.hostid=v.hostid
			order by h.can_power, v.num_vms desc;

	-- open fill_order_cursor;

	--start fetching from cursor
	LOOP
	fetch fill_order_cursor into _hostid, _is_pool_master, _can_power, _num_vms;
	--while __fetch_status = 0

		IF NOT FOUND THEN
			EXIT;
		END IF;	

	if _is_pool_master then
		_i := _i+1;
		update hv_pool_host set fill_order = _i
			where poolid = _pool_id and hostid = _hostid;
		if not found then
			insert into hv_pool_host (poolid, hostid, fill_order) 
				values	(_pool_id, _hostid, _i);
		end if;
	else
		_pool_master_id := _hostid;
	end if;
	
	end loop;
	--loop ends here
	
	if _pool_master_id is not null then
		_i := _i + 1;
		--do the insert
		update hv_pool_host
			set fill_order=_i
			where poolid=_pool_id and hostid=_pool_master_id;

		if not found then
			insert into hv_pool_host (poolid, hostid, fill_order)
				values(_pool_id, _pool_master_id,_i);
		end if;
		
	end if;
	--close the cursor
	close fill_order_cursor;
	return;
end;
$$ language plpgsql;

-- select * from generate_fill_order (2);
-- select * from hv_pool_host
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Date:		November 18, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 17, 2010
-- Description:
--	 Add a row to the vm_metric table, returning the vmmetricid.
-- Parameters:
--   hour_interval		   - The hour of the day in which the metrics occurred (zero-based).
--   five_minute_interval  - The five minute interval of the day in which te metrics occurred (zero-based).
--   day_of_year		   - The day of the year in which the metrics occurred.
--	 year                  - The year in which the metrics occurred
-- Returns:
--   int                   - The database ID of the new or existing row containing the relavent interval data.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_consolidation_interval
(	
	_hour_interval int,
	_five_minute_interval int,
	_day_of_year int,
	_year int
);

create function "WorkloadBalancing".get_consolidation_interval
(	
	_hour_interval int,
	_five_minute_interval int,
	_day_of_year int,
	_year int
) returns int as $$

declare _interval_id int;

begin

	select into _interval_id intervalid 
		from consolidation_intervals
		where hour_interval = _hour_interval
			and five_minute_interval = _five_minute_interval
			and day_of_year = _day_of_year
			and year = _year;

	if _interval_id is null then
		insert into consolidation_intervals
			(	hour_interval,
				five_minute_interval,
				day_of_year,
				year,
				tstamp)
			values
			(	_hour_interval,
				_five_minute_interval,
				_day_of_year,
				_year,
				date '1900-01-01' 
					+ (_year-1900) * interval '1 year' 
					+ (_day_of_year-1) * interval '1 day' 
					+ (_five_minute_interval*5) * interval '1 minute') returning intervalid into _interval_id;

		
	end if;

	return _interval_id;
end;
$$ language plpgsql;




-- ==========================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: January 27, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 23, 2010	
-- Description:	Get the oldest date references in the consolidation 
--		intervals table
-- Parameters:
--   None
-- Returns:
--   Timestamp
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_earliest_consolidation_interval_date();

create function "WorkloadBalancing".get_earliest_consolidation_interval_date
()  returns timestamp as $$

declare 
	r	timestamp;
begin
	select 	tstamp into r
	from consolidation_intervals
	order by tstamp limit 1;

	return r;
	
end; $$
language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			Sept 4, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Retrieve the UTC date and time metrics where last recorded for the 
--   specified host.
-- Parameters:
--   host_id	- the database ID (id column of the hv_host table) of the host.
-- Returns:
--   UTC date and time metrics where last recorded for the host if data is
--   present; null otherwise.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_host_last_metric_time
(
	_host_id int
);

create function "WorkloadBalancing".get_host_last_metric_time
(
	_host_id int
) returns timestamp as $$
declare 
	_tstamp timestamp := null;
begin
	
	-- Check the non-consolidated data first.
	select into _tstamp tstamp 
		from host_metric 
		where hostid=_host_id 
		order by tstamp desc limit 1;

	if _tstamp is null then
		select into _tstamp end_time 
			from host_metric_con 
			where hostid=_host_id 
			order by end_time desc limit 1;
	end if;

	return _tstamp;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Date:		August 17, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 2, 2010
-- Description:
--	 Return the avg metrics for the last 30 minutes for all hosts in a pool
-- Parameters:
--   pool_id - the database ID (id column of the hv_pool table) of the pool
--             containing the hosts we are interested in.
-- Returns:
--   table of average host metrics
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_host_metrics_30_min
( 
	_pool_ids             int[]
);

create function "WorkloadBalancing".fn_get_avg_host_metrics_30_min
( 
	_pool_ids             int[]
) returns setof host_metrics as $$
declare
	r host_metrics%rowtype;
begin
	for r in select	hmc.hostid,
			hph.poolid,
			avg(avg_free_mem),
			0, --this field didn't exist before, was created so that we can reuse host_metrics type. Just ignore it if you're using this function
			avg(avg_total_cpu),
			avg(avg_total_pif_read_per_sec),
			avg(avg_total_pif_write_per_sec),
			avg(avg_load_average)
		from host_metric_con hmc
			join hv_pool_host hph on (hmc.hostid = hph.hostid)
                where hph.poolid = any(_pool_ids)
                    and hmc.start_time > (select current_timestamp at time zone 'UTC' - 30 * cast ('1 minute' as interval))
		group by hmc.hostid, hph.poolid loop
	return next r;
	end loop;
        return;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:					Brian Donegan
-- Date:					August 17, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 2, 2010
-- Description:
--	 Return the current avg metrics for all hosts in a pool
-- Parameters:
--   pool_id - the database ID (id column of the hv_pool table) of the pool
--             containing the hosts we are interested in.
-- Returns:
--   table of average host metrics
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_host_metrics_now
( 
	_pool_ids     int[]
);

create function "WorkloadBalancing".fn_get_avg_host_metrics_now
( 
	_pool_ids     int[]
) returns setof host_metrics as $$

declare
	r host_metrics%rowtype;

begin
	for r in select	hph.hostid,
			hph.poolid,
			avg(hm.free_mem), 
			avg(hm.total_mem),
			avg(hm.avg_cpu_utilization),
			avg(hm.avg_pif_read_per_sec),
			avg(hm.avg_pif_write_per_sec),
			avg(hm.load_average)
		from host_metric hm
			right join hv_pool_host hph on (hm.hostid = hph.hostid)
		where hph.poolid = any(_pool_ids)
		group by hph.hostid, hph.poolid loop
	return next r;
	end loop;
	return;
end;
$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Brian Donegan
-- Date:			August 17, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 2, 2010
-- Description:
--	 Return the avg metrics for the last 30 minutes for all hosts in a pool
-- Parameters:
--   pool_id - the database ID (id column of the hv_pool table) of the pool
--             containing the hosts we are interested in.
-- Returns:
--   table of average host metrics
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_host_metrics_yesterday
( 
	_pool_ids             int[]
);

create function "WorkloadBalancing".fn_get_avg_host_metrics_yesterday
( 
	_pool_ids             int[]
) returns setof host_metrics as $$

declare
	r host_metrics%rowtype;

begin
        for r in select	hmc.hostid, 
			hph.poolid,
			avg(avg_free_mem),
			0,--this field didn't exist before, was created so that we can reuse host_metrics type. Just ignore it if you're using this function
			avg(avg_total_cpu),
			avg(avg_total_pif_read_per_sec),
			avg(avg_total_pif_write_per_sec),
			avg(avg_load_average)
		from host_metric_con hmc
			join hv_pool_host hph on (hmc.hostid = hph.hostid)
                where hph.poolid = any(_pool_ids)
			and start_time > (select current_timestamp at time zone 'UTC' - 25 * cast ('1 hour' as interval))
			and end_time > (select current_timestamp at time zone 'UTC' - 23 * cast ('1 hour' as interval))
		group by hmc.hostid, hph.poolid loop
	return next r;
	end loop;
        return;
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2011 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Barbara Li
-- Date:			December 19, 2011
-- Description:
--	 Return the current avg pbd metrics for pools
-- Parameters:
--   pool_id - the database ID (id column of the hv_pool table) of the pool
--             containing the hosts we are interested in.
-- Returns:
--   table of average host metrics
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_host_pbd_metrics_30_min
( 
	_pool_ids     int[],
	_shared_storage	boolean
);

create function "WorkloadBalancing".fn_get_avg_host_pbd_metrics_30_min
( 
	_pool_ids     int[],
	_shared_storage	boolean
) returns setof host_pbd_metrics as $$

declare
	r host_pbd_metrics%rowtype;

begin
	for r in select	hostid, 
			poolid, 
			(case when sum(io_read) is null then 0 else sum(io_read) end) as avg_disk_io_read, 
			(case when sum(io_write) is null then 0 else sum(io_write) end) as avg_disk_io_write
		from(select hsr.host_id as hostid,
				sr.poolid, 
				vv.vm_id, 
				vv.vbd_id,  
				avg(vvmc.avg_read_per_sec) as io_read, 
				avg(vvmc.avg_write_per_sec) as io_write
			from hv_host_storage_repository hsr
				join storage_repository sr on sr.id = hsr.sr_id
				left join vbd on vbd.srid = sr.id
				left join vm_vbd vv on vv.vbd_id = vbd.id
				left join (select id, vmid 
						  from vm_metric_con 
						  where start_time > (select current_timestamp at time zone 'UTC' - 30 * cast ('1 minute' as interval))) vmm on vmm.vmid = vv.vm_id
				left join vm_vbd_metric_con vvmc on vvmc.vm_metric_id = vmm.id and vvmc.vbd = 0
			where (_shared_storage = true and sr.pool_default_sr = true) 
				or 
				(_shared_storage = false and sr.name = 'Local storage')
			group by hsr.host_id, sr.poolid, vv.vm_id, vv.vbd_id)pm
	where poolid = any(_pool_ids)
	group by hostid, poolid 
	loop
	return next r;
	end loop;
	return;
end;
$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2011 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Barbara Li
-- Date:			December 19, 2011
-- Description:
--	 Return the current avg pbd metrics for pools
-- Parameters:
--   pool_id - the database ID (id column of the hv_pool table) of the pool
--             containing the hosts we are interested in.
-- Returns:
--   table of average host metrics
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_host_pbd_metrics_now
( 
	_pool_ids     	int[],
	_shared_storage	boolean
);

create function "WorkloadBalancing".fn_get_avg_host_pbd_metrics_now
( 
	_pool_ids     	int[],
	_shared_storage	boolean
) returns setof host_pbd_metrics as $$

declare
	r host_pbd_metrics%rowtype;

begin
	for r in select	hostid, 
			poolid, 
			(case when sum(io_read) is null then 0 else sum(io_read) end) as avg_disk_io_read, 
			(case when sum(io_write) is null then 0 else sum(io_write) end) as avg_disk_io_write
	from(select	hsr.host_id as hostid,
			sr.poolid, 
			vv.vm_id, 
			vv.vbd_id, 
			avg(vvm.io_read_per_sec) as io_read, 
			avg(vvm.io_write_per_sec) as io_write
		from hv_host_storage_repository hsr
			join storage_repository sr on sr.id = hsr.sr_id
			left join vbd on vbd.srid = sr.id
			left join vm_vbd vv on vv.vbd_id = vbd.id
			left join vm_metric vmm on vmm.vmid = vv.vm_id
			left join vm_vbd_metric vvm on vvm.vm_metric_id = vmm.id and vvm.vbd = 0
		where (_shared_storage = true and sr.pool_default_sr = true) 
				or 
			  (_shared_storage = false and sr.name = 'Local storage')	
		group by hsr.host_id, sr.poolid, vv.vm_id, vv.vbd_id)pm
	where poolid = any(_pool_ids)
	group by hostid, poolid
	loop
	return next r;
	end loop;
	return;
end;
$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2011 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Barbara Li
-- Date:			December 19, 2011
-- Description:
--	 Return the current avg pbd metrics for pools
-- Parameters:
--   pool_id - the database ID (id column of the hv_pool table) of the pool
--             containing the hosts we are interested in.
-- Returns:
--   table of average host metrics
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_host_pbd_metrics_yesterday
( 
	_pool_ids     int[],
	_shared_storage	boolean
);

create function "WorkloadBalancing".fn_get_avg_host_pbd_metrics_yesterday
( 
	_pool_ids     int[],
	_shared_storage	boolean
) returns setof host_pbd_metrics as $$

declare
	r host_pbd_metrics%rowtype;

begin
	for r in select	hostid, 
			poolid, 
			(case when sum(io_read) is null then 0 else sum(io_read) end) as avg_disk_io_read, 
			(case when sum(io_write) is null then 0 else sum(io_write) end) as avg_disk_io_write
		from(select hsr.host_id as hostid,
				sr.poolid, 
				vv.vm_id, 
				vv.vbd_id,  
				avg(vvmc.avg_read_per_sec) as io_read, 
				avg(vvmc.avg_write_per_sec) as io_write
			from hv_host_storage_repository hsr
				join storage_repository sr on sr.id = hsr.sr_id
				left join vbd on vbd.srid = sr.id
				left join vm_vbd vv on vv.vbd_id = vbd.id
				left join (select id, vmid 
						  from vm_metric_con 
						  where start_time > (select current_timestamp at time zone 'UTC' - 25 * cast ('1 hour' as interval))
							and end_time > (select current_timestamp at time zone 'UTC' - 23 * cast ('1 hour' as interval))) vmm on vmm.vmid = vv.vm_id
				left join vm_vbd_metric_con vvmc on vvmc.vm_metric_id = vmm.id and vvmc.vbd = 0
			where (_shared_storage = true and sr.pool_default_sr = true) 
				or 
				(_shared_storage = false and sr.name = 'Local storage')
			group by hsr.host_id, sr.poolid, vv.vm_id, vv.vbd_id)pm
	where poolid = any(_pool_ids)
	group by hostid, poolid
	loop
	return next r;
	end loop;
	return;
end;
$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Date:		August 17, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 2, 2010
-- Description:
--	 Return the avg metrics for the last 30 minutes for the supplied vm and 
--      any vm determined to be similar based on the pool's matching settings
-- Parameters:
--   vm_id - the database ID (id column of the virtual_machine table) of the 
--             vm for which we want metrics
-- Returns:
--   table of average vm metrics
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_vm_metrics_30_min
( 
	_vm_id             int
);

create function "WorkloadBalancing".fn_get_avg_vm_metrics_30_min
( 
	_vm_id             int
) 
returns setof vm_metrics as $$

declare 
	r vm_metrics%rowtype;
	_metric_count int;
begin

	create temp table _matching_vms_temp (vmid int) on commit drop;
	
	insert into _matching_vms_temp select vmid from fn_get_matching_vms(_vm_id);

	--create a temp table to store data
	create temp table _vm_metrics ( vm_id		int, 
			avg_total_mem		            bigint,
			avg_free_mem		            bigint,
			avg_target_mem		            bigint,
			avg_used_mem					bigint,
			avg_cpu							decimal(9,8),
			avg_block_read					decimal(18,4),
			avg_block_write					decimal(18,4),
			avg_net_read					decimal(18,4),
			avg_net_write					decimal(18,4),
			total_vbd_net_read				decimal(18,4),
			total_vbd_net_write				decimal(18,4),
			avg_runstate_full_contention	decimal(9,8),
			avg_runstate_concurrency_hazard	decimal(9,8),
			avg_runstate_partial_contention decimal(9,8),
			avg_runstate_fullrun			decimal(9,8),
			avg_runstate_partial_run		decimal(9,8),
			avg_runstate_blocked			decimal(9,8)) on commit drop; 


	insert into _vm_metrics select	_vm_id,
			cast(avg(m.avg_total_mem)  as bigint),
			cast(avg(m.avg_free_mem) as bigint),
			cast(avg(m.avg_target_mem) as bigint),
			cast(avg(m.avg_total_mem-m.avg_free_mem) as bigint),
			avg(m.avg_cpu),
			avg(m.avg_vbd_read),
			avg(m.avg_vbd_write),
			avg(m.avg_vif_read),
			avg(m.avg_vif_write),
			avg(m.total_vbd_net_read),
			avg(m.total_vbd_net_write),
			avg(m.avg_runstate_full_contention),
			avg(m.avg_runstate_concurrency_hazard),
			avg(m.avg_runstate_partial_contention),
			avg(m.avg_runstate_fullrun),
			avg(m.avg_runstate_partial_run),
			avg(m.avg_runstate_blocked)
		from vm_metric_con m
		inner join _matching_vms_temp mvs on m.vmid = mvs.vmid
			where m.start_time > (select current_timestamp at time zone 'UTC' - 30 * cast ('1 minute' as interval));

	_metric_count := (select count(*) from _vm_metrics);
	--select _metric_count = __rowcount
	-- If we don't have any metrics from the last 30 minutes,
	-- grab the last 50 data points that we do have.
	--if not found then
	if _metric_count = 0 then
		insert into _vm_metrics select	_vm_id,
				avg(m.avg_total_mem),
				avg(m.avg_free_mem),
				avg(m.avg_target_mem),
				avg(m.avg_total_mem-m.avg_free_mem),
				avg(m.avg_cpu),
				avg(m.avg_vbd_read),
				avg(m.avg_vbd_write),
				avg(m.avg_vif_read),
				avg(m.avg_vif_write),
				avg(m.total_vbd_net_read),
				avg(m.total_vbd_net_write),
				avg(m.avg_runstate_full_contention),
				avg(m.avg_runstate_concurrency_hazard),
				avg(m.avg_runstate_partial_contention),
				avg(m.avg_runstate_fullrun),
				avg(m.avg_runstate_partial_run),
				avg(m.avg_runstate_blocked)
			from vm_metric_con m
			inner join _matching_vms_temp mvs on m.vmid = mvs.vmid
				where m.id in(select id from vm_metric_con order by start_time desc limit 50);
				
            get diagnostics _metric_count = row_count;
        end if;

        
	-- If we don't have any metrics for the VM in the consolidated
	-- metrics, try the historic metrics.
	if _metric_count = 0 then
		insert into _vm_metrics
		select	_vm_id,
				avg(m.avg_total_mem),
				avg(m.avg_free_mem),
				avg(m.avg_target_mem),
				avg(m.avg_total_mem-m.avg_free_mem),
				avg(m.avg_cpu),
				avg(m.avg_vbd_read),
				avg(m.avg_vbd_write),
				avg(m.avg_vif_read),
				avg(m.avg_vif_write),
				avg(m.total_vbd_net_read),
				avg(m.total_vbd_net_write),
				avg(m.avg_runstate_full_contention),
				avg(m.avg_runstate_concurrency_hazard),
				avg(m.avg_runstate_partial_contention),
				avg(m.avg_runstate_fullrun),
				avg(m.avg_runstate_partial_run),
				avg(m.avg_runstate_blocked)
			from vm_metric_history m 
		inner join _matching_vms_temp mvs on m.vmid = mvs.vmid
			where m.id in ( select id 
							from vm_metric_history vmh 
							inner join _matching_vms_temp mvs on m.vmid = mvs.vmid
							order by id desc
							limit 50);
        end if;

        for r in select * from _vm_metrics loop
        return next r;
        end loop;
        return;

end;
$$ language plpgsql;


--select * from fn_get_avg_vm_metrics_30_min(97)
-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Return the avg metrics for the last 30 minutes for the supplied vm and 
--      any vm determined to be similar based on the pool's matching settings
-- Parameters:
--   vm_id - the database ID (id column of the virtual_machine table) of the 
--             vm for which we want metrics
-- Returns:
--   table of average vm metrics
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_vm_metrics_now
( 
	_vm_id     int
);

create function "WorkloadBalancing".fn_get_avg_vm_metrics_now
( 
	_vm_id     int
) 
returns setof vm_metrics as $$

declare
	r vm_metrics%rowtype;

begin
        for r in 
		select _vm_id,
			cast(avg(m.total_mem) as bigint),
			cast(avg(m.free_mem) as bigint),
			cast(avg(m.target_mem) as bigint),
			cast(avg(m.total_mem-m.free_mem) as bigint),
			avg(m.avg_cpu),
			avg(m.avg_vbd_read),
			avg(m.avg_vbd_write),
			avg(m.avg_vif_read),
			avg(m.avg_vif_write),
			avg(m.total_vbd_net_read),
			avg(m.total_vbd_net_write),
			avg(m.runstate_full_contention),
			avg(m.runstate_concurrency_hazard),
			avg(m.runstate_partial_contention),
			avg(m.runstate_fullrun),
			avg(m.runstate_partial_run),
			avg(m.runstate_blocked)
		from vm_metric m 
		inner join "WorkloadBalancing".fn_get_matching_vms(_vm_id) mvs on m.vmid = mvs.vmid loop
	return next r;
	end loop;
	return;
end;
$$ language plpgsql;

/*
select "WorkloadBalancing".fn_get_avg_vm_metrics_now(1);
*/
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Date:		August 17, 2009
-- Rabin Karki, Nov 19, 2010
-- Description:
--	 Return the avg metrics for the previous day for the supplied vm and 
--      any vm determined to be similar based on the pool's matching settings
-- Parameters:
--   vm_id - the database ID (id column of the virtual_machine table) of the 
--             vm for which we want metrics
-- Returns:
--   table of average vm metrics
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_vm_metrics_yesterday
( 
	_vm_id             int
);

create function "WorkloadBalancing".fn_get_avg_vm_metrics_yesterday
( 
	_vm_id             int
) 
returns setof vm_metrics as $$

declare 
	_metric_count int;
	r vm_metrics%rowtype;
begin
	create temp table _matching_vms_yest (vmid int) on commit drop;
	--delete from _matching_vms_yest;

	insert into _matching_vms_yest
		select vmid from fn_get_matching_vms(_vm_id);

	for r in
	select	_vm_id,
			cast(avg(m.avg_total_mem) as bigint),
			cast(avg(m.avg_free_mem) as bigint),
			cast(avg(m.avg_target_mem) as bigint),
			cast(avg(m.avg_total_mem-m.avg_free_mem) as bigint),
			avg(m.avg_cpu),
			avg(m.avg_vbd_read),
			avg(m.avg_vbd_write),
			avg(m.avg_vif_read),
			avg(m.avg_vif_write),
			avg(m.total_vbd_net_read),
			avg(m.total_vbd_net_write),
			avg(m.avg_runstate_full_contention),
			avg(m.avg_runstate_concurrency_hazard),
			avg(m.avg_runstate_partial_contention),
			avg(m.avg_runstate_fullrun),
			avg(m.avg_runstate_partial_run),
			avg(m.avg_runstate_blocked)
		from vm_metric_con m
		inner join _matching_vms_yest mvs on m.vmid = mvs.vmid
		where m.start_time > datetimeadd(getutcdate(), '-25 hour' )
			and m.end_time > datetimeadd(getutcdate(), '-23 hour') loop
	return next r;
	end loop;


	-- If we don't have metrics from yesterday use the historic data.	
    	if not found then
		for r in			
		select	_vm_id,
		avg(m.avg_total_mem),
			avg(m.avg_free_mem),
			avg(m.avg_target_mem),
			avg(m.avg_total_mem-m.avg_free_mem),
			avg(m.avg_cpu),
			avg(m.avg_vbd_read),
			avg(m.avg_vbd_write),
			avg(m.avg_vif_read),
			avg(m.avg_vif_write),
			avg(m.total_vbd_net_read),
			avg(m.total_vbd_net_write),
			avg(m.avg_runstate_full_contention),
			avg(m.avg_runstate_concurrency_hazard),
			avg(m.avg_runstate_partial_contention),
			avg(m.avg_runstate_fullrun),
			avg(m.avg_runstate_partial_run),
			avg(m.avg_runstate_blocked)
		from vm_metric_history m 
		inner join _matching_vms_yest mvs on m.vmid = mvs.vmid
		where m.id in(select id 
					    from vm_metric_history vmh 
						inner join _matching_vms_yest mvs on vmh.vmid = mvs.vmid
						order by id desc
						limit 50) loop
		return next r;
		end loop;
        end if;

    return;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Return the avg metrics for the last 30 minutes for all vms on the
--      specified host
-- Parameters:
--   host_id - the database ID (id column of the hv_host table) of the 
--             host for which we want vm metrics
-- Returns:
--   table of average vm metrics grouped by vm
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_vm_metrics_30_min_by_host
( 
	_host_id             int
);

CREATE FUNCTION "WorkloadBalancing".fn_get_avg_vm_metrics_30_min_by_host
( 
	_host_id             int
) 
RETURNS setof vm_metrics AS $$

DECLARE
	r vm_metrics%rowtype;

BEGIN
	for r in
		select	m.vmid,
			cast(avg(m.avg_total_mem) as bigint),
			cast(avg(m.avg_free_mem) as bigint),
			cast(avg(m.avg_target_mem) as bigint),
			cast(avg(m.avg_total_mem-m.avg_free_mem) as bigint),
			avg(m.avg_cpu),
			avg(m.avg_vbd_read),
			avg(m.avg_vbd_write),
			avg(m.avg_vif_read),
			avg(m.avg_vif_write),
			avg(m.total_vbd_net_read),
			avg(m.total_vbd_net_write),
			avg(m.avg_runstate_full_contention),
			avg(m.avg_runstate_concurrency_hazard),
			avg(m.avg_runstate_partial_contention),
			avg(m.avg_runstate_fullrun),
			avg(m.avg_runstate_partial_run),
			avg(m.avg_runstate_blocked)
		from vm_metric_con m
			join host_vm hv on (m.vmid = hv.vmid)
		where hv.hostid = _host_id 
			and m.start_time > "WorkloadBalancing".datetimeadd(getutcdate(), '-30 minute')
            group by m.vmid loop
	return next r;
	end loop;
	
	RETURN;
END;
$$ LANGUAGE plpgsql;
-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Return the avg metrics for the last 30 minutes for all vms on the 
--      specified host
-- Parameters:
--   host_id - the database ID (id column of the hv_host table) of the 
--             host for which we want vm metrics
-- Returns:
--   table of average vm metrics grouped by vm
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_vm_metrics_now_by_host
( 
	_host_id             int
);

CREATE FUNCTION "WorkloadBalancing".fn_get_avg_vm_metrics_now_by_host
( 
	_host_id             int
) 
RETURNS setof vm_metrics AS $$

DECLARE
	r vm_metrics%rowtype;

BEGIN
	for r in
		select	m.vmid,
			cast(avg(m.total_mem) as bigint),
			cast(avg(m.free_mem) as bigint),
			cast(avg(m.target_mem) as bigint),
			cast(avg(m.total_mem-m.free_mem) as bigint),
			avg(m.avg_cpu),
			avg(m.avg_vbd_read),
			avg(m.avg_vbd_write),
			avg(m.avg_vif_read),
			avg(m.avg_vif_write),
			avg(m.total_vbd_net_read),
			avg(m.total_vbd_net_write),
			avg(m.runstate_full_contention),
			avg(m.runstate_concurrency_hazard),
			avg(m.runstate_partial_contention),
			avg(m.runstate_fullrun),
			avg(m.runstate_partial_run),
			avg(m.runstate_blocked)
		from vm_metric m 
			join host_vm hv  on (m.vmid = hv.vmid)
		where hv.hostid = _host_id
		group by m.vmid loop
	return next r;
	end loop;
	
	RETURN;
END;
$$ LANGUAGE plpgsql;
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Return the avg metrics for the previous day for all the vms on the 
--      specified host
-- Parameters:
--   host_id - the database ID (id column of the hv_host table) of the 
--             host for which we want vm metrics
-- Returns:
--   table of average vm metrics grouped by vm
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_avg_vm_metrics_yesterday_by_host
( 
	_host_id             int
);

CREATE FUNCTION "WorkloadBalancing".fn_get_avg_vm_metrics_yesterday_by_host
( 
	_host_id             int
) 
RETURNS setof vm_metrics AS $$

DECLARE
	r vm_metrics%rowtype;

BEGIN
	for r in
		select	m.vmid,
			cast(avg(m.avg_total_mem) as bigint),
			cast(avg(m.avg_free_mem) as bigint),
			cast(avg(m.avg_target_mem) as bigint),
			cast(avg(m.avg_total_mem-m.avg_free_mem) as bigint),
			avg(m.avg_cpu),
			avg(m.avg_vbd_read),
			avg(m.avg_vbd_write),
			avg(m.avg_vif_read),
			avg(m.avg_vif_write),
			avg(m.total_vbd_net_read),
			avg(m.total_vbd_net_write),
			avg(m.avg_runstate_full_contention),
			avg(m.avg_runstate_concurrency_hazard),
			avg(m.avg_runstate_partial_contention),
			avg(m.avg_runstate_fullrun),
			avg(m.avg_runstate_partial_run),
			avg(m.avg_runstate_blocked)
		from vm_metric_con m 
			join host_vm hv on (m.vmid = hv.vmid)
		where hv.hostid = _host_id 
			and m.start_time > "WorkloadBalancing".datetimeadd(getutcdate(), '-25 hour') 
			and m.end_time > "WorkloadBalancing".datetimeadd(getutcdate(), '-23 hour')
		group by m.vmid loop
	return next r;
	end loop;
	
	RETURN;
END;
$$ LANGUAGE plpgsql;
-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Return the number of free cpus on each host in a pool
-- Parameters:
--   pool_id - the database ID (id column of the hv_pool table) of the pool
--             containing the hosts we are interested in.
-- Returns:
--   table of host id's and the number of free cpus on each
-- ============================================================================
DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_host_free_cpus
( 
	_pool_ids   int[]
);

CREATE FUNCTION "WorkloadBalancing".fn_get_host_free_cpus
( 
	_pool_ids   int[]
) 
RETURNS SETOF host_free_cpus AS $$

DECLARE
	r host_free_cpus%rowtype;

BEGIN
	for r in
		select  h.id,  
			hph.poolid,
			h.num_cpus -              -- Add back the number of CPUs in 
			sum(v.min_cpus) +         -- the host because the control						                             
			h.num_cpus as free_cpus,   -- domain thinks it has all the CPUs.
			sum(v.min_cpus) as vcpus
		from virtual_machine v 
			join host_vm hv on hv.vmid=v.id
			join hv_host h  on h.id=hv.hostid
			join hv_pool_host hph on h.id = hph.hostid
		where hph.poolid = any(_pool_ids)
		group by h.id, h.num_cpus, hph.poolid      -- the join on host_vm eliminates the host.
		loop
		return next r;
	end loop;

	RETURN;
END;

$$ LANGUAGE plpgsql;

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Return the free memory (in bytes) for each host in a pool
-- Parameters:
--   pool_id - the database ID (id column of the hv_pool table) of the pool
--             containing the hosts we are interested in.
-- Returns:
--   table of host id's and the free memory (in bytes) on each
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_host_free_memory
( 
	_pool_ids   int[]
);

CREATE FUNCTION "WorkloadBalancing".fn_get_host_free_memory
( 
	_pool_ids   int[]
) 
RETURNS setof host_free_memory AS $$

DECLARE
	r host_free_memory%rowtype;

BEGIN
        for r in
		select 	hm.hostid, 
			sq.poolid,
			hm.free_mem 
		from host_metric hm
			 join (select max(tstamp) as tstamp, 
					hm.hostid,
					hph.poolid
				from host_metric hm
					join hv_pool_host hph on hm.hostid = hph.hostid
				where hph.poolid = any(_pool_ids)
				group by hm.hostid, hph.poolid) sq on sq.hostid=hm.hostid and sq.tstamp = hm.tstamp
		order by hm.id desc
		loop
		return next r;
	end loop;
	RETURN;
END;

$$ LANGUAGE plpgsql;



-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Date:		October 19, 2010
-- Description:
--	 Return the free memory (in bytes) for each host in a pool, memory
--   ballooning is taken into consideration.
-- Returns:
--   table of pool id, host id, the host potential free memory (in bytes) 
--   and memory ballooning flag on each
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_host_potential_free_memory_dmc();

CREATE OR REPLACE FUNCTION "WorkloadBalancing".fn_get_host_potential_free_memory_dmc
( 
) 
RETURNS setof host_potential_free_memory AS $$

DECLARE
	r host_potential_free_memory%rowtype;

BEGIN
	for r in
		select	hh.poolid,
			hh.id as hostid, 
			(( select hm.total_mem as total_memory from host_metric hm where hh.id = hm.hostid limit 1) -
			 ( select vmm.total_mem as memory_actual from vm_metric vmm where vmm.vmid = vm.id and vmm.hostid = hh.id limit 1) -
			 hh.memory_overhead - 
			 vm.memory_overhead - 
			 coalesce(used_memory, 0)
			) as potential_free_mem,
			(case when memory_ballooning > 0 then 1 else 0 end) as has_memory_ballooning
		from hv_host hh
			join host_vm hv on hv.hostid = hh.id
			join virtual_machine vm on vm.id = hv.vmid
			join (select hh0.poolid,
				     hh0.id,
				     sum (( case 
						when (vm0.min_dynamic_memory < vm0.max_static_memory)
						then  vm0.min_dynamic_memory 
						else  vm0.max_static_memory 
					   end) + vm0.memory_overhead) as used_memory,
				     sum (case 
						when vm0.min_dynamic_memory <> vm0.max_static_memory
						then 1 
						else 0
				          end) as memory_ballooning 
			      from hv_host hh0
				   join host_vm hvm on hvm.hostid = hh0.id
				   left join  virtual_machine vm0 on vm0.id = hvm.vmid and vm0.is_control_domain = false 
			      group by hh0.poolid, hh0.id) vum on vum.id = hh.id and vum.poolid = hh.poolid
		where vm.is_control_domain = true 
			and hh.active=true      
			and hh.enabled = true 
			and hh.power_state= 1
		loop
		return next r;
	end loop;
	RETURN;
END;

$$ LANGUAGE plpgsql;

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Return the number of VMs on each host in a pool that fall who's runstate metrics
--      exceed the various high thresholds
-- Parameters:
--   pool_id - the database ID (id column of the hv_pool table) of the pool
--             containing the hosts we are interested in.
-- Returns:
--   table of vm counts for each runstate
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_host_vm_runstate_counts
( 
	_pool_ids             int[]
);

create function "WorkloadBalancing".fn_get_host_vm_runstate_counts
( 
	_pool_ids             int[]
) 
returns setof host_runstate_counts AS $$

declare
	r record;

begin
        for r in
		select  hostid,
			poolid,
			sum(full_contention) as full_contention_count,
			sum(concurrency_hazard) as concurrency_hazard_count,
			sum(partial_contention) as partial_contention_count,
			sum(fullrun) as fullrun_count,
			sum(partial_run) as partial_run_count,
			sum(blocked) as blocked_count
		from (	select hv.hostid as hostid, 
				hph.poolid,
				case when (avg(vmm.runstate_full_contention)> hpt.host_runstate_full_contention_threshold_high) then vm.min_cpus else 0 end as full_contention,
				case when (avg(vmm.runstate_concurrency_hazard)> hpt.host_runstate_concurrency_hazard_threshold_high) then vm.min_cpus else 0 end as concurrency_hazard,
				case when (avg(vmm.runstate_partial_contention)> hpt.host_runstate_partial_contention_threshold_high) then vm.min_cpus else 0 end as partial_contention,
				case when (avg(vmm.runstate_fullrun)> hpt.host_runstate_fullrun_threshold_high) then vm.min_cpus else 0 end as fullrun,
				case when (avg(vmm.runstate_partial_run)> hpt.host_runstate_partial_run_threshold_high) then vm.min_cpus else 0 end as partial_run,
				case when (avg(vmm.runstate_blocked)> hpt.host_runstate_blocked_threshold_high) then vm.min_cpus else 0 end as blocked
			from vm_metric vmm
				join host_vm hv on vmm.vmid = hv.vmid
				join hv_pool_host hph on hv.hostid = hph.hostid
				join hv_pool_threshold hpt on hph.poolid = hpt.pool_id
				join virtual_machine vm on vmm.vmid = vm.id
			where hph.poolid = any(_pool_ids)
			group by hv.hostid, 
				hph.poolid,
				vmm.vmid,
				vm.min_cpus,
				hpt.host_runstate_full_contention_threshold_high,
				hpt.host_runstate_concurrency_hazard_threshold_high,
				hpt.host_runstate_partial_contention_threshold_high,
				hpt.host_runstate_fullrun_threshold_high,
				hpt.host_runstate_partial_run_threshold_high,
				hpt.host_runstate_blocked_threshold_high
				) runstate_base
		group by hostid, poolid loop
		return next r;
	end loop;
        return;
end;
$$ language plpgsql;


-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Create date: 		July 2, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 21, 2010
-- Description:	Retrieve all the physical hosts in a hypervisor pool as well
--				as information about the hosts.
-- Parameters:
--     pool_id - The database ID (id column of the hv_pool table) of the pool
--               whose physical hosts are to be retrieved.
-- Returns:
--   If successful, a result set containing information about the hosts in the
--   pool.
--   If unsuccessful, an error code that is less than zero.
--      -1 Parameters not specified.
--		-2 Pool not found
-- change for PostgreSQL: these numbers will be in id field!
--
--   The successful result set contains the following columns:
--		id                - Internal, database ID of the host
--		name              - Name of the host
--		uuid              - Unique ID of the host
--		num_cpus          - Number of CPUs in the host.
--		cpu_speed         - The speed of the CPUs in mega-Hertz.
--		num_pifs          - Number of physical network interfaces in the host.
--		is_pool_master    - Set to 1 if the host is also the pool master.
--      num_vms           - The number of VMs running on the host (includes 
--						    control domain).
--		avg_free_mem      - Average free memory since last consolidation of
--                          metrics data.
--		avg_total_mem     - Average total memory since last consolidation of
--                          metrics data.
--		avg_free_mem_con  - Average free memory over the last 30 minutes.
--		avg_total_mem_con - Average total memory over the last 30 minutes.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_hosts_in_pool
(
	_pool_id int
);

CREATE function "WorkloadBalancing".get_hosts_in_pool
(
	_pool_id int
) RETURNS SETOF host_info AS $$

DECLARE 
	_id int;
	_err int;
	_num_hosts int;
	_use_metrics int;
	_use_consolidated int;
	r host_info%rowtype;
	
BEGIN
	begin
		create temp table tmp_return_table(id int, name varchar(256), uuid varchar(48),
				num_cpus int, cpu_speed int, num_pifs int,
				is_pool_master boolean, avg_free_mem bigint, 
				avg_total_mem bigint, avg_free_mem_con bigint, avg_total_mem_con bigint
		) ON COMMIT DROP;
		exception when others then
			truncate table tmp_return_table; --truncate if the table already exists
	end;
	
	-- Make sure we have a valid pool.
	if _pool_id is not null and _pool_id > 0 then
		select into _id id
			from hv_pool
			where id=_pool_id;
		if _id is null then
			_err := -2;
			-- return here : go to done;
		end if;
	else		
		_err := -1;
		-- return here : goto done
	end if;


	if _err is not null then
		insert into tmp_return_table (id) values (_err);-- ROW(_err, , , 0, 0, 0, FALSE, 0, 0, 0, 0);
		for r in select * from tmp_return_table loop
			return next r;
		end loop;
		return;
	end if;
	--select * from r;
	
	-- Get the hosts in the pool.
	CREATE TEMP TABLE _hosts(hostid  int, 
				name           varchar(256), 
				uuid           varchar(48),
				num_cpus       int,
				cpu_speed      int, 
				num_pifs       int, 
				is_pool_master boolean) ON COMMIT DROP;

	INSERT INTO _hosts
		SELECT	h.id,
			h.name,
			h.uuid, 
			h.num_cpus,
			h.cpu_speed,
			h.num_pifs, 
			h.is_pool_master
		FROM hv_host h 
			JOIN hv_pool_host ph ON h.id=ph.hostid 
		WHERE ph.poolid=_pool_id;

	GET DIAGNOSTICS _num_hosts = ROW_COUNT;
		
	--select * from _hosts

	create temp table _vms (hostid int, num_vms int) ON COMMIT DROP;
	insert into _vms 
		select	hostid,
			count(*) 
			from host_vm
		where hostid in (select hostid from _hosts)
			group by hostid;

	--select * from _vms

	-- Get the average memory consumption since the last consolidation.
	create temp table _memory1 (hostid int, avg_free_mem bigint, total_mem bigint) ON COMMIT DROP;
	insert into _memory1
		select	hostid, 
				avg(free_mem), 
				avg(total_mem)    
			from host_metric
			where hostid in (select hostid from _hosts)
			group by hostid;

	GET DIAGNOSTICS _use_metrics = ROW_COUNT;
	--select * from _memory1

	-- Get the average memory consumption over the last 30 minutes.
	create temp table _memory2 (hostid int, avg_free_mem bigint, total_mem bigint) ON COMMIT DROP;
	insert into _memory2
		select	hostid, 
				avg(avg_free_mem), 
				avg(avg_total_mem)    
			from host_metric_con
			where hostid in (select hostid from _hosts)
				and start_time > (select current_timestamp at time zone 'UTC' - 30 * cast ('1 minute' as interval)) -- subtracts 30 mins from utc time
				
				--dateadd(mi, -30, (select current_timestamp at time zone 'UTC') )
			group by hostid;


	GET DIAGNOSTICS _use_consolidated = ROW_COUNT;
	--select * from _memory2
	if _use_metrics=_num_hosts and _use_consolidated=_num_hosts then
		-- return this
		delete from tmp_return_table;
		for r in select h.hostid,
				h.name,
				h.uuid, 
				h.num_cpus,
				h.cpu_speed,
				h.num_pifs, 
				h.is_pool_master, 
				v.num_vms,
				m.avg_free_mem as avg_free_mem, 
				m.total_mem as avg_total_mem,
				c.avg_free_mem as avg_free_mem_con,
				c.total_mem as avg_total_mem_con
			from _hosts h
			join _vms v on h.hostid=v.hostid
			join _memory1 m on h.hostid=m.hostid
			join _memory2 c on h.hostid=c.hostid
			order by v.num_vms loop
			return next r;
			end loop;
		RETURN;
		
	else 
		if _use_metrics=_num_hosts then
			--return this
			for r in select	h.hostid,
					h.name,
					h.uuid, 
					h.num_cpus,
					h.cpu_speed,
					h.num_pifs, 
					h.is_pool_master, 
					v.num_vms,
					m.avg_free_mem as avg_free_mem, 
					m.total_mem as avg_total_mem,
					0 as avg_free_mem_con,
					0 as avg_total_mem_con
				from _hosts h
				join _vms v on h.hostid=v.hostid
				join _memory1 m on h.hostid=m.hostid
				order by v.num_vms loop
				return next r;
				end loop;
			RETURN;
		
		else
			if _use_consolidated=_num_hosts then
				for r in select	h.hostid,
						h.name,
						h.uuid, 
						h.num_cpus,
						h.cpu_speed,
						h.num_pifs, 
						h.is_pool_master, 
						v.num_vms,
						0 as avg_free_mem,
						0 as avg_total_mem,
						c.avg_free_mem as avg_free_mem_con,
						c.total_mem as avg_total_mem_con
					from _hosts h
					join _vms v on h.hostid=v.hostid
					join _memory2 c on h.hostid=c.hostid
					order by v.num_vms loop
					return next r;
					end loop;
				RETURN;
				
			else
				for r in select	h.hostid,
						h.name,
						h.uuid, 
						h.num_cpus,
						h.cpu_speed,
						h.num_pifs, 
						h.is_pool_master, 
						v.num_vms,
						0 as avg_free_mem,
						0 as avg_total_mem,
						0 as avg_free_mem_con,
						0 as avg_total_mem_con
					from _hosts h
					join _vms v on h.hostid=v.hostid
					order by v.num_vms loop
					RETURN NEXT r;
					END LOOP;
				RETURN;
			END IF;
		END IF;
	END IF;

	get diagnostics _err = ROW_COUNT;

--done:	
	
	-- return _err

END;
$$ LANGUAGE plpgsql;


-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			Sept 12, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Retrieve the hash key used to encrypt hypervisor passwords.
-- Parameters:
--   default_hash	- If the hash key is not present this value will be
--					  inserted in the config table.
-- Returns:
--   The hash key used to encrypt hypervisor passwords.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_hv_pwd_hash
(
	_default_hash varchar(50)
);

create function "WorkloadBalancing".get_hv_pwd_hash
(
	_default_hash varchar(50)
) returns varchar(50) as $$

declare _hash varchar(50);
	_tstamp timestamp;
	_rowcount int;

begin
	
	select value into _hash
		from core_config 
		where component_id=3 and
		      category='SecurityHash' and
			  item_name='HvPwdHash';		  

	
	if _hash is null then
		_tstamp := (select current_timestamp at time zone 'UTC');

		insert into core_config (component_id,
			category, 
			item_name,
			value,
			default_value,
			description,
			touched_by,
			tstamp)
		    values (3,               -- comp id
			'SecurityHash',  -- category
			'HvPwdHash',     -- item
			_default_hash,   -- value
			'',              -- default
			null,            -- description 
			null,            -- touch
			_tstamp);         -- tstamp
		_hash := _default_hash;
	end if;

	return _hash;
end;

$$ language plpgsql;
-- ==========================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: January 27, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 23, 2010	
-- Description:	Get the latest date references in the consolidation 
--		intervals table
-- Parameters:
--   _return_date datetime output
-- Returns:
--   n/a
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_latest_consolidation_interval_date();

create function "WorkloadBalancing".get_latest_consolidation_interval_date
(
	out _return_date timestamp
) returns timestamp
as $$

declare _year int;
	_day_of_year int;
	_minute int;
begin
	select into
		_year, _day_of_year, _minute
		year, day_of_year,(five_minute_interval*5)
		from consolidation_intervals
		order by year desc, day_of_year desc, five_minute_interval desc limit 1;

	_return_date := date '1900-01-01' + 
			(_year-1900) * interval '1 year' + 
			(_day_of_year-1) * interval '1 day' + 
			_minute * interval '1 minute';
end; $$ 
language plpgsql;
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Brian Donegan
-- Date:			August 17, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 2, 2010
-- Description:
--	 Returns a list of ids of VMs determined to be similar to the supplied
--      vm, based in the vm's pool's matching settings
-- Parameters:
--   vm_id - the database ID (id column of the virtual_machine table) of the vm
--             for which we are trying to find similar vms
-- Returns:
--   table of vm ids that are determined to be similar to the supplied vm
-- ============================================================================

--drop table if exists "WorkloadBalancing"._matching_vms_main cascade;
--create table "WorkloadBalancing"._matching_vms_main (vmid int);
-- drop function "WorkloadBalancing".fn_get_matching_vms(int)

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_matching_vms
( 
	_vm_id		int
);

create function "WorkloadBalancing".fn_get_matching_vms
( 
	_vm_id		int,
	out vmid 	int
) 
returns setof int as $$

declare 
	--r	record;
	_pool_id               int;
	_vm_name               varchar(256);
	_similar_id            int;
	_use_name_matching     varchar(100);
	_name_matching_pattern varchar(100);
	_name_to_match         varchar(256);

begin
	drop table if exists _matching_vms_main;
	create temp table _matching_vms_main (vmid int) on commit drop;
	select into _pool_id poolid from virtual_machine where id = _vm_id;

	select into _use_name_matching value
		from hv_pool_config
		where pool_id=_pool_id and
		name='UseNameMatching';

	if _use_name_matching = 'true' then
                select into _name_matching_pattern value 
                    from hv_pool_config
                    where pool_id=_pool_id and 
                        name='NameMatchingPattern';

		if _name_matching_pattern = 'NumericSuffix' then
			select into _name_to_match trim_numeric_suffix(_vm_name);
			insert into _matching_vms_main (vmid) (select id from match_vm_by_numeric_suffix(_name_to_match));
		else

			-- Some other type of name matching that we don't support.
			insert into _matching_vms_main (vmid) values (_similar_id);
		end if;
	else

		-- We are not using name matching.
		insert into _matching_vms_main (vmid) values (_similar_id);
	end if;

	return query select * from _matching_vms_main;
end;
$$ language plpgsql;

--select * from hv_pool
--select * from virtual_machine

--select * from fn_get_matching_vms(92)
/*
 * (c) Copyright 2000-2008 Citrix Systems, Inc.
 * ALL RIGHTS RESERVED
 *
 * Project:		 SQL
 * Module:       Citrix DWM Core Person Procedures
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 18, 2010	
 * $LOG$
 *
 */
--drop function get_move_status_by_event_id(int)

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_move_status_by_event_id
(
	_move_set_id int
);

create function "WorkloadBalancing".get_move_status_by_event_id
(
	_move_set_id int,
	out name varchar(256),
	out fromhost varchar(256),
	out tohost varchar(256),
	out reason varchar(20),
	out status int
) returns setof record as $$
begin
	-- This query will always return the full list from the original recommendation event_id
	-- and the status from the next audit log item with an event type of 3 for each of the VM's 
	return query (select vm.name, 
		hvhfrom.name as fromhost, 
		hvhto.name as tohost,
		optr.reason as reason,
		hva.status as status
/*
		( select status_select.status from
			(select top 1 hva2.event_id, status
			 from hv_audit hva2 
			 where hva2.event_type = 3
			 and hva2.vm_id = hva.vm_id
			 and hva2.event_id > _move_set_id
		     order by hva2.event_id asc
			) status_select) as status
*/
	from hv_audit hva
		join hv_host hvhfrom on (hvhfrom.id = hva.from_host_id)
		join hv_host hvhto on (hvhto.id = hva.to_host_id)
		join virtual_machine vm on (vm.id = hva.vm_id)
		left join optimize_reason optr on (hva.reason = optr.id)
	where hva.event_id = _move_set_id);
end;
$$ language plpgsql;

--select * from hv_audit
--select * from get_move_status_by_event_id(1)

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Retrieve the basic configuration information for a hypervisor pool.
-- Parameters:
--       _uuid	- the unique identifier (uuid column of the hv_host table) of
--                a physical host within the pool whose basic configuration 
--                info is to be retrieved.
-- Returns:
--   One result set:
--     Id
--     Hypervisor type
--     Pool address
--     Pool port
--     Username
--     Password
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_pool_by_host_uuid
(
	_uuid varchar
);

create function "WorkloadBalancing".get_pool_by_host_uuid
(
	_uuid varchar
) returns setof pool_basic_info as $$
declare 
	r pool_basic_info%rowtype;
begin
	for r in 
		select p.id, p.hv_type, p.pool_master_1_addr, p.pool_master_1_port, p.protocol, p.username, p.password
		from hv_pool p
			join hv_pool_host ph on ph.poolid=p.id
			join hv_host h on h.id = ph.hostid
		where h.uuid=_uuid loop
		return next r;
	end loop;
	return;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Retrieve the basic configuration information for a hypervisor pool.
-- Parameters:
--       _id	- The database ID(id column of the hv_pool table) of
--                the pool whose basic configuration info is to be retrieved.
-- Returns:
--   One result set:
--     Id
--     Hypervisor type
--     Pool address
--     Pool port
--     Username
--     Password
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_pool_by_pool_id
(
	_id int
);

create function "WorkloadBalancing".get_pool_by_pool_id
(
	_id int
) returns setof pool_basic_info as $$
declare 
	r pool_basic_info%rowtype;
begin
	for r in 
		select id, hv_type, pool_master_1_addr, pool_master_1_port, protocol, username, password
		from hv_pool
		where id=_id loop
		return next r;
	end loop;
	return;
end;
$$ language plpgsql; 

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Retrieve the basic configuration information for a hypervisor pool.
-- Parameters:
--       _name - the name of the pool whose basic configuration info is to be retrieved.
-- Returns:
--   One result set:
--     Id
--     Hypervisor type
--     Pool address
--     Pool port
--     Username
--     Password
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_pool_by_pool_name
(
	_name varchar
);

create function "WorkloadBalancing".get_pool_by_pool_name
(
	_name varchar
) returns setof pool_basic_info as $$
declare 
	r pool_basic_info%rowtype;
begin
	for r in 
		select id, hv_type, pool_master_1_addr, pool_master_1_port, protocol, username, password
		from hv_pool
		where uuid=_name loop
		return next r;
	end loop;
	return;
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Retrieve the basic configuration information for a hypervisor pool.
-- Parameters:
--       _uuid - the unique identifier (uuid column of the hv_pool table) of
--           	 the pool whose basic configuration info is to be retrieved.
-- Returns:
--   One result set:
--     Id
--     Hypervisor type
--     Pool address
--     Pool port
--     Username
--     Password
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_pool_by_pool_uuid
(
	_uuid varchar
);

create function "WorkloadBalancing".get_pool_by_pool_uuid
(
	_uuid varchar
) returns setof pool_basic_info as $$
declare 
	r pool_basic_info%rowtype;
begin
	for r in 
		select id, hv_type, pool_master_1_addr, pool_master_1_port, protocol, username, password
		from hv_pool
		where uuid=_uuid loop
		return next r;
	end loop;
	return;
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Retrieve the internal pool id based on the supplied pool name.
-- Parameters:
--       _name	- the name of the pool whose internal id we are looking for.
-- Returns:
--   One result set:
--     Id
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_pool_id_by_pool_name
(
	_name varchar
);

create function "WorkloadBalancing".get_pool_id_by_pool_name
(
	_name varchar
) returns int as $$
declare 
	r int;
begin
	select id into r
	from hv_pool
	where name=_name;
	return r;
end;
$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Retrieve the internal pool id based on the supplied pool Uuid.
-- Parameters:
--       _uuid	- the unique identifier (uuid column of the hv_pool table) of
--                the pool whose internal id we are looking for.
-- Returns:
--   One result set:
--     Id
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_pool_id_by_pool_uuid
(	
	_uuid varchar
);

create function "WorkloadBalancing".get_pool_id_by_pool_uuid
(	
	_uuid varchar
) returns int as $$
declare 
	r int;
begin
	select id into r
	from hv_pool
	where uuid=_uuid;
	return r;
end;
$$ language plpgsql; 
--drop function get_pool_recommendations()

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_pool_recommendations();

create function "WorkloadBalancing".get_pool_recommendations
(
	out event_id bigint,
	out pool_id int,
	out pool_uuid varchar(48),
	out pool_name varchar(256),
	out optimization_mode int,
	out severity int,
	out optimization_time_stamp timestamp
)
returns setof record as $$
begin
	return query (
		select	mr.id			      as event_id,
		mr.poolid		      as pool_id,
		p.uuid			      as pool_uuid,
		p.name		      as pool_name,
		cast(pc.value as int) as optimization_mode,
		mr.severity		      as severity,
		mr.tstamp		      as optimization_time_stamp
	from move_recommendation mr
		join (select max(id) as id,
			recommendation_id
			from move_recommendation_detail 
			group by recommendation_id) mrd on (mr.id= mrd.recommendation_id)
		join hv_pool p                      on (p.id = mr.poolid)
		join hv_pool_config pc              on (p.id=pc.pool_id and pc.name='OptimizationMode')
		join (select max(m.id) as id
			  from move_recommendation m
			  where m.type = 3 
			  group by m.poolid) recommendations on (mr.id = recommendations.id)
		where mr.type = 3
			  and mr.tstamp > (getutcdate() - (select cast(value as int) 
						from core_config 
						where component_id = 4 and 
							  category = 'Intervals' and
							  item_name = 'PollInterval') * interval '1 second')
		);

end;
$$ language plpgsql;



-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:	Retreive the ID of the hv_pool_threshold rows for the 
--              specified pool.  If the ID is null, the DwmPool class will
--              add the default values.
-- Parameters:
--     pool_id - The database ID (id column of the hv_pool table) of the pool
--               whose hv_pool_threshold ID is to be retreived.
-- Returns:
--   If successful, the non-zero row ID.
--
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_pool_threshold_id_by_id 
(
	_pool_id int
);

CREATE FUNCTION "WorkloadBalancing".get_pool_threshold_id_by_id 
(
	_pool_id int
) RETURNS int AS $$   

DECLARE r int;

BEGIN
	-- Make sure we have a valid pool.
	select id into r from hv_pool_threshold where pool_id = _pool_id;
	return r;
END;
$$ LANGUAGE plpgsql;
--==============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Project:		 SQL
-- Module:       Citrix DWM Core Person Procedures
--
-- $LOG$
--
--==============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_recommendations_for_pool_by_pool_id
(
	_pool_id       int
);

CREATE FUNCTION "WorkloadBalancing".get_recommendations_for_pool_by_pool_id
(
	_pool_id       int
)
RETURNS SETOF refcursor AS $$

DECLARE 
	_licensed		boolean := false;
	_is_licensed 		refcursor;
	_recommendations	refcursor;
	
BEGIN
	_licensed := (select is_licensed 
			from hv_pool 
			where id=_pool_id);


	open _is_licensed for
		select _licensed as is_licensed;
	return next _is_licensed;
		
	if _licensed then
		open _recommendations for
			select	mr.id            as event_id,
				mrd.id           as recommendation_id,
				mr.poolid        as pool_id,
				mr.severity      as severity,
				mrd.vm_id        as vm_id,
				vm.uuid          as vm_uuid,
				vm.name          as vm_name,
				mrd.to_host_id   as move_to_host_id,
				hvhto.uuid       as move_to_host_uuid,
				hvhto.name       as move_to_host_name,
				mrd.from_host_id as move_from_host_id,
				hvhfrom.uuid     as move_from_host_uuid,
				hvhfrom.name     as move_from_host_name,
				mrd.reason       as reason_id,
				optr.reason      as reason, 
				mr.tstamp        as move_recommendation_time_stamp
			from move_recommendation mr
				join move_recommendation_detail mrd on (mr.id = mrd.recommendation_id)
				join hv_pool  hvp on (hvp.id = mr.poolid)
				left join hv_host hvhfrom on (hvhfrom.id = mrd.from_host_id)
				left join hv_host hvhto on (hvhto.id = mrd.to_host_id)
				left join virtual_machine vm on (vm.id = mrd.vm_id)
				join ( 	select max(m.id) as id
					from move_recommendation m
					where m.type = 3 
					group by m.poolid) recommendations on (mr.id = recommendations.id)
				left join optimize_reason optr on (mrd.reason = optr.id)	
			where mr.type = 3
				and mr.tstamp > (select current_timestamp at time zone 'UTC' 
							- (cast('1 second' as interval)
							   *(select cast(value as int) 
							     from core_config 
							     where component_id = 4 
								   and category = 'Intervals' 
								   and item_name = 'PollInterval')))
				 and hvp.id = _pool_id 
				 and hvp.is_licensed = true;
		return next _recommendations;
	end if;
	return;		  
END;

$$ LANGUAGE plpgsql;

/*
drop  FUNCTION "WorkloadBalancing".get_recommendations_for_pool_by_pool_id
(
	_pool_id       int
)

begin;
select get_recommendations_for_pool_by_pool_id(9999);
fetch all from "<unnamed portal 1>"
*/
/*
 * (c) Copyright 2000-2008 Citrix Systems, Inc.
 * ALL RIGHTS RESERVED
 *
 * Project:		 SQL
 * Module:       Citrix DWM Core Person Procedures
 *
 * $LOG$
 *
 */

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_recommendation_detail_status
(
	_recommendation_id int
);

create function "WorkloadBalancing".get_recommendation_detail_status
(
	_recommendation_id int
) returns setof recommendation_detail as $$
declare
	r recommendation_detail%rowtype;
begin

	for r in select	mr.id            as event_id,
			mrd.id           as recommendation_id,
			mr.poolid        as pool_id,
			mr.severity      as severity,
			mrd.vm_id        as vm_id,
			vm.uuid          as vm_uuid,
			vm.name        as vm_name,
			mrd.to_host_id   as move_to_host_id,
			hvhto.uuid       as move_to_host_uuid,
			hvhto.name     as move_to_host_name,
			mrd.from_host_id as move_from_host_id,
			hvhfrom.uuid     as move_from_host_uuid,
			hvhfrom.name   as move_from_host_name,
			mrd.reason       as reason_id,
			optr.reason      as reason, 
			mr.tstamp        as move_recommendation_time_stamp,
			hva.status       as status,
			hva.end_time     as end_time
	from move_recommendation mr
		join move_recommendation_detail mrd     on (mr.id      = mrd.recommendation_id)
		join hv_pool                    hvp     on (hvp.id     = mr.poolid)
		join hv_host                    hvhfrom on (hvhfrom.id = mrd.from_host_id)
		join hv_host                    hvhto   on (hvhto.id   = mrd.to_host_id)
		join virtual_machine            vm      on (vm.id      = mrd.vm_id)
		left join hv_audit              hva     on (mrd.id     = hva.recommendation_detail_id)
		left join optimize_reason optr on (mrd.reason = optr.id)	
		where mrd.id = _recommendation_id loop
	return next r;
	end loop;
	return;
end;
$$
language plpgsql;

/*
 * (c) Copyright 2000-2008 Citrix Systems, Inc.
 * ALL RIGHTS RESERVED
 *
 * Project:		 SQL
 * Module:       Citrix DWM Core Person Procedures
 *
 * $LOG$
 *
 */
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 18, 2010	
-- select * from get_recommendation_status(1)

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_recommendation_status
(
	_event_id       int
);

create function "WorkloadBalancing".get_recommendation_status
(
	_event_id       int,
	out event_id bigint,
	out recommendation_id bigint,
	out pool_id int,
	out severity int,
	out vm_id int,
	out vm_uuid varchar(48),
	out vm_name varchar(256),
	out move_to_host_id int,
	out move_to_host_uuid varchar(48),
	out move_to_host_name varchar(256),
	out move_from_host_id int,
	out move_from_host_uuid varchar(48),
	out move_from_host_name varchar(256),
	out reason_id int,
	out reason varchar(20),  
	out move_recommendation_time_stamp timestamp,
	out status int,
	out end_time timestamp
	
) returns setof record as $$
begin
	return query (
	select	mr.id            as event_id,
		mrd.id           as recommendation_id,
		mr.poolid        as pool_id,
		mr.severity      as severity,
		mrd.vm_id        as vm_id,
		vm.uuid          as vm_uuid,
		vm.name        as vm_name,
		mrd.to_host_id   as move_to_host_id,
		hvhto.uuid       as move_to_host_uuid,
		hvhto.name     as move_to_host_name,
		mrd.from_host_id as move_from_host_id,
		hvhfrom.uuid     as move_from_host_uuid,
		hvhfrom.name   as move_from_host_name,
		mrd.reason       as reason_id,
		optr.reason      as reason, 
		mr.tstamp        as move_recommendation_time_stamp,
		hva.status       as status,
		hva.end_time     as end_time
	from move_recommendation mr
		join move_recommendation_detail mrd     on (mr.id      = mrd.recommendation_id)
		join hv_pool                    hvp     on (hvp.id     = mr.poolid)
		left join hv_host               hvhfrom on (hvhfrom.id = mrd.from_host_id)
		left join hv_host               hvhto   on (hvhto.id   = mrd.to_host_id)
		left join virtual_machine       vm      on (vm.id      = mrd.vm_id)
		left join hv_audit              hva     on (mrd.id     = hva.recommendation_detail_id)
		left join optimize_reason optr on (mrd.reason = optr.id)	
		where mr.id = _event_id);
end;
$$ language plpgsql;
-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:	Retrieve the WLB version.
-- Parameters:
--    none
-- Returns:
--    WLB version
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_version();

CREATE FUNCTION "WorkloadBalancing".get_version 
(
) RETURNS varchar(256) AS $$   

DECLARE 
	_version varchar(256);

BEGIN
	_version := (select value
		  from core_config
		 where component_id=3 
			and category='General' 
			and item_name='MAJOR_VERSION');
	
	return _version;

END;
$$ LANGUAGE plpgsql;
-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Create date: 	June 13, 2010
--
-- Description:	Groom data from historical tables based on a supplied groom date
-- Parameters:
--   			_groom_date 		datetime
-- Returns:
--   			a list of tables that are needed to be vacummed and reindexed
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".groom_historical_data_by_date
(
	_groom_date 		timestamp
);

create Function "WorkloadBalancing".groom_historical_data_by_date
(
	_groom_date 		timestamp
) returns varchar as $$

begin

	-- remove data that is earlier than groom date, 
	-- cascades deletes data in host_metric_history, vm_metric_history and host_vm_history,
	delete from consolidation_intervals 
	where tstamp <= _groom_date; --(select "WorkloadBalancing".get_earliest_consolidation_interval_date());
	
	-- clean up audit log table
	delete from hv_audit_log 
	where tstamp <= _groom_date;
	
	-- clean up move_recommendation, cascades deletes data in move_recommendation_detail
	delete from move_recommendation
	where tstamp <= _groom_date;

	-- clean up vm_movement / tstamp
	delete from vm_movement 
	where vm_movement.tstamp <= _groom_date;

	return 'vm_metric_history,vm_cpu_metric_history,vm_vif_metric_history,vm_vbd_metric_history,host_metric_history,host_cpu_metric_history,host_pif_metric_history,host_pbd_metric_history,host_vm_history,hv_pool_threshold_history,consolidation_intervals,hv_audit_log,move_recommendation,move_recommendation_detail';

end;
$$ language plpgsql;


-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Create date: 	June 13, 2010
--
-- Description:	Groom data from the database for a pool
-- Parameters:
--   n/a
-- Returns:
--   n/a
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".groom_get_db_info();

create function "WorkloadBalancing".groom_get_db_info
(
) 
returns setof refcursor as $$

declare 
	_earliest_date			refcursor;
	_latest_date 			refcursor;
	_current_history_table_size 	refcursor;

begin

	-- get the oldest date from consolidation_intervals
	open _earliest_date for
		select "WorkloadBalancing".get_earliest_consolidation_interval_date() as earliest_date;
	return next _earliest_date;

	open _latest_date for
		select "WorkloadBalancing".get_latest_consolidation_interval_date() as latest_date;
	return next _latest_date;

	open _current_history_table_size for
		-- assume page size using default 8kb
		select sum(relpages::bigint * 8 * 1024) as current_history_table_size
		from pg_class
		where relname = 'vm_metric_history'
			or relname = 'vm_cpu_metric_history'
			or relname = 'vm_vif_metric_history'
			or relname = 'vm_vbd_metric_history'
			or relname = 'host_metric_history'
			or relname = 'host_pif_metric_history'
			or relname = 'host_cpu_metric_history'
			or relname = 'host_pbd_metric_history'
			or relname = 'host_vm_history'
			or relname = 'hv_audit_log';
	return next _current_history_table_size;

	return;
end;
$$ language plpgsql;


/*
begin;
select  groom_get_db_info();
fetch all in "<unnamed portal 8>";
end;
select * from vm_metric_history
*/

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Brian Donegan
-- Date:			November 18, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 22, 2010
-- Description:
--	 Add a row to the host_metric table, returning the hostmetricid.
-- Parameters:
--   hostid                - The database ID (id column of the hv_host table)
--                           of the host owning the metrics.
--   total_mem             - Total memory on the host in bytes
--   free_mem              - Free memory on the host in bytes
--   load_average          - Hypervisor load factor
--   avg_cpu_utilization   - Average utilization of all CPU in the host.
--   avg_pif_read_per_sec  - Average reads/sec of all PIFs in the host.
--   avg_pif_write_per_sec - Average writes/sec of all PIFs in the host.
--   tstamp                - UTC date and time stamp for the metrics.
--   interval_id		   - The database ID of the time interval pertaining to the metric data.
-- Returns:
--   int                   - The id of the new row, used for foreign-key inserts
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".host_metric_add
(
	_hour_interval 		int,
	_five_minute_interval 	int,
	_day_of_year 		int,
	_year 			int,
	_hostid                 int,
	_total_mem              bigint,
	_free_mem		bigint,
	_load_average		decimal(9,3),
	_avg_cpu_utilization	decimal(9,8),
	_avg_pif_read_per_sec	decimal(18,4),
	_avg_pif_write_per_sec	decimal(18,4),
	_cpu 			int[], 
	_utilization 		numeric(9,8)[], 
	_pif 			int[], 
	_io_read_per_sec 	numeric(18,4)[], 
	_io_write_per_sec 	numeric(18,4)[], 
	_tstamp                 timestamp
);

create function "WorkloadBalancing".host_metric_add
(
	_hour_interval 		int,
	_five_minute_interval 	int,
	_day_of_year 		int,
	_year 			int,
	_hostid                 int,
	_total_mem              bigint,
	_free_mem		bigint,
	_load_average		decimal(9,3),
	_avg_cpu_utilization	decimal(9,8),
	_avg_pif_read_per_sec	decimal(18,4),
	_avg_pif_write_per_sec	decimal(18,4),
	_cpu 			int[], 
	_utilization 		numeric(9,8)[], 
	_pif 			int[], 
	_io_read_per_sec 	numeric(18,4)[], 
	_io_write_per_sec 	numeric(18,4)[], 
	_tstamp                 timestamp
) returns int as $$
declare
	_insert_id 		int;
	_interval_id 		int;
begin

	-- Check to be sure the host exists before inserting metrics
	-- If it does not exist, return -1
	if (not exists(select uuid from hv_host where id = _hostid limit 1))
	then
		return -1;
	else
	
	_interval_id = (select * from get_consolidation_interval(_hour_interval, _five_minute_interval, _day_of_year, _year));

	insert into host_metric (
			hostid,
			total_mem,
			free_mem,
			load_average,
			avg_cpu_utilization,
			avg_pif_read_per_sec,
			avg_pif_write_per_sec,
			tstamp,
			intervalid ) 
		values (_hostid,
			_total_mem,
			_free_mem,
			_load_average,
			_avg_cpu_utilization,
			_avg_pif_read_per_sec,
			_avg_pif_write_per_sec,
			_tstamp,
			_interval_id ) returning id into _insert_id;


	insert into host_cpu_metric (host_metric_id, cpu, utilization)
		values(_insert_id, unnest(_cpu), unnest(_utilization));



	insert into host_pif_metric (host_metric_id, pif, io_read_per_sec, io_write_per_sec)
		values(_insert_id, unnest(_pif), unnest(_io_read_per_sec), unnest(_io_write_per_sec));

	return _insert_id;

	end if;
	
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: Sept 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 17, 2010	
-- Description:
--	 Get the ID that should be used from the next set of audit entries
-- Parameters:
--   none
-- Returns:
--   Integer representing the ID that should be used for the next set of audit
--   entries
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_audit_get_next_event_id();

create function "WorkloadBalancing".hv_audit_get_next_event_id() 
returns int as $$

declare
	_num_rows   int;
	_current_id int;
	_tstamp     bigint;
	_done       boolean;
	_count int;

begin
	select into _num_rows count(*) from hv_audit_next_event_id;
	if _num_rows > 0 then
		_done := false;

		select into _current_id, _tstamp next_id, last_update from hv_audit_next_event_id;
		_current_id := _current_id + 1;

		loop
		if _done then
			exit;
		end if;
			update hv_audit_next_event_id 
				set next_id=_current_id
				where last_update = _tstamp;
				get diagnostics _count = ROW_COUNT;
				if _count = 1 then				
					_done := true;
				end if;
		
		end loop;
	else
		_current_id := 1;
		insert into hv_audit_next_event_id (next_id) values (_current_id);
	end if;
	return _current_id;

end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		Sept 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 17, 2010	
-- Description:
--	 Add a record to the hv_audit table
-- Parameters:
--   event_id     - If non-zero, the identifier that groups related audit 
--				    records. If zero, the event_id will be generated.
--   move_rec_id  - The database ID (id column of the move_recommendation_detail
--					table) of the move recommendation associated with the audit
--					event.
--	 event_type   - Describes the type of audit event to write.
--   vm_id		  - The database ID (id column of the virtual_machine table)
--                  of the VM for which the audit record applies.
--   from_host_id - The database ID (id column of the host table) of the host 
--                  from which the VM should move.
--   to_host_id   - The database ID (id column of the host table) of the host 
--                  to which the VM should move or on which the VM should be
--					started.
--   status       - Describes the status of the audit event.
--   start_time	  - The UTC date and time the audit event starts.
-- Returns:
--   The database ID (id column of the hv_audit table) of the new audit record
--   and the event_id of the new audit record.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_audit_add
(
	_event_id		int,
	_move_rec_id    	int,
	_event_type		int,
	_vm_id			int,
	_from_host_id		int,
	_to_host_id		int,
	_status			int,
	_start_time		timestamp
);

create function "WorkloadBalancing".hv_audit_add
(
	_event_id		int,
	_move_rec_id    	int,
	_event_type		int,
	_vm_id			int,
	_from_host_id		int,
	_to_host_id		int,
	_status			int,
	_start_time		timestamp
) returns setof bigint_tuple as $$

declare _pool_id int;
	_audit_id bigint;
	r bigint_tuple%rowtype;
begin
	if _event_id = 0 then
		select into _event_id hv_audit_get_next_event_id();
	end if;

	if _vm_id is not null and _vm_id > 0 then
		select into _pool_id poolid from virtual_machine where id = _vm_id;
	elsif _from_host_id is not null and _from_host_id > 0 then
		select into _pool_id poolid from hv_host where id = _from_host_id;
	elsif _to_host_id is not null and _to_host_id > 0 then
		select into _pool_id poolid from hv_host where id = _to_host_id;
	end if;

	insert into hv_audit (event_id,
			 recommendation_detail_id,
			 event_type,
			 pool_id,
			 vm_id,
			 from_host_id,
			 to_host_id,
			 status,
			 start_time)
		values (_event_id,
			 _move_rec_id,
			 _event_type,
			 _pool_id,
			 _vm_id,
			 _from_host_id,
			 _to_host_id,
			 _status,
			 _start_time) returning id into _audit_id;
	for r in select _audit_id, _event_id loop
	return next r;
	end loop;
	return;
end;

$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		Sept 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 18, 2010	
-- Description:
--	 Update a record int the hv_audit table
-- Parameters:
--   audit_id     - The database ID (id column of the hv_audit table) of the 
--				    audit record to update.
--   status       - Describes the status of the audit event.
--   end_time	  - Optional ending UTC time stamp for the audit event.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_audit_update
(
	_audit_id		int,
	_status			int,
	_end_time		timestamp
);

create function "WorkloadBalancing".hv_audit_update
(
	_audit_id		int,
	_status			int,
	_end_time		timestamp default null
) returns void as $$
begin
	update hv_audit 
		  set status=_status,
			  end_time=_end_time
		where id=_audit_id;
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		April 8, 2009
-- Modified:	Oct 13, 2010
-- Reason: to convert it to PostgreSQL
-- Description:
--	 Add a record in the hv_host_config table.
-- Parameters:
--   host_id        - The database ID (id column of the hv_host table) of the 
--                    host to which the configuration data applies.
--   name           - Name of the configuration item to add.
--   value		    - Value of the configuration item to add.
--   default_value	- Default value of the configuration item to add.
--	 description    - Description of the configuration item to add.
--   tstamp         - UTC date and time the configutation item was added.
-- Returns:
--   None
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_host_config_add 
(
	_host_id       int,
	_name          varchar(100),
	_value         varchar(100),
	_default_value varchar(100),
	_description   varchar(256),
	_tstamp        timestamp
);

create function "WorkloadBalancing".hv_host_config_add (
	_host_id       int,
	_name          varchar(100),
	_value         varchar(100),
	_default_value varchar(100) DEFAULT null,
	_description   varchar(256) DEFAULT null,
	_tstamp        timestamp    DEFAULT null
) returns void AS $$
DECLARE
	_id int := null;

BEGIN
	_id := (select id from hv_host_config where host_id=_host_id and
		name=_name);

	if _id is null then
	  begin
	    if _tstamp is null then
	      _tstamp := getutcdate();
	    end if;
	    
	    insert into hv_host_config (host_id, name, value, default_value, description, tstamp)
		values (_host_id, _name, _value, _default_value, _description, _tstamp);	    
	  end;
	else
	  raise exception 'Config item already exists for host';
	end if;
END;
$$ language plpgsql;












-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		April 08, 2009
-- Modified to pgsql	Oct 13, 2010
-- Description:
--	 Retrieve all of the records in the hv_host_config table for the specified
--   host.
-- Parameters:
--   host_id        - The database ID (id column of the hv_host table) of the 
--                    host for which the configuration data will be retrieved.
-- Returns:
--   Data set with the config data
-- drop function "WorkloadBalancing".hv_host_config_get(int)

-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_host_config_get
(
	_host_id int
); 

create function "WorkloadBalancing".hv_host_config_get(
	_host_id int
) returns setof hv_host_config as $$
declare
	ret_row hv_host_config%rowtype;
begin
	FOR ret_row in select id,
		host_id,
		name,
		value,
		default_value,
		description,
		tstamp
	from hv_host_config	
	where host_id = _host_id loop
	return next ret_row;
	end loop;
	return;	
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Date:		August 12, 2009
-- Modified for Postgres	Oct 13, 2010
-- By: 			Rabin Karki
-- Description:
--	 Retrieves a host configuration value from the hv_host_config table, or an 
--      optional default return value if the desired key name is not found
-- Parameters:
--   host_id - the database ID (id column of the hv_host table) of the host
--   key_name - the key name of the value to retrieve (name column of the
--              hv_host_config table
--   default_value - optional value to return if the desired key name is not 
--                   found
-- Returns:
--   The host configuration value with the supplied key
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_host_config_value
(
	_host_id 	bigint,
	_key_name 	varchar(100),
	_default_value  varchar(100)
);

create function "WorkloadBalancing".fn_get_host_config_value
(
	_host_id 	bigint,
	_key_name 	varchar(100),
	_default_value 	varchar(100) default null
) returns varchar(100) as $$
declare _return_value varchar(100);
begin
	select value into _return_value
		from hv_host_config
		where host_id = _host_id
		and name = _key_name;
	if _return_value is null then
		return _default_value;
	else
		return _return_value;
	end if;
	
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		March 10, 2009
-- Modified:		Oct 13, 2010
-- Description:
--	 Retrieve the value of one configuration item for the specified host.
-- Parameters:
--   host_id        - The database ID (id column of the hv_host table) of the 
--                    host for which the configuration data will be retrieved.
--   item_name      - Name of the configuration item to retrieve.
-- Returns:
--   Data set with the config data
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_host_config_get_item  
(
	_host_id int,
	_item_name varchar(128)
);

create function "WorkloadBalancing".hv_host_config_get_item (
	_host_id int,
	_item_name varchar(128)
) returns varchar(100) as $$
declare
	_value varchar(100);
begin
	select value into _value
	  from hv_host_config
	 where host_id = _host_id and name = _item_name;
	 return _value;
end;
$$
language plpgsql;
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		April 8, 2009
-- Description:
--	 update a record in the hv_host_config table.
-- Parameters:
--   host_id        - The database ID (id column of the hv_host table) of the 
--                    host to which the configuration data applies.
--   name           - Name of the configuration item to update.
--   value		    - New Value of the configuration item to update.
--   tstamp         - UTC date and time the record is updated.
-- Returns:
--   None
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_host_config_update
(
	_host_id 	int,
	_name 		varchar(100),
	_value 		varchar(100),
	_tstamp 	timestamp
);

create function "WorkloadBalancing".hv_host_config_update
(
	_host_id 	int,
	_name 		varchar(100),
	_value 		varchar(100),
	_tstamp 	timestamp default null
) returns void as $$
declare
	_tstamp timestamp;
begin
	_tstamp := getutcdate();

	update hv_host_config
		set value = _value,
		tstamp = _tstamp
	  where host_id = _host_id and
	  name = _name;

	IF NOT FOUND THEN
		perform hv_host_config_add(_host_id, _name, _value);
	end if;
	end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		Oct 23, 2008
-- Rabin Karki
-- Nov 17, 2010
-- Description:
--	 Set the enabled state of the specified host.
-- Parameters:
--   host_uuid  - unique identifier of the host whose enabled state is to be set.
--   pool_uuid  - unique identifier of the pool containing the host.
--   enabled    - true if the host is enabled; false if the host is disabled.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_host_set_enabled
(
	_host_uuid	varchar(48),
	_pool_uuid	varchar(48),
	_enabled	boolean
);

create function "WorkloadBalancing".hv_host_set_enabled
(
	_host_uuid	varchar(48),
	_pool_uuid	varchar(48),
	_enabled	boolean
) returns void as $$

declare _pool_id int;
begin
	select into _pool_id id from hv_pool where uuid=_pool_uuid;

	update hv_host set enabled=_enabled where uuid=_host_uuid and poolid=_pool_id;
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		March 10, 2009
-- For Postgres		11/11/2010
-- By:			Rabin Karki
-- Description:
--	 Add a record in the hv_pool_config table.
-- Parameters:
--   pool_id        - The database ID (id column of the hv_pool table) of the 
--                    pool to which the configuration data applies.
--   name           - Name of the configuration item to add.
--   value		    - Value of the configuration item to add.
--   default_value	- Default value of the configuration item to add.
--	 description    - Description of the configuration item to add.
--   tstamp         - UTC date and time the configutation item was added.
-- Returns:
--   None
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_pool_config_add 
(
	_pool_id       int,
	_name          varchar(100),
	_value         varchar(100),
	_default_value varchar(100),
	_description   varchar(256),
	_tstamp        timestamp
);

create function "WorkloadBalancing".hv_pool_config_add 
(
	_pool_id       int,
	_name          varchar(100),
	_value         varchar(100),
	_default_value varchar(100) default null,
	_description   varchar(256) default null,
	_tstamp        timestamp default null
) returns void as $$

declare 
	_id int := null;

begin
	
	select into _id id from hv_pool_config where pool_id=_pool_id and name=_name;
	
	if _id is null then
		if _tstamp is null then
			_tstamp := getutcdate();
		end if;
				
		insert into hv_pool_config (pool_id,
				   name,
				   value,
				   default_value,
				   description,
				   tstamp)
		   values (_pool_id,
				   _name,
				   _value,
				   _default_value,
				   _description,
				   _tstamp);
	else
		raise exception 'Config item already exists for pool';
	end if;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		March 10, 2009
-- Modified for Postgres: Nov 11, 2010
-- By:			Rabin Karki
-- Description:
--	 Retrieve all of the records in the hv_pool_config table for the specified
--   pool.
-- Parameters:
--   pool_id        - The database ID (id column of the hv_pool table) of the 
--                    pool for which the configuration data will be retrieved.
-- Returns:
--   Data set with the config data
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_pool_config_get
(
	_pool_id       int
); 

create function "WorkloadBalancing".hv_pool_config_get
(
	_pool_id       int
) returns setof hv_pool_config as $$
declare
	r hv_pool_config%rowtype;
begin
	
	for r in select id,
		   pool_id,
		   name,
		   value,
		   default_value,
		   description,
		   tstamp
		from hv_pool_config
	where pool_id = _pool_id loop
	return next r;
	end loop;
	return;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Retrieves a pool configuration value from the hv_pool_config table, or an 
--   optional default return value if the desired key name is not found
-- Parameters:
--   pool_id - the database ID (id column of the hv_pool table) of the pool
--   key_name - the key name of the value to retrieve (name column of the
--              hv_pool_config table
--   default_value - optional value to return if the desired key name is not 
--                   found
-- Returns:
--   The pool configuration value with the supplied key
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".fn_get_pool_config_value
( 
	_pool_id	int,
	_key_name	varchar(100),
	_default_value  varchar(100)
);

CREATE FUNCTION "WorkloadBalancing".fn_get_pool_config_value
( 
	_pool_id	int,
	_key_name	varchar(100),
	_default_value  varchar(100) = null
) 
RETURNS varchar(100) AS $$

DECLARE
	_return_value varchar(100);

BEGIN

	_return_value := (select value
			  from hv_pool_config
			  where pool_id = _pool_id
				and name = _key_name);

	if _return_value is null then
		_return_value := _default_value;
	end if;

	return _return_value;
	
END;
$$ LANGUAGE plpgsql;


-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			March 10, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Retrieve the value of one configuration item for the specified pool.
-- Parameters:
--   pool_id        - The database ID (id column of the hv_pool table) of the 
--                    pool for which the configuration data will be retrieved.
--   item_name      - Name of the configuration item to retrieve.
-- Returns:
--   Data set with the config data
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_pool_config_get_item
(
	_pool_id       int,
	_item_name     varchar(128)
);

create function "WorkloadBalancing".hv_pool_config_get_item
(
	_pool_id       int,
	_item_name     varchar(128)
) returns varchar(100) as $$
begin

	return (select value
	  from hv_pool_config
	where pool_id = _pool_id and name = _item_name);
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		March 10, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 11, 2010
-- Description:
--	 update a record in the hv_pool_config table.
-- Parameters:
--   pool_id        - The database ID (id column of the hv_pool table) of the 
--                    pool to which the configuration data applies.
--   name           - Name of the configuration item to update.
--   value		    - New Value of the configuration item to update.
--   tstamp         - UTC date and time the record is updated.
-- Returns:
--   None
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_pool_config_update
(
	_pool_id       int,
	_name          varchar(100),
	_value         varchar(100),
	_tstamp        timestamp
);

create function "WorkloadBalancing".hv_pool_config_update
(
	_pool_id       int,
	_name          varchar(100),
	_value         varchar(100),
	_tstamp        timestamp default null
) returns void as $$
begin

	if _tstamp is null then
		_tstamp := getutcdate();
	end if;
	
	if exists (select * from hv_pool_config where pool_id=_pool_id and name=_name) then
	
		update hv_pool_config
			set value=_value,
				tstamp=_tstamp
		  where pool_id = _pool_id and
				name    = _name;
	
	else
	
		insert into hv_pool_config (pool_id, name, value, tstamp)
			values(_pool_id, _name, _value, _tstamp);
	
	end if;
	        
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		Mar 05, 2009
-- Modified for PgSQL	Oct 14, 2010
-- Description:
--	 Set the enabled state of the specified pool.  If the pool is enabled, the 
--   WLB data collector will collect metrics from the pool.
-- Parameters:
--   pool_id  - the database ID (id column of the hv_pool table) of the pool
--              whose enabled state is to be set.
--   enabled  - true if the pool is enabled; false if the pool is disabled.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_pool_set_enabled
(
	_pool_id int,
	_enabled boolean
);

create function "WorkloadBalancing".hv_pool_set_enabled
(
	_pool_id int,
	_enabled boolean
) returns void as $$
begin
	update hv_pool set enabled=_enabled where id=_pool_id;
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Set the is_licensed state of the specified pool.
-- Parameters:
--   pool_id    - The database ID (id column of the hv_pool table) of the pool
--                whose license state is to be set.
--   enabled    - true if the pool has a valid license; false otherwise.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_pool_set_licensed
(
	_pool_id     int,
	_is_licensed boolean
);

CREATE FUNCTION "WorkloadBalancing".hv_pool_set_licensed
(
	_pool_id     int,
	_is_licensed boolean
) RETURNS void AS $$

BEGIN

	update hv_pool
	   set is_licensed =_is_licensed,
	       tstamp = getutcdate()
	 where id=_pool_id;
	
END;

$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: June 11, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 18, 2010	
-- Description:	
--	 Retrieve the data collection hosts and the hypervisor pools that they
--   have been assigned to monitor.
-- Parameters:
--	 None
-- Returns:
--   The data collection hosts and the hypervisor pools that they
--   have been assigned to monitor.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_collection_hosts();

create function "WorkloadBalancing".load_collection_hosts() 
returns refcursor as $$

declare
	cur refcursor;
begin

	open cur for

	select ch.id,
		ch.hostname,
		chp.poolid,
		chp.touched_by,
		chp.tstamp,
		cs.description,
		p.name,
		p.hv_type,
		p.uuid,
		p.pool_master_1_addr,
		p.pool_master_1_port
		from collection_host ch
		left join collection_host_hv_pool chp on chp.collection_host_id=ch.id
		left join hv_pool p on chp.poolid = p.id
		left join collection_state cs on chp.state = cs.stateid
		order by ch.hostname;
	
	return cur;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		May 3, 2008
-- Modified for PGSQL	Oct 14, 2010
-- Description:
--	 Retrieve the configuration data used by the data collection and analysis
--   components.
-- Parameters:
--   None
-- Returns:
--   Data set
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_core_config();

create function "WorkloadBalancing".load_core_config() 
returns setof core_config as $$
declare
	r record;
begin
	for r in select component_id, 
		   category,
		   item_name,
		   value,
		   default_value,
		   description,
		   touched_by,
		   tstamp
	from core_config loop
	return next r;
	end loop;
	return;
	
end;
$$
language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		Sept 3, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 16, 2010
-- Description:
--	 Retrieve the configuration data and basic VM data for the specified host.
-- Parameters:
--   host_id    - the database ID (id column of the hv_host table) of the host
--                to load.
-- Returns:
--   Two result sets:
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_host_by_id
(
	_host_id int
);

create function "WorkloadBalancing".load_host_by_id
(
	_host_id int
) returns setof refcursor as $$
declare
	cur1 refcursor;
	cur2 refcursor;
	
begin


	open cur1 for
		select h.name,
	       h.uuid,
	       h.poolid,
		   h.description,
	       h.num_cpus,
		   h.cpu_speed,
	       h.num_pifs,
		   h.is_pool_master,
		   h.enabled,
		   ph.fill_order,
		   h.ip_address,
		   h.status,
		   h.last_result,
		   h.last_result_time,
		  ( select total_mem 
			from host_metric hm 
			where hm.hostid = ph.hostid 
			order by hm.tstamp desc limit 1
		  ) as total_mem,
          h.memory_overhead
	 from hv_host h
	 join hv_pool_host ph on ph.hostid=h.id
	 where h.id = _host_id;
	return next cur1;

	open cur2 for 
	select hv.hostid,
		   hv.vmid,
		   v.name,
           v.uuid,
           v.poolid,
		   v.description,
		   v.min_dynamic_memory,
		   v.max_dynamic_memory,
		   v.min_static_memory,
		   v.max_static_memory,
		   v.target_memory,
		   v.memory_overhead,
		   fn_required_memory(v.id) as required_memory,
		   v.min_cpus,
		   v.hv_memory_multiplier,
           v.is_control_domain,
           v.is_agile,
           v.drivers_up_to_date,
		   v.status,
		   v.last_result,
		   v.last_result_time
	from host_vm hv
	join virtual_machine v on v.id=hv.vmid
	where hv.hostid=_host_id and
          v.active=true
	order by v.name;
	return next cur2;

	return;
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		Sept 3, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 16, 2010
-- Description:
--	 Retrieve the configuration data and basic VM data for all hosts in the
--   specified pool.
-- Parameters:
--   pool_id	- the database ID (id column of the hv_pool table) of the pool
--                whose hosts will be retrieved.
-- Returns:
--   Two result sets:
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_host_by_pool_id
(
	_pool_id int
);

create function "WorkloadBalancing".load_host_by_pool_id
(
	_pool_id int
) returns setof refcursor as $$

declare
	cur1 refcursor;
	cur2 refcursor;

begin
	
	open cur1 for
		select ph.hostid,
	       h.name,
	       h.uuid,
	       h.poolid,
		   h.description,
	       h.num_cpus,
		   h.cpu_speed,
	       h.num_pifs,
		   h.is_pool_master,
		   h.enabled,
		   ph.fill_order,
		   h.ip_address,
		   h.status,
		   fn_get_host_config_value(h.id, 'ParticipatesInPowerManagement', 'false') can_power,
		   h.last_result,
		   h.last_result_time,
		  ( select total_mem 
			from host_metric hm 
			where hm.hostid = ph.hostid 
			order by hm.tstamp desc limit 1
		  ) as total_mem,
		  ( select avg_total_mem 
			from host_metric_con hmc 
			where hmc.hostid = ph.hostid 
			order by hmc.end_time desc limit 1
		  ) as total_mem_con,
           h.memory_overhead
	 from hv_pool_host ph
	 join hv_host h on ph.hostid=h.id
	 where ph.poolid = _pool_id
	 order by h.name;
	return next cur1;
	 --order by ph.hostid

	open cur2 for
	select hv.hostid,
		   hv.vmid,
		   v.name,
           v.uuid,
           v.poolid,
		   v.description,
		   v.min_dynamic_memory,
		   v.max_dynamic_memory,
		   v.min_static_memory,
		   v.max_static_memory,
		   v.target_memory,
		   v.memory_overhead,
		   fn_required_memory(v.id) as required_memory,
		   v.min_cpus,
		   v.hv_memory_multiplier,
           v.is_control_domain,
           v.is_agile,
           v.drivers_up_to_date,
		   v.status,
		   v.last_result,
		   v.last_result_time
	from host_vm hv
	join virtual_machine v on v.id=hv.vmid
	join hv_pool_host ph on ph.hostid=hv.hostid
	where ph.poolid = _pool_id and
          v.active=true
	order by v.name;
	return next cur2;

	return;
	--order by hv.hostid
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		April 7, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 16, 2010
-- Description:
--	 Retrieve the configuration data and basic VM data for the specified host
--   with the specified power state.
-- Parameters:
--   pool_id     - the database ID (id column of the hv_pool table) of the pool
--                 whose hosts with the specified power state are to be loaded.
--   power_state - the power state to match on.
--                     0 = None
--                     1 = On
--                     2 = Off
-- Returns:
--   Three result sets:
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_host_by_power_state
(
	_pool_id     int,
	_power_state int
);

create function "WorkloadBalancing".load_host_by_power_state
(
	_pool_id     int,
	_power_state int
) returns setof refcursor as $$
declare
	cur1 refcursor;
	cur2 refcursor;
	cur3 refcursor;

begin
	open cur1 for 
		select h.name,
	       h.uuid,
	       h.poolid,
		   h.description,
	       h.num_cpus,
		   h.cpu_speed,
	       h.num_pifs,
		   h.is_pool_master,
		   h.enabled,
		   ph.fill_order,
		   h.ip_address,
		   h.status,
		   fn_get_host_config_value(h.id, 'ParticipatesInPowerManagement', 'false') as can_power,
		   h.last_result,
		   h.last_result_time,
		  ( select total_mem 
			from host_metric hm 
			where hm.hostid = ph.hostid 
			order by hm.tstamp desc limit 1) as total_mem,
		  ( select avg_total_mem 
			from host_metric_con hmc 
			where hmc.hostid = ph.hostid 
			order by hmc.end_time desc limit 1
		  ) as total_mem_con,
           h.memory_overhead
	 from hv_host h
	 join hv_pool_host ph on ph.hostid=h.id
	where ((_power_state=1 and h.power_state=_power_state) or
		   (_power_state=2 and h.power_state=_power_state and h.powered_off_by_wlb=true))
		    and ph.poolid=_pool_id;
	return next cur1;

	open cur2 for
		select hv.hostid,
		   hv.vmid,
		   v.name,
           v.uuid,
           v.poolid,
		   v.description,
		   v.min_dynamic_memory,
		   v.max_dynamic_memory,
		   v.min_static_memory,
		   v.max_static_memory,
		   v.target_memory,
		   v.memory_overhead,
		   fn_required_memory(v.id) as required_memory,
		   v.min_cpus,
		   v.hv_memory_multiplier,
           v.is_control_domain,
           v.is_agile,
           v.drivers_up_to_date,
		   v.status,
		   v.last_result,
		   v.last_result_time
	from host_vm hv
	join virtual_machine v on v.id=hv.vmid
	join hv_host h on h.id=hv.hostid
	where ((_power_state=1 and h.power_state=_power_state) or
		  (_power_state=2 and h.power_state=_power_state and h.powered_off_by_wlb=true))
		 and h.poolid=_pool_id
         and v.active=true 
	order by v.name;
	return next cur2;
	
	open cur3 for 
		select hsr.host_id,
		   hsr.sr_id,
		   sr.name,
           sr.uuid,
           sr.size,
		   sr.used,
		   sr.poolid,
		   sr.pool_default_sr
	from hv_host_storage_repository hsr
	join storage_repository sr on sr.id=hsr.sr_id
	join hv_host h on h.id=hsr.host_id
   where ((_power_state=1 and h.power_state=_power_state) or
		  (_power_state=2 and h.power_state=_power_state and h.powered_off_by_wlb=true))
		 and h.poolid=_pool_id
	order by hsr.host_id;
	return next cur3;
	return;
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		August 6, 2009
-- Updated:		December 15, 2010
--			Converted to PostGreSQL
-- Description:
--	 Retrieve the configuration data for the specified host.
-- Parameters:
--   host_id    - the database ID (id column of the hv_host table) of the host
--                to load.
-- Returns:
--   Three result sets:
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_host_simple_by_id
(
	_host_id 	integer
);

CREATE FUNCTION "WorkloadBalancing".load_host_simple_by_id
(
	_host_id 	integer
)
RETURNS SETOF refcursor AS $$
DECLARE
	_total_mem 			bigint;
	_ref_host_config_data		refcursor;
BEGIN

	_total_mem := (	select total_mem from host_metric 
			where hostid = _host_id
			order by id desc 
			limit 1 );

	if (_total_mem is null) then

		_total_mem := (	select avg_total_mem from host_metric_con 
				where hostid = _host_id
				order by id desc 
				limit 1 );
	end if;


	if (_total_mem is null) then

		_total_mem := (	select avg_total_mem from host_metric_history 
				where hostid = _host_id
				order by id desc 
				limit 1 );
	end if;


	-- RESULT SET - 
	open _ref_host_config_data for
		select h.name,
			h.uuid,
			h.poolid,
			h.description,
			h.num_cpus,
			h.cpu_speed,
			h.num_pifs,
			h.is_pool_master,
			h.enabled,
			ph.fill_order,
			h.ip_address,
			h.status,
			h.last_result,
			h.last_result_time,
			_total_mem as total_mem,
		 h.memory_overhead
		 from hv_host h
		 join hv_pool_host ph on ph.hostid=h.id
		 where h.id = _host_id;
	return next _ref_host_config_data;

	RETURN;
END;
$$ LANGUAGE plpgsql;
-- ============================================================================
-- (c) Copyright 2011 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Barbara Li
-- Date:			December 15, 20011
--
-- Description:
--	 Retrieve the configuration and threshold data for a hypervisor pool.
-- Parameters:
--   pool_id   - The database ID (id column of the hv_pool table) of the pool
--               whose configuration and threshold data is to be retrieved.
-- Returns:
--   Result set contains the basic pool configuration plus the thresholds and
--   weights for the pool.
-- ============================================================================

--select * from load_hv_pool_threshold_by_ids(47)
DROP FUNCTION IF EXISTS "WorkloadBalancing".load_hv_pool_threshold_by_ids
(
	_pool_ids 	int[]
);

CREATE FUNCTION "WorkloadBalancing".load_hv_pool_threshold_by_ids
(
	_pool_ids 	int[],
	out		poolid int,
	out 		opt_mode int,
	out		host_cpu_threshold_critical numeric,
	out		host_cpu_threshold_high numeric,
	out		host_cpu_threshold_medium numeric,
	out		host_cpu_threshold_low numeric,
    
	out		host_memory_threshold_critical bigint,
	out		host_memory_threshold_high bigint,
	out		host_memory_threshold_medium bigint,
	out		host_memory_threshold_low bigint,
    
	out		host_net_read_threshold_critical bigint,
	out		host_net_read_threshold_high bigint,
	out		host_net_read_threshold_medium bigint,
	out		host_net_read_threshold_low bigint,
    
	out		host_net_write_threshold_critical bigint,
	out		host_net_write_threshold_high bigint,
	out		host_net_write_threshold_medium bigint,
	out		host_net_write_threshold_low bigint,
    
	out		host_disk_read_threshold_critical bigint,
	out		host_disk_read_threshold_high bigint,
	out		host_disk_read_threshold_medium bigint,
	out		host_disk_read_threshold_low bigint,
    
	out		host_disk_write_threshold_critical bigint,
	out		host_disk_write_threshold_high bigint,
	out		host_disk_write_threshold_medium bigint,
	out		host_disk_write_threshold_low bigint,
    
	out		host_load_avg_threshold_critical numeric,
	out		host_load_avg_threshold_high numeric,
	out		host_load_avg_threshold_medium numeric,
	out		host_load_avg_threshold_low numeric,
    
	out		host_runstate_blocked_threshold_critical numeric,
	out		host_runstate_blocked_threshold_high numeric,
	out		host_runstate_blocked_threshold_medium numeric,
	out		host_runstate_blocked_threshold_low numeric,
			
	out		host_runstate_partial_run_threshold_critical numeric,
	out		host_runstate_partial_run_threshold_high numeric,
	out		host_runstate_partial_run_threshold_medium numeric,
	out		host_runstate_partial_run_threshold_low numeric,
    
	out		host_runstate_fullrun_threshold_critical numeric,
	out		host_runstate_fullrun_threshold_high numeric,
	out		host_runstate_fullrun_threshold_medium numeric,
	out		host_runstate_fullrun_threshold_low numeric,
    
	out		host_runstate_partial_contention_threshold_critical numeric,
	out		host_runstate_partial_contention_threshold_high numeric,
	out		host_runstate_partial_contention_threshold_medium numeric,
	out		host_runstate_partial_contention_threshold_low numeric,
    
	out		host_runstate_concurrency_hazard_threshold_critical numeric,
	out		host_runstate_concurrency_hazard_threshold_high numeric,
	out		host_runstate_concurrency_hazard_threshold_medium numeric,
	out		host_runstate_concurrency_hazard_threshold_low numeric,
    
	out		host_runstate_full_contention_threshold_critical numeric,
	out		host_runstate_full_contention_threshold_high numeric,
	out		host_runstate_full_contention_threshold_medium numeric,
	out		host_runstate_full_contention_threshold_low numeric,
	out		over_commit_cpu_ratio int,
	out		over_commit_cpu_in_perf_mode int,
	out		over_commit_cpu_in_density_mode int,
	out		auto_balance_enabled int,
	out		power_management_enabled int,

	out		pool_master_cpu_limit varchar(100),
	out		pool_master_net_io_limit varchar(100),
	out		prefer_power_on_over_compression varchar(100),
	out		power_on_host_if_no_memory varchar(100),
	out		power_on_host_if_no_sr varchar(100),
	out		compress_guests_to_relieve_pressure varchar(100),
	out		compress_guests_to_preserve_power varchar(100),
	out		weight_current_metrics numeric,
	out		weight_last_30_metrics numeric,
	out		weight_yesterday_metrics numeric,
	out		vm_cpu_threshold_high numeric,
	out		vm_cpu_threshold_medium numeric,
	out		vm_cpu_threshold_low numeric,
	out		vm_cpu_weight_high numeric,
	out		vm_cpu_weight_medium numeric,
	out		vm_cpu_weight_low numeric,
	out		vm_memory_threshold_high bigint,
	out		vm_memory_threshold_medium bigint,
	out		vm_memory_threshold_low bigint,
	out		vm_memory_weight_high  numeric,
	out		vm_memory_weight_medium numeric,
	out		vm_memory_weight_low numeric,
    
	out		vm_net_read_threshold_high bigint,
	out		vm_net_read_threshold_medium bigint,
	out		vm_net_read_threshold_low bigint,
	out		vm_net_read_weight_high numeric,
	out		vm_net_read_weight_medium numeric,
	out		vm_net_read_weight_low numeric,
    
	out		vm_net_write_threshold_high bigint,
	out		vm_net_write_threshold_medium bigint,
	out		vm_net_write_threshold_low bigint,
	out		vm_net_write_weight_high  numeric,
	out		vm_net_write_weight_medium numeric,
	out		vm_net_write_weight_low numeric,
    
	out		vm_disk_read_threshold_high bigint,
	out		vm_disk_read_threshold_medium bigint,
	out		vm_disk_read_threshold_low bigint,
	out		vm_disk_read_weight_high numeric,
	out		vm_disk_read_weight_medium numeric,
	out		vm_disk_read_weight_low numeric,
    
	out		vm_disk_write_threshold_high bigint,
	out		vm_disk_write_threshold_medium bigint,
	out		vm_disk_write_threshold_low bigint,
	out		vm_disk_write_weight_high numeric,
	out		vm_disk_write_weight_medium numeric,
	out		vm_disk_write_weight_low numeric,
    
	out		vm_runstate_weight_high numeric,
	out		vm_runstate_weight_medium numeric,
	out		vm_runstate_weight_low numeric
)
RETURNS setof record AS $$

DECLARE 
	r record;

BEGIN
	return query 
		select	
			pt.pool_id as poolid,
			cast(pc1.value as int) as opt_mode,
				
			pt.host_cpu_threshold_critical,
			pt.host_cpu_threshold_high,
			pt.host_cpu_threshold_medium,
			pt.host_cpu_threshold_low,

			pt.host_memory_threshold_critical,
			pt.host_memory_threshold_high,
			pt.host_memory_threshold_medium,
			pt.host_memory_threshold_low,

			pt.host_net_read_threshold_critical,
			pt.host_net_read_threshold_high,
			pt.host_net_read_threshold_medium,
			pt.host_net_read_threshold_low,

			pt.host_net_write_threshold_critical,
			pt.host_net_write_threshold_high,
			pt.host_net_write_threshold_medium,
			pt.host_net_write_threshold_low,

			pt.host_disk_read_threshold_critical,
			pt.host_disk_read_threshold_high,
			pt.host_disk_read_threshold_medium,
			pt.host_disk_read_threshold_low,

			pt.host_disk_write_threshold_critical,
			pt.host_disk_write_threshold_high,
			pt.host_disk_write_threshold_medium,
			pt.host_disk_write_threshold_low,

			pt.host_load_avg_threshold_critical,
			pt.host_load_avg_threshold_high,
			pt.host_load_avg_threshold_medium,
			pt.host_load_avg_threshold_low,

			pt.host_runstate_blocked_threshold_critical,
			pt.host_runstate_blocked_threshold_high,
			pt.host_runstate_blocked_threshold_medium,
			pt.host_runstate_blocked_threshold_low,
			
			pt.host_runstate_partial_run_threshold_critical,
			pt.host_runstate_partial_run_threshold_high,
			pt.host_runstate_partial_run_threshold_medium,
			pt.host_runstate_partial_run_threshold_low,

			pt.host_runstate_fullrun_threshold_critical,
			pt.host_runstate_fullrun_threshold_high,
			pt.host_runstate_fullrun_threshold_medium,
			pt.host_runstate_fullrun_threshold_low,

			pt.host_runstate_partial_contention_threshold_critical,
			pt.host_runstate_partial_contention_threshold_high,
			pt.host_runstate_partial_contention_threshold_medium,
			pt.host_runstate_partial_contention_threshold_low,

			pt.host_runstate_concurrency_hazard_threshold_critical,
			pt.host_runstate_concurrency_hazard_threshold_high,
			pt.host_runstate_concurrency_hazard_threshold_medium,
			pt.host_runstate_concurrency_hazard_threshold_low,

			pt.host_runstate_full_contention_threshold_critical,
			pt.host_runstate_full_contention_threshold_high,
			pt.host_runstate_full_contention_threshold_medium,
			pt.host_runstate_full_contention_threshold_low,

			cast(pc13.value as int) as over_commit_cpu_ratio,
			
			--over_commit_cpu_in_perf_mode,
			--over_commit_cpu_in_density_mode,
			
			case upper(pc2.value)
				when 'TRUE'  then 1				
				else 0
			end as over_commit_cpu_in_perf_mode,
			case upper(pc3.value)
				when 'TRUE'  then 1
				else 0
			end as over_commit_cpu_in_density_mode,
			case upper(pc4.value)
				when 'TRUE'  then 1
				else 0
			end as auto_balance_enabled,
			case upper(pc5.value)
				when 'TRUE'  then 1
				else 0
			end as power_management_enabled,
			
			pc6.value as pool_master_cpu_limit,
			pc7.value as pool_master_net_io_limit,
			pc8.value as prefer_power_on_over_compression,
			pc9.value as power_on_host_if_no_memory,
			pc10.value as power_on_host_if_no_sr,
			pc11.value as compress_guests_to_relieve_pressure,
			pc12.value as compress_guests_to_preserve_power,
			
			pt.weight_current_metrics,
			pt.weight_last_30_metrics,
			pt.weight_yesterday_metrics,

			pt.vm_cpu_threshold_high,
			pt.vm_cpu_threshold_medium,
			pt.vm_cpu_threshold_low,
			pt.vm_cpu_weight_high,
			pt.vm_cpu_weight_medium,
			pt.vm_cpu_weight_low,

			pt.vm_memory_threshold_high,
			pt.vm_memory_threshold_medium,
			pt.vm_memory_threshold_low,
			pt.vm_memory_weight_high,
			pt.vm_memory_weight_medium,
			pt.vm_memory_weight_low,

			pt.vm_net_read_threshold_high,
			pt.vm_net_read_threshold_medium,
			pt.vm_net_read_threshold_low,
			pt.vm_net_read_weight_high,
			pt.vm_net_read_weight_medium,
			pt.vm_net_read_weight_low,

			pt.vm_net_write_threshold_high,
			pt.vm_net_write_threshold_medium,
			pt.vm_net_write_threshold_low,
			pt.vm_net_write_weight_high,
			pt.vm_net_write_weight_medium,
			pt.vm_net_write_weight_low,

			pt.vm_disk_read_threshold_high,
			pt.vm_disk_read_threshold_medium,
			pt.vm_disk_read_threshold_low,
			pt.vm_disk_read_weight_high,
			pt.vm_disk_read_weight_medium,
			pt.vm_disk_read_weight_low,

			pt.vm_disk_write_threshold_high,
			pt.vm_disk_write_threshold_medium,
			pt.vm_disk_write_threshold_low,
			pt.vm_disk_write_weight_high,
			pt.vm_disk_write_weight_medium,
			pt.vm_disk_write_weight_low,

			pt.vm_runstate_weight_high,
			pt.vm_runstate_weight_medium,
			pt.vm_runstate_weight_low

		from hv_pool_threshold pt
			join hv_pool_config pc1 on pc1.pool_id=pt.pool_id and pc1.name='OptimizationMode'
			join hv_pool_config pc2 on pc2.pool_id=pt.pool_id and pc2.name='OverCommitCpuInPerfMode'
			join hv_pool_config pc3 on pc3.pool_id=pt.pool_id and pc3.name='OverCommitCpuInDensityMode'
			join hv_pool_config pc4 on pc4.pool_id=pt.pool_id and pc4.name='AutoBalanceEnabled'
			join hv_pool_config pc5 on pc5.pool_id=pt.pool_id and pc5.name='PowerManagementEnabled'
			join hv_pool_config pc6 on pc6.pool_id=pt.pool_id and pc6.name='PoolMasterCpuLimit'
			join hv_pool_config pc7 on pc7.pool_id=pt.pool_id and pc7.name='PoolMasterNetIoLimit'
			left join hv_pool_config pc8 on pc8.pool_id=pt.pool_id and pc8.name='PreferPowerOnOverCompression'
			left join hv_pool_config pc9 on pc9.pool_id=pt.pool_id and pc9.name='PowerOnHostIfNoMemory'
			left join hv_pool_config pc10 on pc10.pool_id=pt.pool_id and pc10.name='PowerOnHostIfNoSR'		
			left join hv_pool_config pc11 on pc11.pool_id=pt.pool_id and pc11.name='CompressGuestsToRelievePressure'
			left join hv_pool_config pc12 on pc12.pool_id=pt.pool_id and pc12.name='CompressGuestsToPreservePower'
			left join hv_pool_config pc13 on pc13.pool_id=pt.pool_id and pc13.name='OverCommitCpuRatio'
		where pt.pool_id::int = any(_pool_ids);
END;

$$ LANGUAGE plpgsql;

/*
begin;
select * from load_hv_pool_threshold_by_ids(array[17,18,19]);
fetch all from "<unnamed portal 3>";
end;
*/
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		July 23, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 4, 2010
-- Description:
--	 Retrieve the configuration and threshold data for a hypervisor pool plus
--   the list of physical hosts that are in the pool.
-- Parameters:
--   pool_id	- the database ID (id column of the hv_pool table) of the pool
--                to load.
-- Returns:
--   Four cursors containing result sets:
--     Result set 1 contains the basic pool configuration.
--     Result set 2 contains the thresholds and weights for the pool.
--     Result set 3 contains the list of hosts in the pool.
--     Result set 4 contains the list of VMs running on each host.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_hv_pool
(
	_pool_id int
);

create function "WorkloadBalancing".load_hv_pool
(
	_pool_id int
) returns setof refcursor as $$
declare 
	cur1 refcursor;
	cur2 refcursor;
	cur3 refcursor;
	cur4 refcursor;
begin
	open cur1 for
		select	p.id,
		p.name,
		p.uuid,
		p.description,
		p.hv_type,
		p.enabled,
		p.is_licensed,
		p.pool_master_1_addr,
		p.pool_master_2_addr,
		p.pool_master_1_port,
		p.pool_master_2_port,
		p.protocol,
		p.username,
		p.password,
		p.touched_by,
		p.tstamp,
		p.status,
		p.last_result,
		p.last_result_time,
		p.discovery_status,
		p.last_discovery_completed
	from hv_pool p
	where p.id = _pool_id;
	return next cur1;

	open cur2 for
		select cast(pc1.value as int) as opt_mode,
			
			pt.host_cpu_threshold_critical,
			pt.host_cpu_threshold_high,
			pt.host_cpu_threshold_medium,
			pt.host_cpu_threshold_low,

			pt.host_memory_threshold_critical,
			pt.host_memory_threshold_high,
			pt.host_memory_threshold_medium,
			pt.host_memory_threshold_low,

			pt.host_net_read_threshold_critical,
			pt.host_net_read_threshold_high,
			pt.host_net_read_threshold_medium,
			pt.host_net_read_threshold_low,

			pt.host_net_write_threshold_critical,
			pt.host_net_write_threshold_high,
			pt.host_net_write_threshold_medium,
			pt.host_net_write_threshold_low,

			pt.host_disk_read_threshold_critical,
			pt.host_disk_read_threshold_high,
			pt.host_disk_read_threshold_medium,
			pt.host_disk_read_threshold_low,

			pt.host_disk_write_threshold_critical,
			pt.host_disk_write_threshold_high,
			pt.host_disk_write_threshold_medium,
			pt.host_disk_write_threshold_low,

			pt.host_load_avg_threshold_critical,
			pt.host_load_avg_threshold_high,
			pt.host_load_avg_threshold_medium,
			pt.host_load_avg_threshold_low,

			pt.host_runstate_blocked_threshold_critical,
			pt.host_runstate_blocked_threshold_high,
			pt.host_runstate_blocked_threshold_medium,
			pt.host_runstate_blocked_threshold_low,
			
			pt.host_runstate_partial_run_threshold_critical,
			pt.host_runstate_partial_run_threshold_high,
			pt.host_runstate_partial_run_threshold_medium,
			pt.host_runstate_partial_run_threshold_low,

			pt.host_runstate_fullrun_threshold_critical,
			pt.host_runstate_fullrun_threshold_high,
			pt.host_runstate_fullrun_threshold_medium,
			pt.host_runstate_fullrun_threshold_low,

			pt.host_runstate_partial_contention_threshold_critical,
			pt.host_runstate_partial_contention_threshold_high,
			pt.host_runstate_partial_contention_threshold_medium,
			pt.host_runstate_partial_contention_threshold_low,

			pt.host_runstate_concurrency_hazard_threshold_critical,
			pt.host_runstate_concurrency_hazard_threshold_high,
			pt.host_runstate_concurrency_hazard_threshold_medium,
			pt.host_runstate_concurrency_hazard_threshold_low,

			pt.host_runstate_full_contention_threshold_critical,
			pt.host_runstate_full_contention_threshold_high,
			pt.host_runstate_full_contention_threshold_medium,
			pt.host_runstate_full_contention_threshold_low,

			cast(pc13.value as int) as over_commit_cpu_ratio,
			
			case upper(pc2.value)
				when 'TRUE'  then 1
				when 'FALSE' then 0
				else 0
			end as over_commit_cpu_in_perf_mode,
			case upper(pc3.value)
				when 'TRUE'  then 1
				when 'FALSE' then 0
				else 0
			end as over_commit_cpu_in_density_mode,
			case upper(pc4.value)
				when 'TRUE'  then 1
				when 'FALSE' then 0
				else 0
			end as auto_balance_enabled,
			case upper(pc5.value)
				when 'TRUE'  then 1
				when 'FALSE' then 0
				else 0
			end as power_management_enabled,
			
			pc6.value as pool_master_cpu_limit,
			pc7.value as pool_master_net_io_limit,
			pc8.value as prefer_power_on_over_compression,
			pc9.value as power_on_host_if_no_memory,
			pc10.value as power_on_host_if_no_sr,
			pc11.value as compress_guests_to_relieve_pressure,
			pc12.value as compress_guests_to_preserve_power,

			pt.weight_current_metrics,
			pt.weight_last_30_metrics,
			pt.weight_yesterday_metrics,

			pt.vm_cpu_threshold_high,
			pt.vm_cpu_threshold_medium,
			pt.vm_cpu_threshold_low,
			pt.vm_cpu_weight_high,
			pt.vm_cpu_weight_medium,
			pt.vm_cpu_weight_low,

			pt.vm_memory_threshold_high,
			pt.vm_memory_threshold_medium,
			pt.vm_memory_threshold_low,
			pt.vm_memory_weight_high,
			pt.vm_memory_weight_medium,
			pt.vm_memory_weight_low,

			pt.vm_net_read_threshold_high,
			pt.vm_net_read_threshold_medium,
			pt.vm_net_read_threshold_low,
			pt.vm_net_read_weight_high,
			pt.vm_net_read_weight_medium,
			pt.vm_net_read_weight_low,

			pt.vm_net_write_threshold_high,
			pt.vm_net_write_threshold_medium,
			pt.vm_net_write_threshold_low,
			pt.vm_net_write_weight_high,
			pt.vm_net_write_weight_medium,
			pt.vm_net_write_weight_low,

			pt.vm_disk_read_threshold_high,
			pt.vm_disk_read_threshold_medium,
			pt.vm_disk_read_threshold_low,
			pt.vm_disk_read_weight_high,
			pt.vm_disk_read_weight_medium,
			pt.vm_disk_read_weight_low,

			pt.vm_disk_write_threshold_high,
			pt.vm_disk_write_threshold_medium,
			pt.vm_disk_write_threshold_low,
			pt.vm_disk_write_weight_high,
			pt.vm_disk_write_weight_medium,
			pt.vm_disk_write_weight_low,

			pt.vm_runstate_weight_high,
			pt.vm_runstate_weight_medium,
			pt.vm_runstate_weight_low

		from hv_pool_threshold pt
		join hv_pool_config pc1 on pc1.pool_id=pt.pool_id and pc1.name='OptimizationMode'
		join hv_pool_config pc2 on pc2.pool_id=pt.pool_id and pc2.name='OverCommitCpuInPerfMode'
		join hv_pool_config pc3 on pc3.pool_id=pt.pool_id and pc3.name='OverCommitCpuInDensityMode'
		join hv_pool_config pc4 on pc4.pool_id=pt.pool_id and pc4.name='AutoBalanceEnabled'
		join hv_pool_config pc5 on pc5.pool_id=pt.pool_id and pc5.name='PowerManagementEnabled'
		join hv_pool_config pc6 on pc6.pool_id=pt.pool_id and pc6.name='PoolMasterCpuLimit'
		join hv_pool_config pc7 on pc7.pool_id=pt.pool_id and pc7.name='PoolMasterNetIoLimit'
		left join hv_pool_config pc8 on pc8.pool_id=pt.pool_id and pc8.name='PreferPowerOnOverCompression'
		left join hv_pool_config pc9 on pc9.pool_id=pt.pool_id and pc9.name='PowerOnHostIfNoMemory'
		left join hv_pool_config pc10 on pc10.pool_id=pt.pool_id and pc10.name='PowerOnHostIfNoSR'		
		left join hv_pool_config pc11 on pc11.pool_id=pt.pool_id and pc11.name='CompressGuestsToRelievePressure'
		left join hv_pool_config pc12 on pc12.pool_id=pt.pool_id and pc12.name='CompressGuestsToPreservePower'
		left join hv_pool_config pc13 on pc13.pool_id=pt.pool_id and pc13.name='OverCommitCpuRatio'
	where pt.pool_id = _pool_id;
	return next cur2;
		
	open cur3 for 
		select ph.poolid,
	       ph.hostid,
	       h.name,
	       h.uuid,
	       h.poolid,
		   h.description,
	       h.num_cpus,
		   h.cpu_speed,
	       h.num_pifs,
		   h.is_pool_master,
		   h.enabled,
		   ph.fill_order,
		   h.ip_address,
		   h.status,
		   h.last_result,
		   h.last_result_time,
		  (	select total_mem 
			from host_metric hm 
			where hm.hostid = ph.hostid 
			order by hm.tstamp desc limit 1
		  ) as total_mem
	 from hv_pool_host ph
	 join hv_host h on ph.hostid=h.id
	 where ph.poolid = _pool_id
	 --order by ph.poolid
	order by h.name;
	return next cur3;

	open cur4 for
		select hv.hostid,
		   hv.vmid,
		   v.name,
           v.uuid,
           v.poolid,
		   v.description,
		   v.min_dynamic_memory,
		   v.max_dynamic_memory,
		   v.min_static_memory,
		   v.max_static_memory,
		   v.target_memory,
		   v.memory_overhead,
		   fn_required_memory(v.id) as required_memory,
		   v.min_cpus,
		   v.hv_memory_multiplier,
           v.is_control_domain,
           v.is_agile,
           v.drivers_up_to_date,
		   v.status,
		   v.last_result,
		   v.last_result_time
		from host_vm hv
		join virtual_machine v on v.id=hv.vmid
		join hv_pool_host ph on ph.hostid=hv.hostid
		where ph.poolid = _pool_id and
		  v.active=TRUE
		--order by hv.hostid
		order by v.name;
	return next cur4;
	return;
end; $$
language plpgsql;

/*
begin;
select * from load_hv_pool(2);
fetch all in "<unnamed portal 18>";
commit;
*/


-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Retrieve the configuration and threshold data for all hypervisor pools
--	 plus the list of physical hosts that are in the pool.
-- Parameters:
--   None
-- Returns:
--   Two result sets:
--     Result set 1 contains the basic pool configuration plus the thresholds
--     and weights for the pool.
--     Result set 2 contains the list of hosts in the pool.
--     Result set 3 contains the list of VMs in the pool.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_hv_pools();

CREATE FUNCTION "WorkloadBalancing".load_hv_pools
(
) RETURNS SETOF refcursor AS $$

DECLARE 
	ref_config_thresholds 	refcursor;
	ref_list_hosts 	 	refcursor;
	ref_list_vms		refcursor;    
BEGIN
	OPEN ref_config_thresholds FOR
		select	p.id,
			p.name,
			p.uuid,
			p.description,
			p.hv_type,
			p.enabled,
			p.is_licensed,
			p.pool_master_1_addr,
			p.pool_master_2_addr,
			p.pool_master_1_port,
			p.pool_master_2_port,
			p.protocol,
			p.username,
			p.password,
			case pc1.value
				when '0'  then 0
				when '1'  then 1
				else 0
			end as opt_mode,
			p.touched_by,
			p.tstamp,
			p.status,
			p.last_result,
			p.last_result_time,
			p.discovery_status,
			p.last_discovery_completed,

			t.host_cpu_threshold_critical,
			t.host_cpu_threshold_high,
			t.host_cpu_threshold_medium,
			t.host_cpu_threshold_low,

			t.host_memory_threshold_critical,
			t.host_memory_threshold_high,
			t.host_memory_threshold_medium,
			t.host_memory_threshold_low,

			t.host_net_read_threshold_critical,
			t.host_net_read_threshold_high,
			t.host_net_read_threshold_medium,
			t.host_net_read_threshold_low,

			t.host_net_write_threshold_critical,
			t.host_net_write_threshold_high,
			t.host_net_write_threshold_medium,
			t.host_net_write_threshold_low,

			t.host_disk_read_threshold_critical,
			t.host_disk_read_threshold_high,
			t.host_disk_read_threshold_medium,
			t.host_disk_read_threshold_low,

			t.host_disk_write_threshold_critical,
			t.host_disk_write_threshold_high,
			t.host_disk_write_threshold_medium,
			t.host_disk_write_threshold_low,

			t.host_load_avg_threshold_critical,
			t.host_load_avg_threshold_high,
			t.host_load_avg_threshold_medium,
			t.host_load_avg_threshold_low,

			cast(pc6.value as int) as over_commit_cpu_ratio,
			
			case upper(pc2.value)
				when 'TRUE'  then 1
				when 'FALSE' then 0
				else 0
			end as over_commit_cpu_in_perf_mode,
			case upper(pc3.value)
				when 'TRUE'  then 1
				when 'FALSE' then 0
				else 0
			end as over_commit_cpu_in_density_mode,
			case upper(pc4.value)
				when 'TRUE'  then 1
				when 'FALSE' then 0
				else 0
			end as auto_balance_enabled,
			case upper(pc5.value)
				when 'TRUE'  then 1
				when 'FALSE' then 0
				else 0
			end as power_management_enabled,			

			t.weight_current_metrics,
			t.weight_last_30_metrics,
			t.weight_yesterday_metrics,

			t.vm_cpu_threshold_high,
			t.vm_cpu_threshold_medium,
			t.vm_cpu_threshold_low,
			t.vm_cpu_weight_high,
			t.vm_cpu_weight_medium,
			t.vm_cpu_weight_low,

			t.vm_memory_threshold_high,
			t.vm_memory_threshold_medium,
			t.vm_memory_threshold_low,
			t.vm_memory_weight_high,
			t.vm_memory_weight_medium,
			t.vm_memory_weight_low,

			t.vm_net_read_threshold_high,
			t.vm_net_read_threshold_medium,
			t.vm_net_read_threshold_low,
			t.vm_net_read_weight_high,
			t.vm_net_read_weight_medium,
			t.vm_net_read_weight_low,

			t.vm_net_write_threshold_high,
			t.vm_net_write_threshold_medium,
			t.vm_net_write_threshold_low,
			t.vm_net_write_weight_high,
			t.vm_net_write_weight_medium,
			t.vm_net_write_weight_low,

			t.vm_disk_read_threshold_high,
			t.vm_disk_read_threshold_medium,
			t.vm_disk_read_threshold_low,
			t.vm_disk_read_weight_high,
			t.vm_disk_read_weight_medium,
			t.vm_disk_read_weight_low,

			t.vm_disk_write_threshold_high,
			t.vm_disk_write_threshold_medium,
			t.vm_disk_write_threshold_low,
			t.vm_disk_write_weight_high,
			t.vm_disk_write_weight_medium,
			t.vm_disk_write_weight_low

		from hv_pool p
			left outer join hv_pool_threshold t on p.id=t.pool_id
			left outer join hv_pool_config pc1 on pc1.pool_id=p.id and pc1.name='OptimizationMode'
			left outer join hv_pool_config pc2 on pc2.pool_id=p.id and pc2.name='OverCommitCpuInPerfMode'
			left outer join hv_pool_config pc3 on pc3.pool_id=p.id and pc3.name='OverCommitCpuInDensityMode'
			left outer join hv_pool_config pc4 on pc4.pool_id=p.id and pc4.name='AutoBalanceEnabled'
			left outer join hv_pool_config pc5 on pc5.pool_id=p.id and pc5.name='PowerManagementEnabled'	
			left outer join hv_pool_config pc6 on pc6.pool_id=p.id and pc6.name='OverCommitCpuRatio'
		order by p.name;
	RETURN NEXT ref_config_thresholds;

	OPEN ref_list_hosts FOR
		select 	ph.poolid,
			ph.hostid,
			h.name,
			h.uuid,
			h.poolid,
			h.description,
			h.num_cpus,
			h.cpu_speed,
			h.num_pifs,
			h.is_pool_master,
			h.enabled,
			ph.fill_order,
			h.ip_address,
			h.status,
			h.last_result,
			h.last_result_time ,
			(select total_mem 
			 from host_metric hm 
			 where hm.hostid = ph.hostid 
			 order by hm.tstamp desc
			 limit 1) as total_mem 
		 from hv_pool_host ph
			join hv_host h on ph.hostid=h.id
		 order by h.name;
	RETURN next ref_list_hosts;

	OPEN ref_list_vms FOR
		select 	ph.poolid,
			hv.hostid,
			hv.vmid,
			v.name,
			v.uuid,
			v.poolid,
			v.description,
			v.min_dynamic_memory,
			v.max_dynamic_memory,
			v.min_static_memory,
			v.max_static_memory,
			v.target_memory,
			v.memory_overhead,
			(select "WorkloadBalancing".fn_required_memory(v.id)) as required_memory,
			v.min_cpus,
			v.hv_memory_multiplier,
			v.is_control_domain,
			v.is_agile,
			v.drivers_up_to_date,
			v.status,
			v.last_result,
			v.last_result_time
		from host_vm hv
			join virtual_machine v on v.id=hv.vmid
			join hv_pool_host ph on ph.hostid=hv.hostid
		where  v.active=true
		order by v.name;
	RETURN next ref_list_vms;

	RETURN;
END;

$$ LANGUAGE plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		Sept 11, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 18, 2010	
-- Description:
--	 Retrieve the configuration of the specified virtual machine.
-- Parameters:
--   vm_id	- the database ID (id column of the virtual_machine table) of the
--            VM to load.
-- Returns:
--   Three result sets
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_vm_by_id
(
	_vm_id int
);

create function "WorkloadBalancing".load_vm_by_id
(
	_vm_id int
) returns setof refcursor as $$

declare 
	_pool_id int;
	cur1 refcursor;
	cur2 refcursor;
	cur3 refcursor;
begin
	open cur1 for
		select hv.hostid,
		   v.id,
		   v.name,
           v.uuid,
           v.poolid,
		   v.description,
		   v.min_dynamic_memory,
		   v.max_dynamic_memory,
		   v.min_static_memory,
		   v.max_static_memory,
		   v.target_memory,
		   v.memory_overhead,
		   v.min_cpus,
		   v.hv_memory_multiplier,
		   fn_required_memory(v.id) as required_memory,
           v.is_control_domain,
           v.is_agile,
           v.drivers_up_to_date,
		   v.host_affinity,
		   v.active,
		   v.status,
		   v.last_result,
		   v.last_result_time
	from virtual_machine v
	left outer join host_vm hv on hv.vmid=v.id
	where v.id = _vm_id;
	return next cur1;

	select into _pool_id poolid from virtual_machine where id=_vm_id;
	
	open cur2 for
		select p.id                   as pool_id,
		   p.uuid                 as pool_uuid,
		   p.name                 as pool_name,
		   cast (pc.value as int) as pool_opt_mode,
		   p.hv_type              as pool_type
	from hv_pool p
	join hv_pool_config pc on p.id=pc.pool_id and pc.name='OptimizationMode'
	where p.id=_pool_id;
	return next cur2;

	open cur3 for
		select vsr.vm_id,
		   vsr.sr_id,
		   sr.name,
           sr.uuid,
           sr.size,
		   sr.used,
		   sr.poolid,
		   sr.pool_default_sr
	from vm_storage_repository vsr
	join storage_repository sr on sr.id=vsr.sr_id
	join virtual_machine v on v.id=vsr.vm_id
	where v.id = _vm_id
	order by vsr.vm_id;
	return next cur3;
end;
$$ language plpgsql;

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Create date: 		July 21, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:	
--	 Retrieve all the VMs know to a pool.
-- Parameters:
--	 pool_id - The database ID (id column of the hv_pool table) of the pool
--             whose VMs are to be retrieved.
-- Returns:
--   All VM known to the specified pool.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_vms_by_pool_id
(
	_pool_id int
);

create function "WorkloadBalancing".load_vms_by_pool_id
(
	_pool_id int
) returns setof vms_info as $$
	declare r vms_info%rowtype;
begin
	for r in select	v.id,
			v.name,
			v.uuid,
			v.poolid,
			v.description,
			v.host_affinity, 
			v.min_dynamic_memory, 
			v.max_dynamic_memory, 
			v.min_static_memory, 
			v.max_static_memory,
			v.target_memory,
			v.memory_overhead,
			v.min_cpus, 
			v.hv_memory_multiplier,
			(select fn_required_memory(v.id)) as required_memory,
			v.is_control_domain,
			v.is_agile,
			v.drivers_up_to_date,
			h.id as hostid,
			h.name as hostname,
			h.uuid as host_uuid,
			v.active,
		    v.status,
		    v.last_result,
		    v.last_result_time
		from virtual_machine v
		left outer join host_vm hv on hv.vmid = v.id
		left outer join hv_host h on h.id=hv.hostid
		where v.poolid= _pool_id
		order by v.name loop
		return next r;
		end loop;
	return;
end;

$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Rabin Karki
-- On:			Nov 2, 2010
-- Description:
--	 Remove a numeric suffix (underscore (_) followed by one of more digits)
--   from the input string.
-- Parameters:
--   to_trim  - string from which a numeric suffix will be removed.
-- Returns:
--   The input string without a numeric suffix.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".trim_numeric_suffix
( 
	_to_trim   varchar(256)
);

create function "WorkloadBalancing".trim_numeric_suffix
( 
	_to_trim   varchar(256)
) returns varchar(256) as $$

declare 
	_trimmed 	varchar(256);
	_temp_trim      varchar(256);	
	_suffix_position       int;
	_last_suffix_position  int;

begin
	_last_suffix_position := 0;
	_suffix_position := 1;
	_temp_trim = _to_trim;

	loop
		if _suffix_position <= 0 then
			exit;
		end if;
	
		-- Try to find an underscore.
		_suffix_position := position('_' in _temp_trim);

		
		if (_suffix_position != 0) then
			-- Found an underscore.  Prepare to find the next underscore.
			_last_suffix_position := (_last_suffix_position + _suffix_position);
			_temp_trim := substring(_temp_trim from (_suffix_position + 1));
		else
			-- Didn't find an underscore.  The suffix starts at the
			-- previous underscore position.
			_suffix_position := _last_suffix_position;
			exit;
		end if;
	end loop;


	-- If we found an underscore ...
	if _suffix_position > 0 then

		_temp_trim = substring(_to_trim from _suffix_position + 1);
		if isnumeric(_temp_trim) then
			_trimmed := substring(_to_trim from 0 for (_suffix_position));
		else
			_trimmed := _to_trim;
		end if;
	else
		_trimmed := _to_trim;
	end if;
		

	return _trimmed;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			Sept 16, 2008
-- Modified for Postgresql: 	Rabin Karki
-- On:				Nov 17, 2010
-- Description:
--	 Add a record to the move_recommendation_detail table and to the 
--   move_recommendation table it event_id is zero.
-- Parameters:
--   event_id      - If non-zero, the identifier that groups related move  
--				     recommendation records. If zero, the event_id will be
--                   generated.
--	 event_type    - Describes the type of move recommendation record to write.
--   vm_id		   - The database ID (id column of the virtual_machine table)
--                   of the VM for which the move recommendation applies.
--   from_host_id  - The database ID (id column of the host table) of the host 
--                   from which the VM should move.
--   to_host_id    - The database ID (id column of the host table) of the host 
--                   to which the VM should move or on which the VM should be
--					 started.
--   severity      - Describes the severity of the move recommendation .  Used 
--                   for pool optimization recommendations.
--   reason        - Describes the reason of the move recommendation.  Used for
--				 	 pool optimization recommendations.
--   start_time	   - The UTC date and time the move was recommendated.
--   origonal_time - The UTC date and time the move recommendation was 
--                   origonally found.
--   last_alert_time - The UTC date and time a message was last sent to the
--                   pool master notifying it of this recommendation.
-- Returns:
--   The database ID (id column of the move_recommendation_detail table) of the
--	 new move recommendation detail and the database ID (id column of the 
--   move_recommendation table) of the detail's parent record.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".move_recommendation_add
(
	_event_id	int,
	_event_type	int,
	_vm_id		int,
	_from_host_id	int,
	_to_host_id	int,
	_severity	int,
	_reason		int,
	_start_time	timestamp,
	_origonal_time	timestamp,
	_last_alert_time timestamp
);

create function move_recommendation_add
(
	_event_id		 int,
	_event_type		 int,
	_vm_id			 int,
	_from_host_id	 	 int,
	_to_host_id		 int,
	_severity		 int,
	_reason			 int,
	_start_time		 timestamp,
	_origonal_time	 timestamp default null,
	_last_alert_time timestamp default null
) returns setof bigint_tuple as $$

declare 
	_pool_id int;
	_detail_id bigint;
	r bigint_tuple%rowtype;

begin
	if _event_id = 0 then
		if _vm_id is not null then
			select into _pool_id poolid from virtual_machine where id = _vm_id;
		
		elsif _from_host_id is not null then
			select into _pool_id poolid from hv_host where id = _from_host_id;
		elsif _to_host_id is not null then
			select into _pool_id poolid from hv_host where id = _to_host_id;
		end if;

		insert into move_recommendation (poolid,
				type,
				severity,
				tstamp,
				origonal_tstamp,
				last_alert_tstamp)
			values (_pool_id,
			 	_event_type,
				_severity,
				_start_time,
				_origonal_time,
				_last_alert_time) returning id into _event_id;			
	end if;


	insert into move_recommendation_detail (recommendation_id,
				vm_id,
				from_host_id,
				to_host_id,
				reason,
				tstamp)
			values (_event_id,
				_vm_id,
				_from_host_id,
				_to_host_id,
				_reason,
				_start_time) returning id into _detail_id;

	for r in select _detail_id, _event_id loop
	return next r;
	end loop;
	return;
end;
$$ language plpgsql;



-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		January 6, 2009
-- Description:
--	 Retrieve the last optimization recommendation for the specified pool.
-- Parameters:
--   pool_id      - The database ID (id column of the hv_pool table) of the
--                  pool whose last optimization is to be retrieved.
-- Returns:
--   Two data sets.
--      Data set one contains the ID of the last set of optimization 
--      recommendations and the time of the set of optimizations was
--      origonally recommended.
--      Data set two contains the details of the last set of optimization 
--      recommendations.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".move_recommendation_get_last
(
	_pool_id		int
);

CREATE FUNCTION "WorkloadBalancing".move_recommendation_get_last
(
	_pool_id		int
)
RETURNS SETOF refcursor AS $$
	
	declare _rec_id            			int;
	declare _original_tstamp   			timestamp;
	declare _last_alert_tstamp 			timestamp;
	declare _ref_time_stamp 			refcursor;
	declare _ref_move_recommendation_detail 	refcursor;

BEGIN
	select into _rec_id max(id) 
		from move_recommendation
		where poolid = _pool_id
		group by poolid;
	
	open _ref_time_stamp for
		select	id as rec_id,
			origonal_tstamp as original_tstamp,
			last_alert_tstamp as last_alert_tstamp
		from move_recommendation
		where id = _rec_id;
	return next _ref_time_stamp;
	
	open _ref_move_recommendation_detail for
		select vm_id,
			   from_host_id,
			   to_host_id,
			   reason
		  from move_recommendation_detail 
		 where recommendation_id = _rec_id
		 order by vm_id;
	return next _ref_move_recommendation_detail;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		Sept 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 22, 2010	
-- Description:
--	 Update the status of the specified optimization recommendation detail record.
-- Parameters:
--   recommendation_id  - The database ID (id column of the move_recommendation_detail
--						  table) of the optimization recommendation to update.
--	 status             - The new status for the record.
--                         0 = None,
--                         1 = AutomaticallyApplied,
--                         2 = AutomaticalApplicationFailed,
--                         3 = WouldApplyIfAutobalanceEnabled,
--                         4 = WouldApplyIfPowerManagementEnabled
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".move_recommendation_update_status
(
	_recommendation_id	int,
	_status			int
);

create function "WorkloadBalancing".move_recommendation_update_status
(
	_recommendation_id	int,
	_status			int
) returns void as $$
begin
	update move_recommendation_detail set status=_status
	 where id=_recommendation_id;
end;
$$ language plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:	Find all the physical hosts on which the specified virtual
--				machine can run.
-- Parameters:
--     host_id - The database ID (id column of the hv_host table) of the host
--               whose VM need new physical hosts.
-- Returns:
--   If successful, six result set containing information about the possible
--   hosts and the number of host on which the VM can run.
--		Result set 1. Information about the pool to which the specified host belongs.
--		Result set 2. Thresholds and weights for the pool.
--		Result set 3. Basic info about the host from which the VMs will be migrated.
--		Result set 4. Metrics for the possible hosts.	
--		Result set 5. Storage repositories attached to each host.
--      Result set 6. Physical interfaces attached to each host.
--		Result set 7. Metrics for the VMs.	
--		Result set 8. Storage repositories required by each VM.
--		Result set 9. Virtual interfaces required by each VM.
--
--   If unsuccessful, an error code that is less than zero.
--      -1 Parameters not specified.
--	-2 VM not found
--  -3 Don't have current metrics
--  -4 The pool does not have a paid for license.
--	-5 host to evacuate is excluded
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".place_host_by_id
(
	_host_id	int
);

CREATE FUNCTION "WorkloadBalancing".place_host_by_id
(
	_host_id	int
)
RETURNS SETOF refcursor AS $$

DECLARE 
	_ref_pool_info 				refcursor;
	_ref_pool_thresholds_weight refcursor;
	_ref_from_host				refcursor;    
	_ref_all_hosts_metrics 		refcursor;
	_ref_host_storage 			refcursor;
	_ref_host_pif				refcursor;    
	_ref_vm_metrics	 			refcursor;
	_ref_vm_storage 	 		refcursor;
	_ref_vm_vif					refcursor;    
	_id							int;
	_err						int;
	_uuid						varchar(48);
	_vm_name					varchar(256);
	_pool_id 					int;
	_opt_mode		        	int;
	_over_commit_cpu 			int;
	_MODE_MAX_DENSITY     		int := 1;

BEGIN
	-- Error Checking
	-- Initialize the error value
	_err := 0;
    
	-- Validate parameters
	if (_host_id is null or _host_id <= 0) 
	then
	    _id := 0;
	    _err := -1;
	    --return _err;
	end if;
	
	-- If error code is set from any of the following code, don't execude any other code, just skip to the part
	-- which returns the error code. 
	
	if (_err = 0)
	then
		-- Validate the Host exists
		if not exists (select id from hv_host where id = _host_id)
		then
			_id := 0;
			_err := -2;
			--return _err;
		end if;
	end if;
	
	if (_err = 0)
	then
		-- Validate the host is not explicitly designated to not participate in WLB		
		if ("WorkloadBalancing".fn_get_host_config_value(_host_id, 'ExcludeFromEvacuationRecommendations', 'false')::boolean = true)
		then
				_id := 0;
				_err := -5;
				--return _err; 
		end if;
	end if;
	
	
	if (_err = 0)
	then
		-- We need some details about the VM and the Pool for a bunch of the queries
		_pool_id := (select poolid from hv_host where id = _host_id);

		-- Make sure we have current metrics for all hosts in the pool.
		if exists(  select  h.id as hostid,
					hm.tstamp
						from hv_host h  
						join hv_pool_host hph on (h.id = hph.hostid)
						left join (select hm.hostid, max(tstamp) as tstamp
								   from host_metric hm 
								   join hv_pool_host hph on (hm.hostid = hph.hostid)
								   where hph.poolid = _pool_id 
						and hm.tstamp > "WorkloadBalancing".datetimeadd("WorkloadBalancing".getutcdate(), '-90 second')
								   group by hm.hostid) hm on (h.id = hm.hostid)
						where hph.poolid = _pool_id 
							  and h.power_state = 1 
							  and h.enabled = true 
							  and hm.tstamp is null)
		then
			-- Don't have current metrics
			_err := -3;
			--return _err;
		end if;
	end if;

	if _err < 0 then
		open _ref_pool_info for
			select  _err;
		return next _ref_pool_info;
	else		

		-- Get the opt mode for the pool
		_opt_mode := (select cast(value as int) from hv_pool_config where pool_id = _pool_id and name = 'OptimizationMode');

		-- Get over commit cpu
		case _opt_mode
			when _MODE_MAX_DENSITY then 
			    _over_commit_cpu := (select (case lower(value)
								when 'true' then 1
								else 0 
							 end)
						 from hv_pool_config where pool_id = _pool_id and name = 'OverCommitCpuInDensityMode');
			else 
			    _over_commit_cpu := (select (case lower(value)
								when 'true' then 1
								else 0 
							 end) 
						 from hv_pool_config where pool_id = _pool_id and name = 'OverCommitCpuInPerfMode');
		end case;


		--RESULT SET #1: Pool Information
		open _ref_pool_info for
			select  p.id,
				p.uuid,
				p.name,
				p.hv_type,
				_opt_mode as opt_mode,
				p.max_cpu_rating,
				is_licensed
			from hv_pool p 
			where p.id = _pool_id;
		return next _ref_pool_info;


		-- RESULT SET #2: Pool Thresholds and Weights
		open _ref_pool_thresholds_weight  for
			select "WorkloadBalancing".load_hv_pool_threshold_by_ids(array[_pool_id]);
		return next _ref_pool_thresholds_weight;


		-- RESULT SET #3. Basic info about the host from which the VMs will
		--                be migrated.
		open _ref_from_host for
			select  id,
				uuid, 
				name,
				poolid
			from hv_host 
			where id = _host_id;
		return next _ref_from_host;


		-- RESULT SET #4: All Hosts in Pool
		open _ref_all_hosts_metrics for
			select	h.id,
				h.uuid, 
				h.name,
				h.poolid,
				h.num_cpus,
				h.cpu_speed,
				hfc.free_cpus,
				coalesce(cv.potential_free_mem, hfm.free_mem) as potential_free_memory,  -- return the current free memory for non-MR hosts
				h.num_pifs,
				h.is_pool_master,					
				h.power_state,
				"WorkloadBalancing".fn_get_host_config_value(h.id, 'ParticipatesInPowerManagement', 'false') as can_power,
				"WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPlacementRecommendations', 'false') as exclude_placements,
				"WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromEvacuationRecommendations', 'false') as exclude_evacuations,
				ph.fill_order,
				mn.avg_total_mem as total_mem,
				hfm.free_mem    as free_mem,
				mn.avg_free_mem as avg_free_mem_now, 
				mn.avg_cpu      as avg_cpu_now,
				mn.avg_read	as avg_pif_read_now,
				mn.avg_write	as avg_pif_write_now,
				mn.avg_load	as avg_load_average,
				m30.avg_free_mem as avg_free_mem_30, 
				m30.avg_cpu	as avg_cpu_30,
				m30.avg_read	as avg_pif_read_30,
				m30.avg_write	as avg_pif_write_30,
				m30.avg_load	as avg_load_average_30,
				my.avg_free_mem	as avg_free_mem_yesterday, 
				my.avg_cpu	as avg_cpu_yesterday,
				my.avg_read	as avg_pif_read_yesterday,
				my.avg_write	as avg_pif_write_yesterday,
				my.avg_load	as avg_load_average_yesterday
			from hv_host h 
				join hv_pool_host ph on h.id = ph.hostid
				join "WorkloadBalancing".fn_get_avg_host_metrics_now(array[_pool_id]) mn on h.id = mn.hostid
				join "WorkloadBalancing".fn_get_host_free_cpus(array[_pool_id]) hfc on h.id = hfc.hostid
				left join "WorkloadBalancing".fn_get_host_free_memory(array[_pool_id]) hfm on h.id = hfm.hostid
				left join "WorkloadBalancing".fn_get_host_potential_free_memory_dmc() cv on cv.hostid = h.id and cv.poolid = _pool_id
				left join "WorkloadBalancing".fn_get_avg_host_metrics_30_min(array[_pool_id]) m30 on h.id = m30.hostid
				left join "WorkloadBalancing".fn_get_avg_host_metrics_yesterday(array[_pool_id]) my on h.id = my.hostid 
			where h.id != _host_id;
		return next _ref_all_hosts_metrics;


		-- RESULT SET #5: The storage repositories on each host.
		open _ref_host_storage for
			select	hsr.host_id   as host_id,
				sr.id             as sr_id,
				sr.uuid           as sr_uuid, 
				sr.name           as sr_name,
				sr.size           as sr_size,
				sr.used           as sr_used,
				sr.poolid         as poolid
			from hv_host_storage_repository hsr
				join storage_repository sr on sr.id=hsr.sr_id
				join hv_pool_host hph on hsr.host_id = hph.hostid
			where hph.poolid = _pool_id 
				and hsr.host_id != _host_id
			order by hsr.host_id;		
		return next _ref_host_storage;

		
		-- RESULT SET #6: The physical interfaces on each host.
		open _ref_host_pif for
			select	hp.hostid     as host_id,
				pif.id        as pif_id,
				pif.uuid      as pif_uuid, 
				pif.name      as pif_name,
				pif.networkid as networkid,
				pif.poolid,
				pif.is_management_interface
			from hv_host_pif hp
				join hv_pif pif on pif.id=hp.pif_id
				join hv_pool_host hph on hp.hostid = hph.hostid
			where hph.poolid = _pool_id 
				and hp.hostid != _host_id
			order by hp.hostid;
		return next _ref_host_pif;


		-- RESULT SET #7: Metrics for the VM we are trying to place.
		open _ref_vm_metrics for
			select	v.id,
				v.uuid, 
				v.name,
				v.poolid,
				v.min_cpus,
				v.min_dynamic_memory,
				v.max_dynamic_memory,
				v.min_static_memory,
				v.max_static_memory,
				v.target_memory,
				v.memory_overhead,
				"WorkloadBalancing".fn_required_memory(v.id) as required_memory,
				"WorkloadBalancing".fn_vm_total_memory(v.id) as total_memory,
				v.hv_memory_multiplier,
				v.is_agile,
				v.drivers_up_to_date,
				coalesce(mn.avg_total_mem,0) as have_current_vm_metrics,
				coalesce(m30.avg_total_mem,0) as have_last_30_vm_metrics,
				coalesce(my.avg_total_mem,0) as have_yesterday_vm_metrics,
				mn.avg_total_mem  as avg_total_mem_now, 
				mn.avg_free_mem  as avg_free_mem_now,
				mn.avg_target_mem  as avg_target_mem_now,
				mn.avg_used_mem	as avg_used_mem_now, 
				mn.avg_cpu as avg_cpu_now,
				mn.avg_net_read	 as avg_net_read_now,
				mn.avg_net_write as avg_net_write_now,
				mn.avg_block_read as avg_block_read_now,
				mn.avg_block_write as avg_block_write_now,
				mn.total_vbd_net_read  as total_vbd_net_read,
				mn.total_vbd_net_write   as total_vbd_net_write,
				mn.avg_runstate_full_contention	 as avg_runstate_full_contention_now,
				mn.avg_runstate_concurrency_hazard as avg_runstate_concurrency_hazard_now,
				mn.avg_runstate_partial_contention as avg_runstate_partial_contention_now,
				mn.avg_runstate_fullrun	 as avg_runstate_fullrun_now,
				mn.avg_runstate_partial_run as avg_runstate_partial_run_now,
				mn.avg_runstate_blocked	 as avg_runstate_blocked_now,
				m30.avg_total_mem as avg_total_mem_30, 
				m30.avg_free_mem as avg_free_mem_30,
				m30.avg_target_mem as avg_target_mem_30,
				m30.avg_used_mem as avg_used_mem_30, 
				m30.avg_cpu as avg_cpu_30,
				m30.avg_net_read as avg_net_read_30,
				m30.avg_net_write as avg_net_write_30,
				m30.avg_block_read as avg_block_read_30,
				m30.avg_block_write as avg_block_write_30,
				m30.total_vbd_net_read as total_vbd_net_read_30,
				m30.total_vbd_net_write as total_vbd_net_write_30,			
				m30.avg_runstate_full_contention as avg_runstate_full_contention_30,
				m30.avg_runstate_concurrency_hazard as avg_runstate_concurrency_hazard_30,
				m30.avg_runstate_partial_contention as avg_runstate_partial_contention_30,
				m30.avg_runstate_fullrun as avg_runstate_fullrun_30,
				m30.avg_runstate_partial_run as avg_runstate_partial_run_30,
				m30.avg_runstate_blocked as avg_runstate_blocked_30,
				my.avg_total_mem as avg_total_mem_yesterday, 
				my.avg_free_mem as avg_free_mem_yesterday,
				my.avg_target_mem as avg_target_mem_yesterday,
				my.avg_used_mem	as avg_used_mem_yesterday, 
				my.avg_cpu as avg_cpu_yesterday,
				my.avg_net_read	 as avg_net_read_yesterday,
				my.avg_net_write as avg_net_write_yesterday,
				my.avg_block_read as avg_block_read_yesterday,
				my.avg_block_write as avg_block_write_yesterday,
				my.total_vbd_net_read as total_vbd_net_read_yesterday,
				my.total_vbd_net_write as total_vbd_net_write_yesterday
		    from virtual_machine v 
			join host_vm hv on (v.id = hv.vmid)
			left join "WorkloadBalancing".fn_get_avg_vm_metrics_now_by_host(_host_id) mn on v.id = mn.vm_id
			left join "WorkloadBalancing".fn_get_avg_vm_metrics_30_min_by_host(_host_id) m30 on v.id = m30.vm_id
			left join "WorkloadBalancing".fn_get_avg_vm_metrics_yesterday_by_host(_host_id) my on v.id = my.vm_id
		    where hv.hostid = _host_id 
			and v.is_control_domain = false;
		return next _ref_vm_metrics;


		-- RESULT SET #8:  The storage repositories required by each VM.
		open _ref_vm_storage for
			select  vmsr.vm_id, 
				vmsr.sr_id, 
				sr.uuid 
			from vm_storage_repository vmsr 
				join host_vm hv on (vmsr.vm_id = hv.vmid)
				join storage_repository sr on (sr.id = vmsr.sr_id)
			where hv.hostid = _host_id;
		return next _ref_vm_storage;
		
		-- RESULT SET #9:  The virtual network interfaces required by each VM.
		open _ref_vm_vif for
			select  vvf.vif_id, 
				vf.uuid,
				vf.poolid,
				vf.networkid ,
				vf.poolid
			from vm_vif vvf 
				join host_vm hv on (vvf.vm_id = hv.vmid)
				join vif vf on (vf.id=vvf.vif_id)
			where hv.hostid = _host_id;
		return next _ref_vm_vif;
	end if;
	RETURN;
END;

$$ LANGUAGE plpgsql;

/*
begin;
select place_host_by_id(178);
fetch all from "<unnamed portal 135>";
*/


-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:	Find all the physical hosts on which the specified virtual
--		machine can run.
-- Parameters:
--     vm_id	- The database ID (id column of the virtual_machine
--                table) of the VM to place
--     similar_vm_id - The database ID (id column of the virtual_machine	 
--                     table) of a VM that has similar performance
--                     characteristisc.
-- Returns:
--   If successful, eight result sets:
--      Result set 1.  The error code.  0=success.
--		Result set 2.  Information about the pool to which the VM to place belongs.
--		Result set 3.  Thresholds and weights for the pool.
--		Result set 4.  Metrics for all hosts in the vm's pool.
--		Result set 5.  Number of VMs running on each host.
--      Result set 6.  The storage repositories on each host.
--      Result set 7.  The physical interfaces on each host.
--		Result set 8.  Metrics for the VM we are trying to place.
--		Result set 9.  The storage repositories required by the VM.
--		Result set 10. The virtual network interfaces by the VM.
--	
--   If unsuccessful, an error code that is less than zero.
--      -1 Parameters not specified.
--		-2 VM not found
--      -6 We don't have current metrics.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".place_vm_by_id
(
	_vm_id		int,
	_similar_vm_id	int
);

CREATE FUNCTION "WorkloadBalancing".place_vm_by_id
(
	_vm_id		int,
	_similar_vm_id	int = null
)
RETURNS SETOF refcursor AS $$

DECLARE 
	_ref_errors			refcursor;
	_ref_pool_info 			refcursor;
	_ref_thresholds_weights	refcursor;
	_ref_host_metrics 		refcursor;
	_ref_num_vms 			refcursor;
	_ref_host_storage		refcursor;
	_ref_host_pif 			refcursor;
	_ref_vm_metrics			refcursor;
	_ref_vm_storage 		refcursor;
	_ref_vm_vif				refcursor;
	_id 					int;
    _err 					int;
    _uuid 					varchar(48);
    _vm_name 				varchar(256);
	_pool_id 				int;
	_opt_mode		        int;
	_over_commit_cpu 		int;
	_MODE_MAX_DENSITY     	int := 1;


BEGIN

	-- Initialize the error value
	_err := 0;
    
	-- Validate parameters
	if (_vm_id is null or _vm_id <= 0) 
	then
		_id := 0;
		_err := -1;

	-- Validate the VM exists
	elsif not exists (select id from virtual_machine where id = _vm_id) 
		then
			_id := 0;
			_err := -2;

	-- Check that we have recent host metrics
	else
		if not exists ( select tstamp
			from host_metric hm 
				join hv_pool_host ph  on ph.hostid = hm.hostid
				join virtual_machine vm  on ph.poolid = vm.poolid
			where vm.id = _vm_id 
				and hm.tstamp > "WorkloadBalancing".datetimeadd("WorkloadBalancing".getutcdate(), '-90 second'))
		then
			_err := -6;
			_id := _vm_id;
		end if;	
	end if;

	-- Base Data Collection
	-- We need some details about the VM and the Pool for a bunch of the queries
	_pool_id := (select poolid from virtual_machine where id = _vm_id);       

	-- RESULT SET #1: Error information
	-- Always return an error result set.  
	-- If there is no error (@err=0), then we will return 
	-- a little extra unused data, but should be a problem
	if (_id = 0) then
		open _ref_errors for
		    select  _err as err,
			    _id  as vm_id,
			    null as vm_uuid,
			    null as pool_id,
			    0    as auto_balanced_enabled,
			    0    as power_management_enabled;
		return next _ref_errors;
	else
		open _ref_errors for
		    select  _err as err,
			    _id as vm_id, 
			    uuid as vm_uuid,
			    poolid as pool_id,
			    "WorkloadBalancing".fn_get_pool_config_value(poolid, 'PowerManagementEnabled', 'false') as power_management_enabled,
			    "WorkloadBalancing".fn_get_pool_config_value(poolid, 'AutoBalanceEnabled', 'false') as auto_balanced_enabled
		    from virtual_machine 
		    where id = _vm_id;
		return next _ref_errors;
	end if;

	-- Only return the other result sets if there were no errors
	if (_err = 0 or _err = -6) then

		-- Get the opt mode for the pool
		_opt_mode := (select cast(value as int) from hv_pool_config where pool_id = _pool_id and name = 'OptimizationMode');

		-- Get over commit cpu
		case _opt_mode
			when _MODE_MAX_DENSITY then 
			    _over_commit_cpu := (select (case lower(value)
								when 'true' then 1
								else 0 
							end)
						 from hv_pool_config where pool_id = _pool_id and name = 'OverCommitCpuInDensityMode');
			else 
			    _over_commit_cpu := (select (case lower(value)
								when 'true' then 1
								else 0 
							end)
						 from hv_pool_config where pool_id = _pool_id and name = 'OverCommitCpuInPerfMode');
		end case;

		-- RESULT SET #2: Pool Information
		open _ref_pool_info for
			select  p.id,
				p.uuid,
				p.name,
				p.hv_type,
				_opt_mode as opt_mode,
				p.max_cpu_rating,
				is_licensed
			from hv_pool p 
			where p.id = _pool_id;
		return next _ref_pool_info;


		-- RESULT SET #3: Pool Thresholds and Weights
		open _ref_thresholds_weights for
			select *
			from load_hv_pool_threshold_by_ids(array[_pool_id]);
		return next _ref_thresholds_weights;

		-- RESULT SET #4: All Hosts in Pool
		open _ref_host_metrics for
			select	h.id,
				h.uuid, 
				h.name,
				h.poolid,
				h.num_cpus,
				h.cpu_speed,
				hfc.free_cpus,
				coalesce(cv.potential_free_mem, hfm.free_mem) as potential_free_memory,  
				h.num_pifs,
				h.is_pool_master,					
				h.power_state,
				"WorkloadBalancing".fn_get_host_config_value(h.id, 'ParticipatesInPowerManagement', 'false') as can_power,
				"WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPlacementRecommendations', 'false') as exclude_placements,
				"WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromEvacuationRecommendations', 'false') as exclude_evacuations,					                    
				ph.fill_order,
				mn.avg_total_mem as total_mem,
				hfm.free_mem     as free_mem,
				mn.avg_free_mem  as avg_free_mem_now, 
				mn.avg_cpu       as avg_cpu_now,
				mn.avg_read	 as avg_pif_read_now,
				mn.avg_write	 as avg_pif_write_now,
				mn.avg_load	 as avg_load_average,
				m30.avg_free_mem as avg_free_mem_30, 
				m30.avg_cpu	 as avg_cpu_30,
				m30.avg_read	 as avg_pif_read_30,
				m30.avg_write	 as avg_pif_write_30,
				m30.avg_load	 as avg_load_average_30,
				my.avg_free_mem	 as avg_free_mem_yesterday, 
				my.avg_cpu	 as avg_cpu_yesterday,
				my.avg_read	 as avg_pif_read_yesterday,
				my.avg_write	 as avg_pif_write_yesterday,
				my.avg_load	 as avg_load_average_yesterday,
				vrs.full_contention_count,
				vrs.concurrency_hazard_count,
				vrs.partial_contention_count,
				vrs.fullrun_count,
				vrs.partial_run_count,
				vrs.blocked_count
			from hv_host h 
				join hv_pool_host ph on h.id = ph.hostid
				join "WorkloadBalancing".fn_get_avg_host_metrics_now(array[_pool_id]) mn on h.id = mn.hostid
				join "WorkloadBalancing".fn_get_host_free_cpus(array[_pool_id]) hfc on h.id = hfc.hostid
				left join "WorkloadBalancing".fn_get_host_vm_runstate_counts(array[_pool_id]) vrs on h.id = vrs.hostid
				left join "WorkloadBalancing".fn_get_host_free_memory(array[_pool_id]) hfm on h.id = hfm.hostid
				left join "WorkloadBalancing".fn_get_host_potential_free_memory_dmc() cv on cv.hostid = h.id and cv.poolid = _pool_id  
				left join "WorkloadBalancing".fn_get_avg_host_metrics_30_min(array[_pool_id]) m30 on h.id = m30.hostid
				left join "WorkloadBalancing".fn_get_avg_host_metrics_yesterday(array[_pool_id]) my on h.id = my.hostid;
		return next _ref_host_metrics;
				

		-- RESULT SET #5: Number of VMs running on each host
		open _ref_num_vms  for 
			select  hv.hostid, 
				count(vmid) as num_vm 
			from host_vm hv 
				join hv_pool_host hph on (hv.hostid = hph.hostid)
			where hph.poolid = _pool_id
			group by hv.hostid;
		return next _ref_num_vms;

			
		-- RESULT SET #6: The storage repositories on each host.
		open _ref_host_storage	for
			select	hsr.host_id       as host_id,
				sr.id             as sr_id,
				sr.uuid           as sr_uuid, 
				sr.name           as sr_name,
				sr.size           as sr_size,
				sr.used           as sr_used,
				sr.poolid         as poolid
			from hv_host_storage_repository hsr
				join storage_repository sr on sr.id = hsr.sr_id
				join hv_pool_host hph on hsr.host_id = hph.hostid
			where hph.poolid = _pool_id
			order by hsr.host_id;
		return next _ref_host_storage;
		
			
		-- RESULT SET #7: The physical interfaces on each host.
		open _ref_host_pif  for
			select	hp.hostid     as host_id,
				pif.id        as pif_id,
				pif.uuid      as pif_uuid, 
				pif.name      as pif_name,
				pif.networkid as networkid,
				pif.poolid,
				pif.is_management_interface
			from hv_host_pif hp
				join hv_pif pif on pif.id = hp.pif_id
				join hv_pool_host hph on hp.hostid = hph.hostid
			where hph.poolid = _pool_id
			order by hp.hostid;
		return next _ref_host_pif;
		

		-- RESULT SET #8: Metrics for the VM we are trying to place.
		open _ref_vm_metrics for			
			select	v.id,
				v.uuid, 
				v.name,
				v.poolid,
				v.min_cpus,
				v.min_dynamic_memory,
				v.max_dynamic_memory,
				v.min_static_memory,
				v.max_static_memory,
				v.target_memory,
				v.memory_overhead,
				"WorkloadBalancing".fn_required_memory(v.id)    	as required_memory,
				"WorkloadBalancing".fn_vm_total_memory(v.id)    	as total_memory,
				v.hv_memory_multiplier,
				v.is_agile,
				v.drivers_up_to_date,
				coalesce(mn.avg_total_mem,0)		as have_current_vm_metrics,
				coalesce(m30.avg_total_mem,0)		as have_last_30_vm_metrics,
				coalesce(my.avg_total_mem,0)		as have_yesterday_vm_metrics,
				mn.avg_total_mem                	as avg_total_mem_now, 
				mn.avg_free_mem                 	as avg_free_mem_now,
				mn.avg_target_mem               	as avg_target_mem_now,
				mn.avg_used_mem				as avg_used_mem_now, 
				mn.avg_cpu				as avg_cpu_now,
				mn.avg_net_read				as avg_net_read_now,
				mn.avg_net_write			as avg_net_write_now,
				mn.avg_block_read			as avg_block_read_now,
				mn.avg_block_write			as avg_block_write_now,
				mn.total_vbd_net_read           	as total_vbd_net_read,
				mn.total_vbd_net_write              	as total_vbd_net_write,
				mn.avg_runstate_full_contention		as avg_runstate_full_contention_now,
				mn.avg_runstate_concurrency_hazard	as avg_runstate_concurrency_hazard_now,
				mn.avg_runstate_partial_contention	as avg_runstate_partial_contention_now,
				mn.avg_runstate_fullrun			as avg_runstate_fullrun_now,
				mn.avg_runstate_partial_run		as avg_runstate_partial_run_now,
				mn.avg_runstate_blocked			as avg_runstate_blocked_now,
				m30.avg_total_mem                   	as avg_total_mem_30, 
				m30.avg_free_mem                    	as avg_free_mem_30,
				m30.avg_target_mem                  	as avg_target_mem_30,
				m30.avg_used_mem			as avg_used_mem_30, 
				m30.avg_cpu				as avg_cpu_30,
				m30.avg_net_read			as avg_net_read_30,
				m30.avg_net_write			as avg_net_write_30,
				m30.avg_block_read			as avg_block_read_30,
				m30.avg_block_write			as avg_block_write_30,
				m30.total_vbd_net_read              	as total_vbd_net_read_30,
				m30.total_vbd_net_write             	as total_vbd_net_write_30,			
				m30.avg_runstate_full_contention	as avg_runstate_full_contention_30,
				m30.avg_runstate_concurrency_hazard	as avg_runstate_concurrency_hazard_30,
				m30.avg_runstate_partial_contention	as avg_runstate_partial_contention_30,
				m30.avg_runstate_fullrun		as avg_runstate_fullrun_30,
				m30.avg_runstate_partial_run		as avg_runstate_partial_run_30,
				m30.avg_runstate_blocked		as avg_runstate_blocked_30,
				my.avg_total_mem                    	as avg_total_mem_yesterday, 
				my.avg_free_mem                     	as avg_free_mem_yesterday,
				my.avg_target_mem                   	as avg_target_mem_yesterday,
				my.avg_used_mem				as avg_used_mem_yesterday, 
				my.avg_cpu				as avg_cpu_yesterday,
				my.avg_net_read				as avg_net_read_yesterday,
				my.avg_net_write			as avg_net_write_yesterday,
				my.avg_block_read			as avg_block_read_yesterday,
				my.avg_block_write			as avg_block_write_yesterday,
				my.total_vbd_net_read               	as total_vbd_net_read_yesterday,
				my.total_vbd_net_write              	as total_vbd_net_write_yesterday,
				my.avg_runstate_full_contention		as avg_runstate_full_contention_yesterday,
				my.avg_runstate_concurrency_hazard	as avg_runstate_concurrency_hazard_yesterday,
				my.avg_runstate_partial_contention	as avg_runstate_partial_contention_yesterday,
				my.avg_runstate_fullrun			as avg_runstate_fullrun_yesterday,
				my.avg_runstate_partial_run		as avg_runstate_partial_run_yesterday,
				my.avg_runstate_blocked			as avg_runstate_blocked_yesterday
			from virtual_machine v 
				left outer join "WorkloadBalancing".fn_get_avg_vm_metrics_now(_vm_id) mn  on v.id = mn.vm_id
				left outer join "WorkloadBalancing".fn_get_avg_vm_metrics_30_min(_vm_id) m30 on v.id = m30.vm_id
				left outer join "WorkloadBalancing".fn_get_avg_vm_metrics_yesterday(_vm_id) my on v.id = my.vm_id
			where v.id = _vm_id;
		return next _ref_vm_metrics;			
	

		-- RESULT SET #9:  The storage repositories required by the VM.
		open _ref_vm_storage for
			select vmsr.sr_id, sr.uuid 
			from vm_storage_repository vmsr 
				join storage_repository sr on sr.id = vmsr.sr_id 
			where vmsr.vm_id = _vm_id;
		return next _ref_vm_storage;
		

		-- RESULT SET #10:  The virtual network interfaces required by the VM.
		open _ref_vm_vif for
			select  vvf.vif_id, 
			    vf.uuid,
			    vf.poolid,
			    vf.networkid 
			from vm_vif vvf
				join vif vf on vf.id = vvf.vif_id 
			where vvf.vm_id =_vm_id;
		return next _ref_vm_vif;

	end if;
	return;

end;
$$ language plpgsql;

/*
begin;
select "WorkloadBalancing".place_vm_by_id(2147483647);
fetch all from "<unnamed portal 85>";
*/
-- ==========================================================================
-- (c) Copyright 2011 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Date:		December 12, 2011
--
-- Description:	Find all the physical hosts on which the specified virtual
--		machine can run.
-- Parameters:
--     _host_uuids	- A list of perferred host uuids for placing a vm
--     _pool_uuids	- A list of perferred pool uuids for placing a vm.
-- Returns:
--   If successful, eight result sets:
--      Result set 1.  The error code.  0=success.
--		Result set 2.  Information about the pool to which the VM to place belongs.
--		Result set 3.  Thresholds and weights for the pool.
--		Result set 4.  Metrics for all hosts in the vm's pool.
--		Result set 5.  Number of VMs running on each host.
--      Result set 6.  The storage repositories on each host.
--      Result set 7.  The physical interfaces on each host.
--	
--   If unsuccessful, an error code that is less than zero.
--      -1 Parameters not specified.
-- 	-2 Invalid pool/host uuids
--      -6 We don't have current metrics.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".place_vm_by_uuids
(
	_host_uuids		varchar[],
	_pool_uuids		varchar[],
	_shared_storage	boolean
);

CREATE FUNCTION "WorkloadBalancing".place_vm_by_uuids
(
	_host_uuids		varchar[],
	_pool_uuids		varchar[],
	_shared_storage	boolean
)
RETURNS SETOF refcursor AS $$

DECLARE 
	_ref_errors			refcursor;
	_ref_pool_info 			refcursor;
	_ref_thresholds_weights		refcursor;
	_ref_host_metrics 		refcursor;
	_ref_num_vms 			refcursor;
	_ref_host_storage		refcursor;
	_ref_host_pif 			refcursor;
	_ref_host_pbd			refcursor;

	_pool_ids 			int[];
	_host_ids			int[];
	_err 				int;
	_opt_mode		        int;
	_over_commit_cpu 		int;
	_MODE_MAX_DENSITY     		int := 1;


BEGIN

	-- Initialize the error value
	_err := 0;
    
	-- Validate parameters, _pool_uuid and _host_uuids cannot be null or empty at the same time
	if ((_pool_uuids is null or array_upper(_pool_uuids, 1) is null) and (_host_uuids is null or array_upper(_host_uuids, 1) is null)) 
		then 
			_err := -1;

	-- Validate pool uuids and host uuids
	elsif (array_upper(_host_uuids, 1)  > 0 and (select count(uuid)::int from hv_host where uuid = any(_host_uuids)) = 0 and (_pool_uuids is null or array_upper(_pool_uuids, 1) is null)) 
		then
			_err := -2;
			
	elsif (array_upper(_pool_uuids, 1) > 0 and (select count(uuid)::int from hv_pool where uuid = any(_pool_uuids)) = 0 and (_host_uuids is null or array_upper(_host_uuids, 1) is null)) 
		then 
			_err := -2;
	
	-- Check that we have recent host metrics
	else
		if not exists ( select hm.tstamp
				from host_metric hm 
					join hv_pool_host ph  on ph.hostid = hm.hostid
					left join hv_pool hp on ph.poolid = hp.id
					left join hv_host hh on ph.hostid = hh.id
				where ((array_upper(_host_uuids, 1)  > 0 and hh.uuid = any(_host_uuids)) 
						or 
					  (array_upper(_pool_uuids, 1) > 0 and hp.uuid = any(_pool_uuids)))
					and (hm.tstamp > "WorkloadBalancing".datetimeadd("WorkloadBalancing".getutcdate(), '-90 second')))
		then
			_err := -6;
		end if;	
	end if;

	-- RESULT SET #1: Error information
	-- Always return an error result set.  
	open _ref_errors for
		select  _err as err;
	return next _ref_errors;

	-- Only return the other result sets if there were no errors
	if (_err = 0 or _err = -6) then

		-- Get pool ids and host ids
		if array_upper(_host_uuids, 1) > 0 then
			_host_ids := array(select id::int from hv_host where uuid = any(_host_uuids));
			_pool_ids := array(select distinct hp.id::int 
					   from hv_host hh
						join hv_pool_host hph on hh.id = hph.hostid
						join hv_pool hp on hph.poolid = hp.id
					   where hh.uuid = any(_host_uuids));	
					   
		elsif array_upper(_pool_uuids, 1) > 0 then
			_pool_ids := array(select id::int from hv_pool where uuid = any(_pool_uuids));
					   
		end if;
		
		
		-- RESULT SET #2: Pool Information
		open _ref_pool_info for
			select  distinct p.id,
					p.uuid,
					p.name,
					p.hv_type,
					(select cast(value as int) from hv_pool_config where pool_id = p.id and name = 'OptimizationMode') as opt_mode,
					p.max_cpu_rating,
					is_licensed,
					(case when (1 = 0)
						then (select (case lower(value) when 'true' then 1 else 0 end)
							  from hv_pool_config 
							  where pool_id = p.id and name = 'OverCommitCpuInDensityMode')
						else (select (case lower(value) when 'true' then 1	else 0 end)
							  from hv_pool_config 
							  where pool_id = p.id and name = 'OverCommitCpuInPerfMode')
						end) as over_commit_cpu
				from hv_pool p 
					 join hv_pool_config hpc on p.id = hpc.pool_id
				where p.id = any(_pool_ids);
		return next _ref_pool_info;


		-- RESULT SET #3: Pool Thresholds and Weights
		open _ref_thresholds_weights for
			select *
			from load_hv_pool_threshold_by_ids(_pool_ids);
		return next _ref_thresholds_weights;


		-- RESULT SET #4: Hosts' metrics
		open _ref_host_metrics for
			select	h.id,
				h.uuid, 
				h.name,
				h.poolid,
				h.num_cpus,
				hfc.vcpus as num_vcpus,
				h.cpu_speed,
				hfc.free_cpus,
				coalesce(cv.potential_free_mem, hfm.free_mem) as potential_free_memory,  
				h.num_pifs,
				h.is_pool_master,					
				h.power_state,
				"WorkloadBalancing".fn_get_host_config_value(h.id, 'ParticipatesInPowerManagement', 'false') as can_power,
				"WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPlacementRecommendations', 'false') as exclude_placements,
				"WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromEvacuationRecommendations', 'false') as exclude_evacuations,					                    
				ph.fill_order,
				mn.avg_total_mem as total_mem,
				hfm.free_mem     as free_mem,
				mn.avg_free_mem  as avg_free_mem_now, 
				mn.avg_cpu       as avg_cpu_now,
				mn.avg_read	 as avg_pif_read_now,
				mn.avg_write	 as avg_pif_write_now,
				mn.avg_load	 as avg_load_average,
				m30.avg_free_mem as avg_free_mem_30, 
				m30.avg_cpu	 as avg_cpu_30,
				m30.avg_read	 as avg_pif_read_30,
				m30.avg_write	 as avg_pif_write_30,
				m30.avg_load	 as avg_load_average_30,
				my.avg_free_mem	 as avg_free_mem_yesterday, 
				my.avg_cpu	 as avg_cpu_yesterday,
				my.avg_read	 as avg_pif_read_yesterday,
				my.avg_write	 as avg_pif_write_yesterday,
				my.avg_load	 as avg_load_average_yesterday,
				pbdmn.avg_disk_io_read as avg_pbd_read_now,
				pbdmn.avg_disk_io_write as avg_pbd_write_now,
				pbdm30.avg_disk_io_read as avg_pbd_read_30,
				pbdm30.avg_disk_io_write as avg_pbd_write_30,
				pbdmy.avg_disk_io_read as avg_pbd_read_yesterday,
				pbdmy.avg_disk_io_write as avg_pbd_write_yesterday,
				vrs.full_contention_count,
				vrs.concurrency_hazard_count,
				vrs.partial_contention_count,
				vrs.fullrun_count,
				vrs.partial_run_count,
				vrs.blocked_count
			from hv_host h 
				join hv_pool_host ph on h.id = ph.hostid and h.poolid = ph.poolid
				join "WorkloadBalancing".fn_get_avg_host_metrics_now(_pool_ids) mn on h.id = mn.hostid and h.poolid = mn.poolid
				join "WorkloadBalancing".fn_get_host_free_cpus(_pool_ids) hfc on h.id = hfc.hostid and h.poolid = hfc.poolid
				left join "WorkloadBalancing".fn_get_host_vm_runstate_counts(_pool_ids) vrs on h.id = vrs.hostid and h.poolid = vrs.poolid
				left join "WorkloadBalancing".fn_get_host_free_memory(_pool_ids) hfm on h.id = hfm.hostid and h.poolid = hfm.poolid
				left join "WorkloadBalancing".fn_get_host_potential_free_memory_dmc() cv on cv.hostid = h.id and cv.poolid = any(_pool_ids) and h.poolid = cv.poolid
				left join "WorkloadBalancing".fn_get_avg_host_metrics_30_min(_pool_ids) m30 on h.id = m30.hostid and h.poolid = m30.poolid
				left join "WorkloadBalancing".fn_get_avg_host_metrics_yesterday(_pool_ids) my on h.id = my.hostid and h.poolid = my.poolid
				left join  "WorkloadBalancing".fn_get_avg_host_pbd_metrics_now(_pool_ids,_shared_storage) pbdmn on h.id = pbdmn.hostid and h.poolid = pbdmn.poolid
				left join  "WorkloadBalancing".fn_get_avg_host_pbd_metrics_30_min(_pool_ids,_shared_storage) pbdm30 on h.id = pbdm30.hostid and h.poolid = pbdm30.poolid
				left join  "WorkloadBalancing".fn_get_avg_host_pbd_metrics_yesterday(_pool_ids,_shared_storage) pbdmy on h.id = pbdmy.hostid and h.poolid = pbdmy.poolid
			where h.poolid = any(_pool_ids)
				and ((array_upper(_host_ids, 1) > 0 and h.id = any(_host_ids)) 
					  or 
					 (array_upper(_host_ids, 1) is null));					
		return next _ref_host_metrics;
	

		-- RESULT SET #5: Number of VMs running on each host
		open _ref_num_vms  for 
			select  hv.hostid as host_id, 
				hph.poolid,
				count(vmid) as num_vm 
			from host_vm hv 
				join hv_pool_host hph on (hv.hostid = hph.hostid)
			where hph.poolid = any(_pool_ids) 
				and ((array_upper(_host_ids, 1) > 0  and hv.hostid= any(_host_ids)) 
					  or 
					 (array_upper(_host_ids, 1) is null))
			group by hv.hostid, hph.poolid;
		return next _ref_num_vms;

			
		-- RESULT SET #6: The default or local storage repositorie on each host.
		open _ref_host_storage	for
			select	hsr.host_id       as host_id,
				sr.id             as sr_id,
				sr.uuid           as sr_uuid, 
				sr.name           as sr_name,
				sr.size           as sr_size,
				sr.used           as sr_used,
				sr.poolid         as poolid,
				sr.pool_default_sr as sr_default
			from hv_host_storage_repository hsr				
				join storage_repository sr on sr.id = hsr.sr_id
				join hv_pool_host hph on hsr.host_id = hph.hostid
			where hph.poolid = any(_pool_ids) 
				and ((_shared_storage = true and sr.pool_default_sr = true) 
					or 
					(_shared_storage = false and sr.name = 'Local storage'))
				and ((array_upper(_host_ids, 1) > 0 and hsr.host_id = any(_host_ids)) 
					  or 
					 (array_upper(_host_ids, 1) is null and hsr.host_id = hsr.host_id))
			order by hsr.host_id;
		return next _ref_host_storage;
		
			
		-- RESULT SET #7: The physical interfaces on each host.
		open _ref_host_pif  for
			select	hpi.hostid	as host_id,
				pif.id        	as pif_id,
				pif.uuid      	as pif_uuid, 
				pif.name      	as pif_name,
				pif.networkid 	as networkid,
				pif.poolid,
				pif.is_management_interface
			from hv_host_pif hpi
				join hv_pif pif on pif.id = hpi.pif_id
				join hv_pool_host hph on hpi.hostid = hph.hostid
			where hph.poolid = any(_pool_ids)
				and ((array_upper(_host_ids, 1) > 0 and hpi.hostid = any(_host_ids)) 
					  or 
					 (array_upper(_host_ids, 1) is null))
			order by hpi.hostid;
		return next _ref_host_pif;
				
	end if;
	return;

end;
$$ language plpgsql;

/*
begin;
select "WorkloadBalancing".place_vm_by_uuids(array['87180fca-b520-449d-a6ae-82ee7be7a304','ae8e3e08-0d46-4fc1-bc42-62fd1a515468'], null,true);

fetch all from "<unnamed portal 223>";

select "WorkloadBalancing".fn_get_avg_host_pbd_metrics_now(array[5,17],true);
select "WorkloadBalancing".fn_get_avg_host_pbd_metrics_30_min(array[5,17],true);
select "WorkloadBalancing".fn_get_avg_host_pbd_metrics_yesterday(array[5,17],true);
*/
-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Create date: December 9, 2008
-- Modified for 
-- PosgtreSQL:	Deane Smith
-- On:		Jan 18, 2011
-- Description:	Retrieve the stored procedure name required to run the report
--              identified by the specified report file name.
-- Parameters:
--     report_file - The RDLC file name for the report (report_file column of
--                   the report table) of the report whose stored proc name is
--                   to be retrieved.
-- Returns:
--   If successful, the stored proc name for the report.
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".report_get_sql_by_filename
( 
	_report_file	varchar(100)
);

CREATE FUNCTION "WorkloadBalancing".report_get_sql_by_filename
( 
	_report_file	varchar(100)
) 
RETURNS varchar(100) AS $$
DECLARE  
	_report_proc varchar(100) := null;
BEGIN

	_report_proc := (select report_proc from report where report_file = _report_file);

	RETURN _report_proc;

END;
$$ LANGUAGE plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:
--	 Set the maximum CPU rating for the specified hypervisor pool.
-- Parameters:
--   pool_id        - The database ID (id column of the hv_pool table) of the 
--                    hypervisor pool whosed maximum CPU rating will be set.
--   max_cpu_rating - The maximum CPU rating for the hypervisor pool.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".set_pool_cpu_rating
(
	_pool_id	int,
	_max_cpu_rating int
);

CREATE FUNCTION "WorkloadBalancing".set_pool_cpu_rating
(
	_pool_id	int,
	_max_cpu_rating int
) RETURNS void AS $$

BEGIN

	update 	hv_pool 
	   set 	max_cpu_rating = _max_cpu_rating 
	 where 	id=_pool_id;
	
END;

$$ LANGUAGE plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		Sept 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 22, 2010
-- Description:
--	 Set the last_result column of the hv_host table for the specified host.
-- Parameters:
--   hostd    - The database ID (id column of the host table) of the host
--              whose last result will be set.
--   result   - The last result value.
--   tstamp   - The time stamp for the last result.
--   
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".set_host_last_result
(
	_host_id		int,
	_last_result		int,
	_last_result_time	timestamp
);

create function "WorkloadBalancing".set_host_last_result
(
	_host_id		int,
	_last_result		int,
	_last_result_time	timestamp
) returns void as $$
begin
	update hv_host 
		set last_result=_last_result,
			last_result_time=_last_result_time
	  where id=_host_id;
end;

$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		May 05, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 19, 2010
-- Description:
--	 Set the powered_off_by_wlb column of the hv_host table to 1 for the 
--   specified host.
-- Parameters:
--   host_id  - The database ID (id column of the hv_host table) of the host
--              for which the powered_off_by_wlb column will be set.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".set_host_powered_off_by_wlb
(
	_host_id		int,
	_powered_off_by_wlb	int
);

create function "WorkloadBalancing".set_host_powered_off_by_wlb
(
	_host_id		int,
	_powered_off_by_wlb	int
) returns void 
as $$
begin

	if _powered_off_by_wlb = 1 then
		update hv_host set powered_off_by_wlb = TRUE where id=_host_id;
	else
		update hv_host set powered_off_by_wlb = FALSE where id=_host_id;	
	end if;

end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			Sept 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Set the last result column of the hv_pool table for the pool to which the
--   specified host belongs.
-- Parameters:
--   host_id  - The database ID (id column of the hv_host table) of the 
--              host in the pool whose status will be set.
--   last_result      - The last result value.
--   last_result_time - The time stamp for the last result.

-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".set_pool_last_result_by_host_id
(
	_host_id		int,
	_last_result	  	int,
	_last_result_time 	timestamp
);

create function "WorkloadBalancing".set_pool_last_result_by_host_id
(
	_host_id		int,
	_last_result	  	int,
	_last_result_time 	timestamp
) returns void as $$

declare _pool_id int;
begin
	select into _pool_id poolid from hv_pool_host where hostid=_host_id;

	update hv_pool 
		set last_result=_last_result,
			last_result_time=_last_result_time
	  where id=_pool_id;
end;
$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			Sept 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Set the last_result column of the virtual_machine table for the specified VM.
-- Parameters:
--   vm_id    - The database ID (id column of the virtual_machine table) of the 
--              VM whose last result will be set.
--   result   - The last result value.
--   tstamp   - The time stamp for the last result.
--   
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".set_vm_last_result
(
	_vm_id			int,
	_last_result		int,
	_last_result_time	timestamp
);

create function "WorkloadBalancing".set_vm_last_result
(
	_vm_id			int,
	_last_result		int,
	_last_result_time	timestamp
) returns void as $$
begin

	update virtual_machine 
		set last_result=_last_result,
			last_result_time=_last_result_time
	  where id=_vm_id;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		John Cartales
-- Date:		Sept 16, 2008
-- Modified for PgSQL	Oct 14, 2010
-- Description:
--	 Set the status column of the hv_pool table for the pool to which the
--   specified host belongs.
-- Parameters:
--   host_id  - The database ID (id column of the hv_host table) of the 
--              host in the pool whose status will be set.
--   status   - The new status value.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".set_pool_status_by_host_id
(
	_host_id int,
	_status int
);

create function "WorkloadBalancing".set_pool_status_by_host_id
(
	_host_id int,
	_status int
) returns void as $$
declare
	_pool_id int;
begin
	select poolid into _pool_id from hv_pool_host where hostid=_host_id;
	update hv_pool set status=_status where id=_pool_id;
end;
$$ language plpgsql;
-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			Sept 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 22, 2010
-- Description:
--	 Set the status column of the hv_host table for the specified host.
-- Parameters:
--   host_id  - The database ID (id column of the hv_host table) of the 
--              host whose status will be set.
--   status   - The new status value.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".set_host_status
(
	_host_id	int,
	_status		int
);

create function "WorkloadBalancing".set_host_status
(
	_host_id	int,
	_status		int
) returns void as $$
begin
	update hv_host set status=_status where id=_host_id;
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			John Cartales
-- Date:			Sept 16, 2008
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Oct 20, 2010
-- Description:
--	 Set the status column of the virtual_machine table for the specified VM.
-- Parameters:
--   vm_id    - The database ID (id column of the virtual_machine table) of the 
--              VM whose status will be set.
--   status   - The new status value.
-- Returns:
--   n/a
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".set_vm_status
(
	_vm_id		int,
	_status		int
);

create function "WorkloadBalancing".set_vm_status
(
	_vm_id		int,
	_status		int
) returns void as $$
begin
	update virtual_machine set status=_status where id=_vm_id;
end;
$$ language plpgsql;
-- ========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:	
--	 Update the configuration item and reload the core_config table
-- Parameters:
--	 _component_id 	   ID of component owning config item to update
--	 _category	   Category of the config item to update
--	 _item_name	   Name of the config item to update
--	 _value		   New value of the config item
--	 _touched_by       Name of the user making the update
--	 _tstamp	   UTC time stamp of the update.
-- Returns:
--   The number if rows affected by the update (should be one) and a result
--   set containing all rows of the core_config table.
-- ========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".update_config_item
(
	_component_id 	int,
	_category	varchar(256),
	_item_name	varchar(256),
	_value		varchar(256),
	_touched_by	varchar(256),
	_tstamp		timestamp
);

create function "WorkloadBalancing".update_config_item
(
	_component_id 	int,
	_category	varchar(256),
	_item_name	varchar(256),
	_value		varchar(256),
	_touched_by	varchar(256),
	_tstamp		timestamp
) returns setof refcursor as $$

declare
	_core_config refcursor;

begin
	-- Update the config item.
	update core_config 
		set value = _value,
		touched_by = _touched_by,
		tstamp = _tstamp
	where component_id = _component_id 
		and category = _category 
		and item_name = _item_name;
	
	-- Reload all of the config data.
	open _core_config for
		select * from load_core_config();
	return next _core_config;
	return;	 
end;
$$ language plpgsql; 

/*
begin;
select "WorkloadBalancing".update_config_item(3,cast('Reporting' as varchar(256)), cast('SMTPServer' as varchar(256)),cast('localhost' as varchar(256)),cast('' as varchar(256)),cast('11/17/2010 9:25:31 PM' as timestamp));
fetch all from "<unnamed portal 13>"
*/
-- ============================================================================
-- Author:		John Cartales
-- Date:		August 20, 2008
-- Modified by:		Rabin Karki
-- On:			18 Oct, 2010
-- Description:
--	 Update a row to the host_vm_history table by adding the ending time stamp
--   for the specified host and VM.
-- Parameters:
--   host_id	- The database ID (id column of the hv_host table) of the host.
--   vm_id		- The database ID (id column of the virtual_machine table) of
--				  the virtual machine.
--   end_time   - The UTC time the VM stopped running on the host.
-- Returns:
--   The number of rows updated.  Should be one.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".update_host_vm_history
(
	_host_id 	int,
	_vm_id 		int,
	_end_time 	timestamp
);

create function "WorkloadBalancing".update_host_vm_history
(
	_host_id int,
	_vm_id int,
	_end_time timestamp
) returns int as $$
declare
	_rowcount int := 0;
begin
	if _host_id is not null and _host_id > 0 then
		update host_vm_history set end_time=_end_time
			where host_id=_host_id and vm_id=_vm_id and end_time is null;
	else
		update host_vm_history set end_time=_end_time
			where vm_id=_vm_id and end_time is null;
	end if;
	GET DIAGNOSTICS _rowcount = ROW_COUNT; 
	return _rowcount;
end;
$$ language plpgsql;


-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Rabin Karki
-- Date:			Jan 11, 2012
-- Description
--	Get discovery status and last discovery completed timestamp of a pool
-- Parameters:
--   id	                       	- The unique ID of the hypervisor pool
-- Returns:
--		discovery_status		- Discovery status of the pool
--						0 -> New pool. 1 -> Discovery in progress. 2 -> Discovery complete. 4 -> Unknown
--		last_discovery_completed 	- DateTime the last time Discovery was completed
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_discovery_status
(
	_pool_id bigint
);

create function "WorkloadBalancing".get_discovery_status
(
	_pool_id bigint
) returns refcursor as
$$
declare 
	_ref_discovery_status refcursor;
begin
	if exists ( select id from hv_pool where id = _pool_id ) then
		open _ref_discovery_status for
			select discovery_status, last_discovery_completed from hv_pool where id = _pool_id;
		return _ref_discovery_status;
	else
  -- pool doesn't exist, return unknown status
		open _ref_discovery_status for
			select 4 as discovery_status, getutcdate() as last_discovery_completed;
		return _ref_discovery_status;
	end if;	
end;
$$ language 'plpgsql';

-- ============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Rabin Karki
-- Date:			Jan 11, 2012
-- Description
--	Update discovery status and timestamp of a pool
-- Parameters:
--   id	                       	- The unique ID of the hypervisor pool
--   discovery_status		- Discovery status of the pool
--				0 -> New pool. 1 -> Discovery in progress. 2 -> Discovery complete
-- Returns:
--   Nothing
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".update_discovery_status
(
	_pool_id 	  bigint,
	_discovery_status int
);

create function "WorkloadBalancing".update_discovery_status
(
	_pool_id bigint,
	_discovery_status int
) returns void as
$$
begin
	if exists ( select id from hv_pool where id = _pool_id ) then
		update hv_pool set discovery_status = _discovery_status where id = _pool_id;
		-- if discovery_status flag is 'completed', update the timestamp
		if (_discovery_status = 2) then
			update hv_pool set last_discovery_completed = getutcdate() where id = _pool_id;
		end if;
	end if;
	return;
end;
$$ language 'plpgsql';

-- ==========================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Brian Donegan
-- Create date: 		April 6, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 3, 2010
-- Description:	Retrieves details of a scheduled task for populating Task objects
-- Parameters:
--   _taksid - System assigned id for the task to be loaded
-- Returns:
--   Result set 1 is the Task, Action and Trigger details
--	 Result set 2 moved to sched_load_task_action_param_by_id.sql file
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_sched_task_by_id
(
	_taskid int
);

create function "WorkloadBalancing".load_sched_task_by_id
(
	_taskid int
) returns setof refcursor as $$
declare 
	details_cur refcursor;
	action_param_cur refcursor;

begin
	-- Return the Task, Trigger and Action details
	open details_cur for
		select	sched_task.id as taskid,
			sched_task.poolid,
			sched_task.name,
			sched_task.description,
			sched_task.enabled,
			sched_task.owner,
			sched_task.last_run_result,
			sched_task.last_touched_by,
			sched_task.tstamp as last_touched,
			sched_trigger.type as trigger_type,
			sched_trigger.days_of_week,
			sched_trigger.time as execute_time,
			sched_trigger.enable_date,
			sched_trigger.disable_date,
			sched_trigger.last_run,
			sched_action.type as action_type,
			sched_action_type.name as action_name,
			sched_action_type.description as action_description,
			sched_action_type.assembly,
			sched_action_type.class
		from sched_task
		inner join sched_trigger
			on sched_task.id = sched_trigger.taskid
		inner join sched_action
			on sched_trigger.id = sched_action.triggerid
		inner join sched_action_type
			on sched_action.type = sched_action_type.id
		where sched_task.id = _taskid;
	return next details_cur;

	open action_param_cur for
		select	sched_trigger.taskid,
			sched_action_param.param_name,
			sched_action_param.param_value
		from sched_action_param
		inner join sched_action
			on sched_action_param.actionid = sched_action.id
		inner join sched_trigger
			on sched_action.triggerid = sched_trigger.id
		inner join sched_task
			on sched_trigger.taskid = sched_task.id
		where sched_task.id = _taskid;
	return next action_param_cur;
	
	return;
end;
$$ language plpgsql;
-- ==========================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: 	April 6, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 3, 2010
-- Description:	Retrieves details of pending scheduled tasks for populating Task objects
-- Parameters:
-- Returns cursors:
--   Result set 1 is the Task, Action and Trigger details
--	 Result set 2 is the Action parameters
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_pending_sched_tasks();

create function "WorkloadBalancing".load_pending_sched_tasks()
returns setof refcursor as $$

declare 
	-- Define the trigger type enumeration values
	_trigger_type_once int := 0;
	_trigger_type_daily int := 1;
	_trigger_type_weekly int := 2;
	-- End define

	_day_of_week bigint;
	_now timestamp;
	_execute_time timestamp;
	_base_date timestamp;

	taskdetails_cur refcursor;
	action_params_cur refcursor;

begin
	-- get the current utc date
	_now := getutcdate();

	-- convert the SQL weekday into our DayOfWeek enumeration
	_day_of_week := power(2, EXTRACT(DOW FROM getutcdate()))::bigint%127;
	

	-- get the date portion of the current date
	_base_date = date(getutcdate());

	-- force rounding of the execute time to minutes
	_execute_time := date_trunc('minute', getutcdate());

	open taskdetails_cur for 
		select	sched_task.id as taskid,
			sched_task.poolid,
			sched_task.name,
			sched_task.description,
			sched_task.enabled,
			sched_task.last_run_result,
			sched_task.last_touched_by,
			sched_task.tstamp as last_touched,
			sched_trigger.type as trigger_type,
			sched_trigger.days_of_week,
			sched_trigger.time as execute_time,
			sched_trigger.enable_date,
			sched_trigger.disable_date,
			sched_trigger.last_run,
			sched_action.type as action_type,
			sched_action_type.assembly,
			sched_action_type.class
		from sched_task
		inner join sched_trigger
			on sched_task.id = sched_trigger.taskid
		inner join sched_action
			on sched_trigger.id = sched_action.triggerid
		inner join sched_action_type
			on sched_action.type = sched_action_type.id
		where (sched_trigger.type = _trigger_type_once)
			and (sched_trigger.last_run is null or (_now - sched_trigger.last_run) > '0 day')
			and (sched_trigger.days_of_week & _day_of_week) = _day_of_week
			and (extract(minute from sched_trigger.time) * interval '1 minute' + extract(hour from sched_trigger.time) * interval '1 hour' + _base_date) = _execute_time
			--and dateadd(minute, extract(minute from sched_trigger.time), dateadd(hour, extract(hour from sched_trigger.time), _base_date)) = _execute_time
			and (sched_trigger.enable_date is null or sched_trigger.enable_date < _now)
			and (sched_trigger.disable_date is null or sched_trigger.disable_date > _now)
			and sched_task.enabled = TRUE
	union all

--select * from sched_trigger
--extract(minute from '1900-01-01 18:54:00') 
--select (extract(minute from TIMESTAMP '1900-01-01 18:54:00') * interval '1 minute' + extract(hour from TIMESTAMP '1900-01-01 18:54:00') * interval '1 hour' + date(getutcdate()))

	select	sched_task.id as taskid,
			sched_task.poolid,
			sched_task.name,
			sched_task.description,
			sched_task.enabled,
			sched_task.last_run_result,
			sched_task.last_touched_by,
			sched_task.tstamp as last_touched,
			sched_trigger.type as trigger_type,
			sched_trigger.days_of_week,
			sched_trigger.time as execute_time,
			sched_trigger.enable_date,
			sched_trigger.disable_date,
			sched_trigger.last_run,
			sched_action.type as action_type,
			sched_action_type.assembly,
			sched_action_type.class
		from sched_task
		inner join sched_trigger
			on sched_task.id = sched_trigger.taskid
		inner join sched_action
			on sched_trigger.id = sched_action.triggerid
		inner join sched_action_type
			on sched_action.type = sched_action_type.id
		where (sched_trigger.type = _trigger_type_daily or sched_trigger.type = _trigger_type_weekly)
			and (sched_trigger.last_run is null or (_now - sched_trigger.last_run) > '0 day' or sched_task.tstamp > sched_trigger.last_run)
			and (sched_trigger.days_of_week & _day_of_week) = _day_of_week
			and (extract(minute from sched_trigger.time) * interval '1 minute' + extract(hour from sched_trigger.time) * interval '1 hour' + _base_date) = _execute_time
			--and dateadd(minute, datepart(minute, sched_trigger.time), dateadd(hour, datepart(hour, sched_trigger.time), _base_date)) = _execute_time
			and (sched_trigger.enable_date is null or sched_trigger.enable_date < _now)
			and (sched_trigger.disable_date is null or sched_trigger.disable_date > _now)
			and sched_task.enabled = TRUE;
	return next taskdetails_cur;



	open action_params_cur for
		select	sched_trigger.taskid as taskid,
			sched_action_param.param_name,
			sched_action_param.param_value
		from sched_task
		inner join sched_trigger
			on sched_task.id = sched_trigger.taskid
		inner join sched_action
			on sched_trigger.id = sched_action.triggerid
		inner join sched_action_type
			on sched_action.type = sched_action_type.id
		inner join sched_action_param
			on sched_action.id = sched_action_param.actionid
		where (sched_trigger.type = _trigger_type_once)
			and (sched_trigger.last_run is null or (_now - sched_trigger.last_run) > '0 day' or sched_task.tstamp > sched_trigger.last_run)
			and (sched_trigger.days_of_week & _day_of_week) = _day_of_week
			and (extract(minute from sched_trigger.time) * interval '1 minute' + extract(hour from sched_trigger.time) * interval '1 hour' + _base_date) = _execute_time
			and (sched_trigger.enable_date is null or sched_trigger.enable_date < _now)
			and (sched_trigger.disable_date is null or sched_trigger.disable_date > _now)
	union all
	select	sched_trigger.taskid as taskid,
			sched_action_param.param_name,
			sched_action_param.param_value
		from sched_task
		inner join sched_trigger
			on sched_task.id = sched_trigger.taskid
		inner join sched_action
			on sched_trigger.id = sched_action.triggerid
		inner join sched_action_type
			on sched_action.type = sched_action_type.id
		inner join sched_action_param
			on sched_action.id = sched_action_param.actionid
		where (sched_trigger.type = _trigger_type_daily or sched_trigger.type = _trigger_type_weekly)
			and (sched_trigger.last_run is null or (_now - sched_trigger.last_run) > '0 day')
			and (sched_trigger.days_of_week & _day_of_week) = _day_of_week
			and (extract(minute from sched_trigger.time) * interval '1 minute' + extract(hour from sched_trigger.time) * interval '1 hour' + _base_date) = _execute_time
			and (sched_trigger.enable_date is null or sched_trigger.enable_date < _now)
			and (sched_trigger.disable_date is null or sched_trigger.disable_date > _now);
	return next action_params_cur;

	return;
end; $$ language plpgsql;

-- ==========================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: April 6, 2009-- 
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 2, 2010
-- Description:	Retrieves details of a scheduled task for populating Task objects
-- Parameters:
--   _taksid - System assigned id for the task to be loaded
-- Returns:
--   Result set 1 is the Task, Action and Trigger details
--	 Result set 2 is the Action parameters
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_sched_tasks_by_poolid_and_type
(
	_poolid int,
	_actiontype int
);

create function "WorkloadBalancing".load_sched_tasks_by_poolid_and_type
(
	_poolid int,
	_actiontype int
) returns setof refcursor as $$

declare 
	details_cur refcursor;
	action_param_cur refcursor;

begin
	-- Return the Task, Trigger and Action details
	open details_cur for
		select	sched_task.id as taskid,
			sched_task.poolid,
			sched_task.name,
			sched_task.description,
			sched_task.enabled,
			sched_task.owner,
			sched_task.last_run_result,
			sched_task.last_touched_by,
			sched_task.tstamp as last_touched,
			sched_trigger.type as trigger_type,
			sched_trigger.days_of_week,
			sched_trigger.time as execute_time,
			sched_trigger.enable_date,
			sched_trigger.disable_date,
			sched_trigger.last_run,
			sched_action.type as action_type,
			sched_action_type.name as action_name,
			sched_action_type.description as action_description,
			sched_action_type.assembly,
			sched_action_type.class
		from sched_task
		inner join sched_trigger
			on sched_task.id = sched_trigger.taskid
		inner join sched_action
			on sched_trigger.id = sched_action.triggerid
		inner join sched_action_type
			on sched_action.type = sched_action_type.id
		where (sched_task.poolid = _poolid or _poolid = 0)
			and (_actiontype = 0 or sched_action.type = _actiontype);
	return next details_cur;

	open action_param_cur for
		select	sched_trigger.taskid,
			sched_action_param.param_name,
			sched_action_param.param_value
		from sched_action_param
		inner join sched_action
			on sched_action_param.actionid = sched_action.id
		inner join sched_trigger
			on sched_action.triggerid = sched_trigger.id
		inner join sched_task
			on sched_trigger.taskid = sched_task.id
		where (sched_task.poolid = _poolid or _poolid = 0)
			and (_actiontype = 0 or sched_action.type = _actiontype);
	return next action_param_cur;
	
	return;
end;
$$ language plpgsql;
-- ==========================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:			Brian Donegan
-- Create date:			 April 6, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 2, 2010
-- Description:	Retrieves details of a scheduled task for populating Task objects
-- Parameters:
--   _poolid - System assigned id for the task to be loaded
--   _actiontypename - Name of the action type to filter for
-- Returns:
--   Task, Action and Trigger details
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".load_sched_tasks_by_poolid_and_type_name
(
	_poolid int,
	_actiontypename varchar(50)
);

create function "WorkloadBalancing".load_sched_tasks_by_poolid_and_type_name
(
	_poolid int,
	_actiontypename varchar(50)
) returns setof refcursor as $$

--declare r sched_task_details%rowtype;
declare 
	details_cur refcursor; 
	action_param_cur refcursor;

begin
	-- Return the Task, Trigger and Action details
	open details_cur for
		select	sched_task.id as taskid,
			sched_task.poolid,
			sched_task.name,
			sched_task.description,
			sched_task.enabled,
			sched_task.owner,
			sched_task.last_run_result,
			sched_task.last_touched_by,
			sched_task.tstamp as last_touched,
			sched_trigger.type as trigger_type,
			sched_trigger.days_of_week,
			sched_trigger.time as execute_time,
			sched_trigger.enable_date,
			sched_trigger.disable_date,
			sched_trigger.last_run,
			sched_action.type as action_type,
			sched_action_type.name as action_name,
			sched_action_type.description as action_description,
			sched_action_type.assembly,
			sched_action_type.class
		from sched_task
		inner join sched_trigger
			on sched_task.id = sched_trigger.taskid
		inner join sched_action
			on sched_trigger.id = sched_action.triggerid
		inner join sched_action_type
			on sched_action.type = sched_action_type.id
		where (sched_task.poolid = _poolid or _poolid = 0)
			and sched_action_type.name = _actiontypename;
	return next details_cur;

	open action_param_cur for
		select	sched_trigger.taskid,
			sched_action_param.param_name,
			sched_action_param.param_value
		from sched_action_param
		inner join sched_action
			on sched_action_param.actionid = sched_action.id
		inner join sched_trigger
			on sched_action.triggerid = sched_trigger.id
		inner join sched_action_type
			on sched_action.type = sched_action_type.id
		inner join sched_task
			on sched_trigger.taskid = sched_task.id
		where (sched_task.poolid = _poolid or _poolid = 0)
			and sched_action_type.name = _actiontypename;
	return next action_param_cur;

	return;

	
end; $$ language plpgsql;
		
			
-- ==========================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: April 6, 2009
-- Description:	Deletes a scheduled task by task id
-- Parameters:
--   @taskid - System assigned id for the task to be deleted
-- Returns:
--   Affected rowcount (int)
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".delete_sched_task_by_id
(
	_taskid int
);

create function "WorkloadBalancing".delete_sched_task_by_id
(
	_taskid int
) returns void as $$
begin

	delete from
		sched_task
		where id = _taskid;
		
end;
$$ language plpgsql;
-- ==========================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: April 6, 2009
-- Modified for PosgtreSQL:	Rabin Karki
-- On:				Nov 3, 2010
-- Description:	Saves details of a scheduled task
-- Parameters:
--  _taskid - System assigned id for the task, null for new task
--	_poolid - Optional poolid pertaining to the task
--	_name - Name of the task (user defined, not required)
--	_description - Description of the task (user defined, not required)
--	_owner - Name of the user owning the task
--	_enabled - Whether the task is enabled 
--	_touched_by - Name of the last user to edit the task
--	_trigger_type - Interval type of the trigger
--	_days_of_week - Bit mask denoting the days of the week a weekly task will run
--	_execute_time - Time of day that the task will execute (date portion discarded)
--	_enable_date - Date that the task will become active
--	_disable_date - Date after which the task will no longer execute
--	_action_type - The type of action to be performed
-- Returns:
--   n/a
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".save_sched_task
(
	_taskid 	int,
	_poolid 	int,
	_name 		varchar(50),
	_description 	varchar(255),
	_enabled 	boolean,
	_owner 		varchar(255),
	_touched_by 	varchar(255),	
	_trigger_type 	int,
	_days_of_week 	int,
	_execute_time 	timestamp,
	_enable_date 	timestamp,
	_disable_date 	timestamp,
	_action_type 	int,
	_action_name 	varchar(255)
);

create function "WorkloadBalancing".save_sched_task
(
	_taskid int,
	_poolid int,
	_name varchar(50),
	_description varchar(255),
	_enabled boolean,
	_owner varchar(255),
	_touched_by varchar(255),
	
	_trigger_type int,
	_days_of_week int,
	_execute_time timestamp,
	_enable_date timestamp,
	_disable_date timestamp,
	_action_type int,
	_action_name varchar(255) default null
) returns int as $$

begin
	if (_taskid <= 0) then
	declare _triggerid int; _actionid int;
	begin
		insert into sched_task (poolid, 
			enabled,
			name,
			description,
			owner,
			last_touched_by,
			tstamp)
		values (_poolid,
			_enabled,
			_name,
			_description,
			_owner,
			_touched_by,
			getutcdate()) returning id into _taskid;


		insert into sched_trigger (taskid,
			type,
			days_of_week,
			time,
			enable_date,
			disable_date)
		values (_taskid,
			_trigger_type,
			_days_of_week,
			_execute_time,
			_enable_date,
			_disable_date) returning id into _triggerid;

		-- If the Action Name was specified instead of the Action Type, get the type
		if _action_type = 0 and _action_name is not null then
			select into _action_type id 
				from sched_action_type
				where name = _action_name;
		end if;

		insert into sched_action (triggerid, type)
			values (_triggerid, _action_type) returning id into _actionid;
	end;

	else
		update sched_task
			set poolid = _poolid,
			enabled = _enabled,
			name = _name,
			description = _description,
			owner = _owner,
			last_touched_by = _touched_by,
			tstamp = getutcdate()
				where id = _taskid;

		update sched_trigger
			set type = _trigger_type,
			days_of_week = _days_of_week,
			time = _execute_time,
			enable_date = _enable_date,
			disable_date = _disable_date,
			last_run = null
				where taskid = _taskid;

		update sched_action
			set type = (select id from sched_action_type where id = _action_type or name = _action_name)
			where triggerid = (select sched_trigger.id from sched_trigger where sched_trigger.taskid = _taskid);

		-- Clean up any existing params
		-- this looks kinda hacky, but didn't find a better way 
		delete from sched_action_param where id in(
			select sched_action_param.id from sched_action_param
			inner join sched_action
				on sched_action_param.actionid = sched_action.id
			inner join sched_trigger
				on sched_action.triggerid = sched_trigger.id
			where sched_trigger.taskid = _taskid);

	end if;
	return _taskid;
end;
$$ language plpgsql;



-- ==========================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: April 6, 2009
-- Description:	Saves details of a scheduled task
-- Parameters:
--  @taskid - System assigned id for the task, null for new task
--	@poolid - Optional poolid pertaining to the task
--	@name - Name of the task (user defined, not required)
--	@description - Description of the task (user defined, not required)
--	@owner - Name of the user owning the task
--	@enabled - Whether the task is enabled 
--	@touched_by - Name of the last user to edit the task
--	@trigger_type - Interval type of the trigger
--	@days_of_week - Bit mask denoting the days of the week a weekly task will run
--	@execute_time - Time of day that the task will execute (date portion discarded)
--	@enable_date - Date that the task will become active
--	@disable_date - Date after which the task will no longer execute
--	@action_type - The type of action to be performed
-- Returns:
--   n/a
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".save_sched_task_action_param
(
	_taskid int,
	_name 	varchar(50),
	_value 	varchar(255)
);

CREATE FUNCTION "WorkloadBalancing".save_sched_task_action_param
(
	_taskid int,
	_name varchar(50),
	_value varchar(255)
)
RETURNS VOID AS $$
	DECLARE _actionid int;
BEGIN

	_actionid = (select sched_action.id
		from sched_action
		inner join sched_trigger
			on sched_action.triggerid = sched_trigger.id
		where sched_trigger.taskid = _taskid);

    if _actionid is not null
    then

	    if exists(select param_value from sched_action_param where actionid = _actionid and sched_action_param.param_name = _name)
		then
			update sched_action_param
				set param_value = _value
				where actionid = _actionid
					and param_name = _name;
	    else
			insert into sched_action_param (actionid, param_name, param_value)
				values (_actionid, _name, _value);
		end if;
    end if;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Description:	Retrieves details of a scheduled task for populating Task objects
-- Parameters:
--   @taksid - System assigned id for the task to be loaded
-- Returns:
--   Result set 1 is the Task, Action and Trigger details
--	 Result set 2 is the Action parameters
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_task_action_types();

create function "WorkloadBalancing".get_task_action_types
(
) returns setof  refcursor as $$

declare 
	_action_types refcursor;

begin	
	open  _action_types for
		select	id as type,
			name,
			description,
			assembly,
			class
		from sched_action_type; 
	return next _action_types;
	
	return;
end;
$$ language plpgsql;

/*
select "WorkloadBalancing".get_task_action_types()
drop function "WorkloadBalancing".get_task_action_types();
*/
-- ==========================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Create date: April 9, 2009
-- Description:	Sets the current state of a task trigger
-- Parameters:
--   @taskid - System assigned id for the task to be updated
--	 @success - The result of the last run (0=failure, 1=success)
-- Returns:
--	 n/a  
-- ==========================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".set_task_last_run_result
(
	_taskid int,
	_success boolean
);

CREATE FUNCTION "WorkloadBalancing".set_task_last_run_result
(
	_taskid int,
	_success boolean
) 
RETURNS VOID AS $$
	DECLARE _UTCTimestamp timestamp;
BEGIN
 
 _UTCTimestamp = getutcdate();

	update sched_trigger
		set last_run = _UTCTimestamp	
		where taskid = _taskid;

	update sched_task
		set last_run_result = _success
		where id = _taskid;
END;
$$ LANGUAGE plpgsql;
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Date:		Mar 31, 2010
-- Updated:		Nov 15, 2010
--			Converted to PostGreSQL
-- Description:
--	 Retrieve the UTC date and time audit log where last recorded for the 
--   specified pool.
-- Parameters:
--   pool_id	- the database ID (id column of the hv_pool table) of the pool.
-- Returns:
--   1. UTC date and time audit log where last recorded for the pool if data is
--		present; null otherwise.
--	 2. The number of days that audit log data need to be retrieved back
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".get_audit_log_data_retrieve_info
(
	_pool_id	int
);

CREATE FUNCTION "WorkloadBalancing".get_audit_log_data_retrieve_info
(
	_pool_id	int
)
RETURNS SETOF refcursor AS $$
DECLARE 
	_ref_most_recent_timestamp 	refcursor;
	_ref_number_of_days 		refcursor;
BEGIN

	-- get the most recent log_tstamp.
	open _ref_most_recent_timestamp for
		select log_tstamp from hv_audit_log 
		where pool_id = _pool_id
		order by log_tstamp desc
		limit 1;
	return next _ref_most_recent_timestamp;


	-- get the number of days that the audit log data can be retrieved back
	open _ref_number_of_days for
		select value as auditLogRetrieveBackDays
		from hv_pool_config
		where pool_id = _pool_id and name = 'AuditLogRetrieveBackDays';
	return next _ref_number_of_days;

	RETURN;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Date:		Mar 31, 2010
-- Updated:		
-- Description:
--	 Reset audit log data AuditLogRetrieveBackDay to zero and delete audit log 
--	 data for the pool
-- Parameters:
--   pool_id	- the database ID (id column of the hv_pool table) of the pool.
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".reset_audit_log_data_retrieve_info
(
	_pool_id	int
);

CREATE FUNCTION "WorkloadBalancing".reset_audit_log_data_retrieve_info
(
	_pool_id	int
)
RETURNS void AS $$
BEGIN

	-- delete audit log data for the pool.
	delete from hv_audit_log
	where pool_id = _pool_id;

	-- update audit log retrieve back flag
	update hv_pool_config
	set value = '0'
	where pool_id = _pool_id and name = 'AuditLogRetrieveBackDays';

END;
$$ LANGUAGE plpgsql;


-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Date:		Aug 31, 2009
-- Modified for PosgtreSQL:	Deane Smith
-- On:				Nov 13, 2010
-- Description:
--	 Save a audit log record for the specified pool.
-- Parameters:
--   log_tstamp			   - Date and time stamp fot the audit log record.
--	 log_type			   - Audit log record type: debug|info.
--   pool_id			   - The database ID (id column of the hv_pool table).
--   hostid                - The database ID (id column of the hv_host table).
--                           of the host owning the metrics.
--   session               - Session number of the audit log record.
--   user_sid              - SID of the audit log record user.
--   access_allowed        - User's access right in the audit log record: true(allowed)|false(denied).
--   succeeded			   - The result of the event in the audit log record: ture(ok)|false(error).
--   error_info			   - Error in the audit log record if there is any.
--   call_type			   - Event call type in the audit log record: api|http.
--   event_type            - Event in the audit log record: import/export,host/pool-backup...
-- Returns:
--   int                   - The id of the new row, used for foreign-key inserts
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_audit_log_add
(
	 "_log_tstamp" 			timestamp,
	 "_log_type" 			varchar(96),
	 "_pool_id" 			int,
	 "_session" 			varchar(96),
	 "_user_sid" 			varchar(96),
	 "_user_name" 			varchar(96),
	 "_access_allowed" 		boolean,
	 "_succeeded"			boolean,
	 "_error_info" 			varchar(256),
	 "_call_type" 			varchar(96),
	 "_event_object"		varchar(96),
	 "_event_object_name"		varchar(1024),
	 "_event_object_type"		varchar(96),
	 "_event_object_uuid"		varchar(48),
	 "_event_object_opaqueref"	varchar(48),
	 "_event_action"		varchar(96)
	
);


create function "WorkloadBalancing".hv_audit_log_add
(
	 "_log_tstamp" 			timestamp,
	 "_log_type" 			varchar(96),
	 "_pool_id" 			int,
	 "_session" 			varchar(96),
	 "_user_sid" 			varchar(96),
	 "_user_name" 			varchar(96),
	 "_access_allowed" 		boolean,
	 "_succeeded"			boolean,
	 "_error_info" 			varchar(256),
	 "_call_type" 			varchar(96),
	 "_event_object"		varchar(96),
	 "_event_object_name"		varchar(1024),
	 "_event_object_type"		varchar(96),
	 "_event_object_uuid"		varchar(48),
	 "_event_object_opaqueref"	varchar(48),
	 "_event_action"		varchar(96)
	
) 
RETURNS void AS
$$
declare _id bigint := null;
declare _event_object_id bigint := null;
declare _event_action_id bigint :=null;
declare _tstamp timestamp := (select current_timestamp at time zone 'UTC');
BEGIN

	-- Get event object
	-- we don't add new objects anymore, the table is prepopulated. so removing this
	--if not exists(select id from hv_audit_log_event_object where name = _event_object)
	--then
	--	insert into hv_audit_log_event_object (name) values (_event_object);
	--end if;

	select id into _event_object_id from hv_audit_log_event_object where name = lower(_event_object);

	-- Get event action
	--if not exists(select id from hv_audit_log_event_action where name = _event_action)
	--then
	--	insert into hv_audit_log_event_action (name) values (_event_action);
	--end if;
				
	select id into _event_action_id from hv_audit_log_event_action where name = lower(_event_action);


	-- Insert audit log data
	insert into hv_audit_log(log_tstamp,
				log_type,
				pool_id,
				session,
				user_sid,
				user_name,
				access_allowed,
				succeeded,
				error_info,
				call_type,
				event_object,
				event_object_name,
				event_object_type,
				event_object_uuid,
				event_object_opaqueref,
				event_action,
				tstamp ) 
			values (_log_tstamp,
				_log_type,
				_pool_id,
				_session,
				_user_sid,
				_user_name,
				_access_allowed,
				_succeeded,
				_error_info,
				_call_type,
				_event_object_id,
				_event_object_name,
				_event_object_type,
				_event_object_uuid,
				_event_object_opaqueref,
				_event_action_id,
				_tstamp)
			returning id into _id;

	--return _id;
	return;
END;
$$
LANGUAGE 'plpgsql';
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Rabin Karki
-- Date:		Mar 10, 2011
-- Description:
--	 Returns the content in hv_audit_log_event_object table
-- Parameters: 
-- enabled: Specifies whether we want the enabled objects or the disabled ones
-- ============================================================================

DROP FUNCTION IF EXISTS  "WorkloadBalancing".hv_audit_log_get_event_objects
(
	_enabled 	boolean,
	out id 		bigint,
	out name 	varchar
);

create function "WorkloadBalancing".hv_audit_log_get_event_objects
(
_enabled boolean default true,
out id bigint,
out name varchar
) returns setof record as $$

begin
	return query (select eo_t.id , eo_t.name from hv_audit_log_event_object eo_t where eo_t.enabled = _enabled);
end; 
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Rabin Karki
-- Date:		Mar 10, 2011
-- Description:
--	 Returns the content in hv_audit_log_event_object table
-- Parameters: 
-- enabled: Specifies whether we want the enabled objects or the disabled ones
-- ============================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing".hv_audit_log_get_event_actions
(
	_enabled 	boolean
);

create function "WorkloadBalancing".hv_audit_log_get_event_actions
(
_enabled boolean default true,
out id bigint,
out name varchar
) returns setof record as $$

begin
	return query (select ea_t.id , ea_t.name from hv_audit_log_event_action ea_t where ea_t.enabled = _enabled);
end; 
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Date:		April 5, 2012
-- Description:
--	 Adds or updates entries in the hv_audit_log_event_action table
-- Parameters: 
--  name: The name of the audit log action 
--  enabled: Specifies whether we want to include this action in the audit log report
--  description(optional): A description of the audit log action
-- ============================================================================
--
--  NOTE: This function is not used by code anywhere, but it is referenced in a KB 
--     	  article (CTX130830), so moving to it's own file for customers to use.
--
-- ==================================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing"."update_audit_log_actions" 
(  
  _name varchar(96),
  _enabled boolean,
  _description varchar(1024)
);

CREATE FUNCTION "WorkloadBalancing"."update_audit_log_actions" 
(  
  _name varchar(96),
  _enabled boolean default false,
  _description varchar(1024) default null
)
RETURNS void AS
$$
BEGIN

	if not exists(select * from hv_audit_log_event_action where name=_name)
    then
		insert into hv_audit_log_event_action (name, description, enabled) values(_name, _description, _enabled);
	else
		update hv_audit_log_event_action set enabled = _enabled, description = _description where name = _name;
	end if;	

END;
$$
LANGUAGE 'plpgsql';
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Brian Donegan
-- Date:		April 5, 2012
-- Description:
--	 Adds or updates entries in the hv_audit_log_event_object table
-- Parameters: 
--  name: The name of the audit log object 
--  enabled: Specifies whether we want to include this object in the audit log report
--  description(optional): A description of the audit log object
-- ==================================================================================
--
--  NOTE: This function is not used by code anywhere, but it is referenced in a KB 
--     	  article (CTX130830), so moving to it's own file for customers to use.
--
-- ==================================================================================

DROP FUNCTION IF EXISTS "WorkloadBalancing"."update_audit_log_objects" 
(  
  _name varchar(96),
  _enabled boolean,
  _description varchar(1024)
);

CREATE FUNCTION "WorkloadBalancing"."update_audit_log_objects" 
(  
  _name varchar(96),
  _enabled boolean default false,
  _description varchar(1024) default null
)
RETURNS void AS
$$
BEGIN

	if not exists(select * from hv_audit_log_event_object where name=_name)
    then
		insert into hv_audit_log_event_object (name, description, enabled) values(_name, _description, _enabled);
	else
		update hv_audit_log_event_object set enabled = _enabled, description = _description where name = _name;
	end if;	

END;
$$
LANGUAGE 'plpgsql';

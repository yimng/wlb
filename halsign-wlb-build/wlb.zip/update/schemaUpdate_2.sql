﻿-- ============================================================================
-- (c) Copyright 2012 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Phus Lu
-- Date:		Aug 5, 2014
-- Description:
--	 Schema update script
-- ============================================================================

ALTER TABLE "WorkloadBalancing"."hv_audit_log_event_action"
  ADD COLUMN "granularity" VARCHAR(50) NOT NULL DEFAULT 'Minimum';

ALTER TABLE "WorkloadBalancing"."hv_audit_log_event_object"
  ADD COLUMN "granularity" VARCHAR(50) NOT NULL DEFAULT 'Minimum';

ALTER TABLE "WorkloadBalancing"."report"
  ADD COLUMN "report_version" VARCHAR(100) NOT NULL DEFAULT 'tampa';

﻿-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated: Nov 26 2010
-- Author:    Phus Lu
-- Create Date:    Aug 5, 2014
-- Updated: Aug 5, 2014
--    Converted to PostGreSQL
--    Removed unused garbage variables and improved code flow.
-- Description: Retrieve the list of pools that are under performace pressure
--              when their optimization mode is max performance or have idle
--              host when the optimization mode is max density.
-- Parameters:
--   None
-- Returns:
--   Result Set 1:
--      Configuration, threshold and weight information for each hypervisor pool.
--   Result Set 2:
-- ==========================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".ae_get_pools_in_trouble
(
  _poll_interval_seconds int
)
RETURNS SETOF refcursor AS $$

DECLARE
  _opt_mode_max_perf        int := 0;
  _opt_mode_max_density     int := 1;
  _poll_interval                  interval;
  _ref_perf_pools_perf    refcursor;
  _ref_density_pools_perf   refcursor;
  _ref_density_pools_consolidate  refcursor;
BEGIN

  create temporary table _host_metrics
  (
    host_id       int,
    num_vms       int,
    avg_free_mem  bigint,
    total_mem     bigint,
    avg_cpu       numeric,
    avg_net_read  numeric,
    avg_net_write numeric,
    avg_load      numeric
  )
  on commit drop;


  create temporary table _vms_with_runstate
  (
    poolid int,
    hostid int,
    vmid int
  )
  on commit drop;


  create temporary table _pools_with_data
  (
    pool_id    int
  )
  on commit drop;



  create temporary table _pool_density_perf_issue
  (
    poolid          int,
    pool_uuid       varchar(48),
    pool_name       varchar(256),
    hv_type         int,
    pool_master_cpu_limit varchar(24),
    host_id         int,
    host_uuid       varchar(48),
    host_name     varchar(256),
    is_pool_master  boolean,
    can_power       boolean,
    fill_order      int,
    total_mem       bigint,
    potential_free_mem bigint,
    avg_free_mem    bigint,
    avg_cpu         numeric(9,8),
    avg_net_read    numeric(18,4),
    avg_net_write   numeric(18,4),
    avg_load        numeric(9,3),
    num_vms     int
  )
  on commit drop;


  -- Get the poll interval for the analysis engine.  We only care about
  -- pools that have data newer than the last poll interval.
  _poll_interval := '-' || _poll_interval_seconds || ' seconds';


  -- Grab the pools for which we have current data.
  insert into _pools_with_data (pool_id)
    select ph.poolid
    from host_metric hm
    join hv_pool_host ph on (ph.hostid = hm.hostid)
    where hm.tstamp >  datetimeadd(getutcdate(), _poll_interval)
    group by ph.poolid;


  -- Get the host metrics.  We have to look for max performance and max
  -- density issues but only want to get the metrics data once.
  insert into _host_metrics
    select  hm.hostid,
      count(distinct hv.vmid) as num_vms,
      avg(hm.free_mem) as free_mem,
      avg(hm.total_mem) as total_mem,
      avg(hm.avg_cpu_utilization) as cpu_util,
      avg(hm.avg_pif_read_per_sec) as net_read,
      avg(hm.avg_pif_write_per_sec) as net_write,
      avg(hm.load_average) as load_average
    from host_metric hm
    join hv_host h on h.id = hm.hostid
    join host_vm hv on (hm.hostid = hv.hostid)
    where h.active = true
    and h.enabled = true
    and h.power_state = 1
    group by hm.hostid;


  -- Get the vms with runstate issues
  insert into _vms_with_runstate
    select hph.poolid, hv.hostid, vm.vmid
    from vm_metric vm
    join host_vm hv on (vm.vmid = hv.vmid)
    join hv_pool_host hph on (hv.hostid = hph.hostid)
    join hv_pool_threshold hpt on (hph.poolid = hpt.pool_id)
    group by hph.poolid, hv.hostid, vm.vmid,
      hpt.host_runstate_full_contention_threshold_high,
      hpt.host_runstate_concurrency_hazard_threshold_high,
      hpt.host_runstate_partial_contention_threshold_high
    having  avg(vm.runstate_full_contention) > hpt.host_runstate_full_contention_threshold_high
      or avg(vm.runstate_concurrency_hazard) > hpt.host_runstate_concurrency_hazard_threshold_high
      or avg(vm.runstate_partial_contention) > hpt.host_runstate_partial_contention_threshold_high;

  -- Put the pools with the optimization mode set to max density that have
  -- performance issues into a table variable so we can filter them out of
  -- the query of density pools with density issues.
  insert into _pool_density_perf_issue
    select  ph.poolid,
      p.uuid,
      p.name,
      p.hv_type,
      pc1.value     as pool_master_cpu_limit,
      hm.host_id,
      h.uuid,
      h.name,
      h.is_pool_master,
      case lower(hc.value)
        when 'true'  then true
        when 'false' then false
        else false
      end as can_power,
      ph.fill_order,
      hm.total_mem,
      dmc.potential_free_mem,
      hm.avg_free_mem,
      hm.avg_cpu,
      hm.avg_net_read,
      hm.avg_net_write,
      hm.avg_load,
      hm.num_vms
    from _host_metrics hm
    join hv_host           h   on (h.id = hm.host_id)
    join hv_pool_host      ph  on (ph.hostid = hm.host_id)
    join hv_pool_threshold pt  on (pt.pool_id = ph.poolid)
    join hv_pool           p   on (p.id = ph.poolid)
    join _pools_with_data  pd  on (pd.pool_id = p.id)
    join hv_pool_config    pc  on (pc.pool_id = p.id and pc.name = 'OptimizationMode')
    join hv_pool_config    pc1 on (pc1.pool_id = p.id and pc1.name = 'PoolMasterCpuLimit')
    left join hv_host_config hc on (hc.host_id = h.id and hc.name = 'ParticipatesInPowerManagement')
    left join _vms_with_runstate vrs on (h.id = vrs.hostid)
    left join "WorkloadBalancing".fn_get_host_potential_free_memory_dmc() dmc on (dmc.hostid = ph.hostid and dmc.poolid = ph.poolid)
    where cast(pc.value as int) = _opt_mode_max_density and
    --p.id in (select pool_id from @pools_with_data) and
    (
      (hm.avg_cpu > pt.host_cpu_threshold_critical      or
      hm.avg_load > pt.host_load_avg_threshold_critical or
      -- use potential free memory snapshot for ballooning
      (dmc.has_memory_ballooning = true and dmc.potential_free_mem < pt.host_memory_threshold_critical) or
      (dmc.has_memory_ballooning = false and hm.avg_free_mem < pt.host_memory_threshold_critical) or
      hm.avg_net_read  > pt.host_net_read_threshold_critical or
      hm.avg_net_write > pt.host_net_write_threshold_critical)
      or (h.is_pool_master = true    -- pool master has exceed CPU limit
      and cast(pc1.value as decimal(9,5)) > 0
      and hm.avg_cpu >  cast(pc1.value as decimal(9,5)))
      or  vrs.poolid is not null
    ) -- exists in @vms_with_runstate
    and cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPoolOptimizations', 'false') as boolean) = false;


  -- RESULT SET 1 - Pools with the optimization mode set to max performance that have performance issues.
  open _ref_perf_pools_perf for
    select  ph.poolid,
      p.uuid as pool_uuid,
      p.name  as pool_name,
      p.hv_type,
      pc1.value as pool_master_cpu_limit,
      hm.host_id,
      h.uuid as host_uuid,
      h.name as host_name,
      h.is_pool_master,
      case lower(hc.value)
        when 'true'  then true
        when 'false' then false
        else false
      end as can_power,
      ph.fill_order,
      hm.total_mem,
      hm.avg_free_mem,
      hm.avg_cpu,
      hm.avg_net_read,
      hm.avg_net_write,
      hm.avg_load,
      hm.num_vms
    from _host_metrics hm
    join hv_host h      on (h.id = hm.host_id)
    join hv_pool_host ph    on (ph.hostid = hm.host_id)
    join hv_pool_threshold pt   on (pt.pool_id = ph.poolid)
    join hv_pool p      on (p.id = ph.poolid)
    join _pools_with_data pd  on (pd.pool_id = p.id)
    join hv_pool_config pc    on (pc.pool_id = p.id and pc.name = 'OptimizationMode')
    join hv_pool_config pc1   on (pc1.pool_id = p.id and pc1.name = 'PoolMasterCpuLimit')
    left join hv_host_config hc   on (hc.host_id = h.id and hc.name = 'ParticipatesInPowerManagement')
    left join _vms_with_runstate vrs on (h.id = vrs.hostid)
    where cast(pc.value as int) = _opt_mode_max_perf
    and ((  hm.avg_cpu > pt.host_cpu_threshold_high or
      hm.avg_load      > pt.host_load_avg_threshold_high or
      hm.avg_free_mem  < pt.host_memory_threshold_high   or
      hm.avg_net_read  > pt.host_net_read_threshold_high or
      hm.avg_net_write > pt.host_net_write_threshold_high)
      -- pool master has exceed CPU limit
      or (h.is_pool_master = true
        and cast(pc1.value as numeric(9,5)) > 0
        and hm.avg_cpu >  cast(pc1.value as numeric(9,5)))
      -- exists in _vms_with_runstate
      or  vrs.poolid is not null)
    and cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPoolOptimizations', 'false') as boolean) = false;
  return next _ref_perf_pools_perf;



  -- RESULT SET 2 - Pools with the optimization mode set to max density that have performance issues.
  open _ref_density_pools_perf for
    select  poolid,
      pool_uuid,
      pool_name,
      hv_type,
      pool_master_cpu_limit,
      host_id,
      host_uuid,
      host_name,
      is_pool_master,
      can_power,
      fill_order,
      total_mem,
      potential_free_mem,
      avg_free_mem,
      avg_cpu,
      avg_net_read,
      avg_net_write,
      avg_load,
      num_vms
    from _pool_density_perf_issue;
  return next _ref_density_pools_perf;


  -- RESULT SET 3- Pools with the optimization mode set to max density that have idle hosts.
  open _ref_density_pools_consolidate for
    select  distinct ph.poolid,
      p.uuid       as pool_uuid,
      p.name       as pool_name,
      p.hv_type,
      pc1.value    as pool_master_cpu_limit,
      hm.host_id,
      h.uuid       as host_uuid,
      h.name       as host_name,
      h.is_pool_master,
      case lower(hc.value)
        when 'true'  then true
        when 'false' then false
        else false
      end as can_power,
      ph.fill_order,
      hm.total_mem,
      hm.avg_free_mem,
      hm.avg_cpu,
      hm.avg_net_read,
      hm.avg_net_write,
      hm.avg_load,
      hm.num_vms
    from _host_metrics hm
    join hv_host           h  on (h.id = hm.host_id)
    join hv_pool_host      ph on (ph.hostid = hm.host_id)
    join hv_pool_threshold pt on (pt.pool_id = ph.poolid)
    join host_vm           hv on (hv.hostid = hm.host_id) -- need to have VMs on the host.
    join hv_pool           p  on (p.id = ph.poolid)
    join _pools_with_data  pd on (pd.pool_id = p.id)
    join hv_pool_config    pc on (pc.pool_id = p.id and pc.name = 'OptimizationMode')
    join hv_pool_config    pc1 on (pc1.pool_id = p.id and pc1.name = 'PoolMasterCpuLimit')
    left join hv_host_config hc on (hc.host_id = h.id and hc.name = 'ParticipatesInPowerManagement')
    where cast(pc.value as int) = _opt_mode_max_density
    --p.id in (select pool_id from @pools_with_data) and
    and ph.poolid not in (select poolid from _pool_density_perf_issue)
    and ( hm.avg_cpu < pt.host_cpu_threshold_low or
      hm.avg_free_mem  > pt.host_memory_threshold_low or
      hm.avg_net_read  < pt.host_net_read_threshold_low or
      hm.avg_net_write < pt.host_net_write_threshold_low)
    and cast("WorkloadBalancing".fn_get_host_config_value(h.id, 'ExcludeFromPoolOptimizations', 'false') as boolean) = false
    order by ph.fill_order desc;
  return next _ref_density_pools_consolidate;



  RETURN;
END;
$$ LANGUAGE plpgsql;

/*
begin;
select "WorkloadBalancing".ae_get_pools_in_trouble_bl();
fetch all from "<unnamed portal 24>";
*/

--==============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Project:    SQL
-- Module:       Citrix DWM Core Person Procedures
--
-- $LOG$
--
--==============================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".get_recommendations_for_pool_by_pool_id
(
  _pool_id       int,
  _poll_interval_seconds int
)
RETURNS SETOF refcursor AS $$

DECLARE
  _licensed   boolean := false;
  _is_licensed    refcursor;
  _recommendations  refcursor;
  _poll_interval interval;

BEGIN

  -- Get the poll interval for the analysis engine.  We only care about
  -- pools that have data newer than the last poll interval.
  _poll_interval := _poll_interval_seconds || ' seconds';

  _licensed := (select is_licensed
      from hv_pool
      where id=_pool_id);


  open _is_licensed for
    select _licensed as is_licensed;
  return next _is_licensed;

  if _licensed then
    open _recommendations for
      select  mr.id            as event_id,
        mrd.id           as recommendation_id,
        mr.poolid        as pool_id,
        mr.severity      as severity,
        mrd.vm_id        as vm_id,
        vm.uuid          as vm_uuid,
        vm.name          as vm_name,
        mrd.to_host_id   as move_to_host_id,
        hvhto.uuid       as move_to_host_uuid,
        hvhto.name       as move_to_host_name,
        mrd.from_host_id as move_from_host_id,
        hvhfrom.uuid     as move_from_host_uuid,
        hvhfrom.name     as move_from_host_name,
        mrd.reason       as reason_id,
        optr.reason      as reason,
        mr.tstamp        as move_recommendation_time_stamp
      from move_recommendation mr
        join move_recommendation_detail mrd on (mr.id = mrd.recommendation_id)
        join hv_pool  hvp on (hvp.id = mr.poolid)
        left join hv_host hvhfrom on (hvhfrom.id = mrd.from_host_id)
        left join hv_host hvhto on (hvhto.id = mrd.to_host_id)
        left join virtual_machine vm on (vm.id = mrd.vm_id)
        join (  select max(m.id) as id
          from move_recommendation m
          where m.type = 3
          group by m.poolid) recommendations on (mr.id = recommendations.id)
        left join optimize_reason optr on (mrd.reason = optr.id)
      where mr.type = 3
        and mr.tstamp > (select current_timestamp at time zone 'UTC'
              - _poll_interval)
         and hvp.id = _pool_id
         and hvp.is_licensed = true;
    return next _recommendations;
  end if;
  return;
END;

$$ LANGUAGE plpgsql;

/*
drop  FUNCTION "WorkloadBalancing".get_recommendations_for_pool_by_pool_id
(
  _pool_id       int
)

begin;
select get_recommendations_for_pool_by_pool_id(9999);
fetch all from "<unnamed portal 1>"
*/
-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:    Rabin Karki
-- Date:    Mar 10, 2011
-- Description:
--   Returns the content in hv_audit_log_event_action table
-- Parameters:
-- enabled: Specifies whether we want the enabled actions or the disabled ones
-- ============================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".hv_audit_log_get_event_actions_by_pool_id
(
  _pool_id int,
  out id bigint,
  out name varchar
) returns setof record as $$

declare
  _pool_audit_log_granularity  varchar;

begin
  select into _pool_audit_log_granularity value from hv_pool_config where hv_pool_config.pool_id=_pool_id and hv_pool_config.name = 'PoolAuditLogGranularity';
  return query (select ea_t.id , ea_t.name from hv_audit_log_event_action ea_t where ea_t.enabled = 't' and udf_getauditloglevel(ea_t.granularity) <= udf_getauditloglevel(_pool_audit_log_granularity));
end;
$$ language plpgsql;

-- ============================================================================
-- (c) Copyright 2009 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:    Rabin Karki
-- Date:    Mar 10, 2011
-- Description:
--   Returns the content in hv_audit_log_event_object table
-- Parameters:
-- enabled: Specifies whether we want the enabled objects or the disabled ones
-- ============================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".hv_audit_log_get_event_objects_by_pool_id
(
  _pool_id int,
  out id bigint,
  out name varchar
) returns setof record as $$

declare
  _pool_audit_log_granularity  varchar;

begin
  select into _pool_audit_log_granularity value from hv_pool_config where hv_pool_config.pool_id=_pool_id and hv_pool_config.name = 'PoolAuditLogGranularity';
  return query (select eo_t.id , eo_t.name from hv_audit_log_event_object eo_t where eo_t.enabled = 't' and udf_getauditloglevel(eo_t.granularity) <= udf_getauditloglevel(_pool_audit_log_granularity));
end;
$$ language plpgsql;

--==============================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Project:    SQL
-- Module:       Citrix DWM Core Person Procedures
--
-- $LOG$
--
--==============================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".get_recommendations_for_pool_by_pool_id
(
  _pool_id       int,
  _poll_interval_seconds int
)
RETURNS SETOF refcursor AS $$

DECLARE
  _licensed   boolean := false;
  _is_licensed    refcursor;
  _recommendations  refcursor;
  _poll_interval interval;

BEGIN

  -- Get the poll interval for the analysis engine.  We only care about
  -- pools that have data newer than the last poll interval.
  _poll_interval := _poll_interval_seconds || ' seconds';

  _licensed := (select is_licensed
      from hv_pool
      where hv_pool.id=_pool_id);


  open _is_licensed for
    select _licensed as is_licensed;
  return next _is_licensed;

  if _licensed then
    open _recommendations for
      select  mr.id            as event_id,
        mrd.id           as recommendation_id,
        mr.poolid        as pool_id,
        mr.severity      as severity,
        mrd.vm_id        as vm_id,
        vm.uuid          as vm_uuid,
        vm.name          as vm_name,
        mrd.to_host_id   as move_to_host_id,
        hvhto.uuid       as move_to_host_uuid,
        hvhto.name       as move_to_host_name,
        mrd.from_host_id as move_from_host_id,
        hvhfrom.uuid     as move_from_host_uuid,
        hvhfrom.name     as move_from_host_name,
        mrd.reason       as reason_id,
        optr.reason      as reason,
        mr.tstamp        as move_recommendation_time_stamp
      from move_recommendation mr
        join move_recommendation_detail mrd on (mr.id = mrd.recommendation_id)
        join hv_pool  hvp on (hvp.id = mr.poolid)
        left join hv_host hvhfrom on (hvhfrom.id = mrd.from_host_id)
        left join hv_host hvhto on (hvhto.id = mrd.to_host_id)
        left join virtual_machine vm on (vm.id = mrd.vm_id)
        join (  select max(m.id) as id
          from move_recommendation m
          where m.type = 3
          group by m.poolid) recommendations on (mr.id = recommendations.id)
        left join optimize_reason optr on (mrd.reason = optr.id)
      where mr.type = 3
        and mr.tstamp > (select current_timestamp at time zone 'UTC'
              - _poll_interval)
         and hvp.id = _pool_id
         and hvp.is_licensed = true;
    return next _recommendations;
  end if;
  return;
END;

$$ LANGUAGE plpgsql;

/*
drop  FUNCTION "WorkloadBalancing".get_recommendations_for_pool_by_pool_id
(
  _pool_id       int
)

begin;
select get_recommendations_for_pool_by_pool_id(9999);
fetch all from "<unnamed portal 1>"
*/

-- ==========================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:    John Cartales
-- Create date: December 9, 2008
-- Modified for
-- PosgtreSQL:  Deane Smith
-- On:    Jan 18, 2011
-- Description: Retrieve the stored procedure name required to run the report
--              identified by the specified report file name.
-- Parameters:
--     report_file - The RDLC file name for the report (report_file column of
--                   the report table) of the report whose stored proc name is
--                   to be retrieved.
-- Returns:
--   If successful, the stored proc name for the report.
-- ==========================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".report_get_sql_by_filename
(
  _report_file  varchar,
  _report_version varchar
)
RETURNS varchar AS $$
DECLARE
  _report_proc varchar := null;
BEGIN

  _report_version := lower(_report_version);
  _report_proc := (select report_proc from report where report_file = _report_file and report_version = _report_version);

  RETURN _report_proc;

END;
$$ LANGUAGE plpgsql;

DROP FUNCTION IF EXISTS report_get_sql_by_filename(_report_file varchar);

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:    Brian Donegan
-- Create date: October 21, 2009
-- Modified for PosgtreSQL: Deane Smith
-- On:        Jan 17, 2011
-- Description: Used to load the WlbReports collection object.
-- Returns:
--     Result set #1: Base data for each report
--     Result set #2: Localized report names for each report
--     Result set #3: Label names for each report
-- ==========================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".report_load_reports
(
  _report_version varchar
)
RETURNS SETOF refcursor AS $$
DECLARE
  _ref_report       refcursor;
  _ref_report_localized     refcursor;
  _ref_report_labels    refcursor;
BEGIN

  _report_version := lower(_report_version);

  -- first result set is the base report data
  open _ref_report for
    select * from report where report_version = _report_version;
  return next _ref_report;

  -- second result set is the localized report names
  open _ref_report_localized for
    select report_file,two_letter_code,report_name_localized
    from report
    join report_locale on (report.report_version = _report_version and report.repid = report_locale.repid);
  return next _ref_report_localized;

  -- Thirs result set is the report labels
  open _ref_report_labels for
    select report_file,label_name
    from report
    join report_label_map on (report.report_version = _report_version and report.repid = report_label_map.repid)
    join report_label on (report.report_version = _report_version and report_label_map.rlid = report_label.rlid);
  return next _ref_report_labels;

END;
$$
LANGUAGE 'plpgsql';
-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
-- Author:    Barbara Li
-- Create date: October 23, 2009
-- Modified for
-- PosgtreSQL:  Deane Smith
-- On:    Jan 28, 2011
-- Description: Returns dataset for the Pool Audit Trail History report
-- Parameters:
--  _pStart   Start date for data query
--  _pEnd     End date for data query
--  _pPoolID  uuid of pool
--  _pUTCOffset   UTC offset minutes
-- ==========================================================================

DROP TYPE IF EXISTS "WorkloadBalancing"."rp_pool_audit_history_type" CASCADE;

CREATE TYPE "WorkloadBalancing".rp_pool_audit_history_type AS (
  logtime timestamp without time zone,
  tstamp timestamp without time zone,
  id bigint,
  username varchar,
  usersid varchar,
  access boolean,
  eventobjectid integer,
  eventobject varchar,
  eventobjectname varchar,
  eventobjectuuid varchar,
  eventactionid integer,
  eventaction varchar,
  succeeded boolean,
  error varchar
);


CREATE OR REPLACE FUNCTION "WorkloadBalancing".rp_pool_audit_history
(
  _Start      varchar,
  _End      varchar,
  _PoolID     varchar,
  _UTCOffset    varchar
)
RETURNS SETOF rp_pool_audit_history_type AS $$
DECLARE
   r      rp_pool_audit_history_type%rowtype;
  _UTCNow     timestamp;
  _UTCStartDate   timestamp;
  _UTCEndDate   timestamp;
  _pStart     int;
  _pEnd       int;
  _pFilter    int;
  _pUTCOffset     int;
BEGIN

  _pStart := cast(_Start as integer);
  _pEnd := cast(_End as integer);
  _pUTCOffset := cast(_UTCOffset as integer);

  _UTCNow := getutcdate();
  _UTCStartDate :=  udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
  _UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);

  for r in

    select  udf_getlocaltime(hal.log_tstamp, _pUTCOffset) as logtime,
      udf_getlocaltime(hal.tstamp, _pUTCOffset) as tstamp,
      hal.id as id,
      hal.user_name as username,
      hal.user_sid as usersid,
      hal.access_allowed as access,
      -- hal.call_type calltype,
      hal.event_object as eventobjectid,
      haleo.name as eventobject,
      hal.event_object_name as eventobjectname,
      hal.event_object_uuid as eventobjectuuid,
      hal.event_action as eventactionid,
      halea.name as eventaction,
      hal.succeeded as succeeded,
      hal.error_info as error
    from hv_audit_log hal
      join hv_audit_log_event_object haleo on (hal.event_object = haleo.id)
      join hv_audit_log_event_action halea on (hal.event_action = halea.id)
      join hv_pool hp on (hal.pool_id = hp.id)
    where hal.log_tstamp between _UTCStartDate and _UTCEndDate
      and halea.name in (select name from hv_audit_log_event_action where granularity='Minimum')
      and haleo.name in (select name from hv_audit_log_event_object where granularity='Minimum')
      and hp.uuid = _PoolID
  loop
  return next r;
  end loop;

  RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
-- Author:    Barbara Li
-- Create date: October 23, 2009
-- Modified for
-- PosgtreSQL:  Deane Smith
-- On:    Jan 28, 2011
-- Description: Returns dataset for the Pool Audit Trail History report
-- Parameters:
--  _pStart   Start date for data query
--  _pEnd     End date for data query
--  _pPoolID  uuid of pool
--  _pUTCOffset   UTC offset minutes
-- ==========================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".rp_pool_audit_history2
(
  _Start      varchar,
  _End      varchar,
  _PoolID     varchar,
  _ReportVersion  varchar,
  _AuditUser      varchar,
  _AuditObject    varchar,
  _StartLine      varchar,
  _EndLine        varchar,
  _UTCOffset    varchar
)
RETURNS SETOF rp_pool_audit_history_type AS $$
DECLARE
   r      rp_pool_audit_history_type%rowtype;
  _UTCNow     timestamp;
  _UTCStartDate timestamp;
  _UTCEndDate   timestamp;
  _pStart     int;
  _pEnd       int;
  _pFilter    int;
  _pLimit     int;
  _pOffset        int;
  _pUTCOffset   int;
  _pool_id    int;
  _pool_audit_log_granularity varchar;
BEGIN

  _pStart := cast(_Start as integer);
  _pEnd := cast(_End as integer);
  _pUTCOffset := cast(_UTCOffset as integer);

  _UTCNow := getutcdate();
  _pStart := cast(_Start as double precision)::integer;
  _pEnd := cast(_End as double precision)::integer;

  if _pStart > 0 then
    _UTCStartDate := to_timestamp(cast(_pStart as double precision));
  else
    _UTCStartDate := udf_core_get_offset_date(_pStart, 1, 1, _UTCNow, _pUTCOffset);
  end if;

  if _pEnd > 0 then
    _UTCEndDate := to_timestamp(cast(_End as double precision));
  else
    _UTCEndDate := udf_core_get_offset_date(_pEnd, 0, 1, _UTCNow, _pUTCOffset);
  end if;

  _pLimit := cast(_EndLine as integer) - cast(_StartLine as integer) + 1;
  _pOffset := cast(_StartLine as integer) - 1;

  select into _pool_id hv_pool.id from hv_pool where hv_pool.uuid=_PoolID;
  select into _pool_audit_log_granularity value from hv_pool_config where hv_pool_config.pool_id=_pool_id and hv_pool_config.name = 'PoolAuditLogGranularity';

  if (_AuditUser = 'ALL') and (_AuditObject = 'ALL') then
    for r in

      select  udf_getlocaltime(hal.log_tstamp, _pUTCOffset) as logtime,
        udf_getlocaltime(hal.tstamp, _pUTCOffset) as tstamp,
        hal.id as id,
        hal.user_name as username,
        hal.user_sid as usersid,
        hal.access_allowed as access,
        -- hal.call_type calltype,
        hal.event_object as eventobjectid,
        haleo.name as eventobject,
        hal.event_object_name as eventobjectname,
        hal.event_object_uuid as eventobjectuuid,
        hal.event_action as eventactionid,
        halea.name as eventaction,
        hal.succeeded as succeeded,
        hal.error_info as error
      from hv_audit_log hal
        join hv_audit_log_event_object haleo on (hal.event_object = haleo.id)
        join hv_audit_log_event_action halea on (hal.event_action = halea.id)
        join hv_pool hp on (hal.pool_id = hp.id)
      where hal.log_tstamp between _UTCStartDate and _UTCEndDate
        and hal.user_name like '%'
        and haleo.name in (select name from hv_audit_log_event_object where enabled='t' and udf_getauditloglevel(granularity) <= udf_getauditloglevel(_pool_audit_log_granularity))
        and halea.name in (select name from hv_audit_log_event_action where enabled='t' and udf_getauditloglevel(granularity) <= udf_getauditloglevel(_pool_audit_log_granularity))
        and hp.uuid = _PoolID
      order by hal.log_tstamp desc
      limit _pLimit
      offset _pOffset
    loop
    return next r;
    end loop;
  end if;

  if (_AuditUser = 'ALL') and (_AuditObject <> 'ALL') then
    for r in

      select  udf_getlocaltime(hal.log_tstamp, _pUTCOffset) as logtime,
        udf_getlocaltime(hal.tstamp, _pUTCOffset) as tstamp,
        hal.id as id,
        hal.user_name as username,
        hal.user_sid as usersid,
        hal.access_allowed as access,
        -- hal.call_type calltype,
        hal.event_object as eventobjectid,
        haleo.name as eventobject,
        hal.event_object_name as eventobjectname,
        hal.event_object_uuid as eventobjectuuid,
        hal.event_action as eventactionid,
        halea.name as eventaction,
        hal.succeeded as succeeded,
        hal.error_info as error
      from hv_audit_log hal
        join hv_audit_log_event_object haleo on (hal.event_object = haleo.id)
        join hv_audit_log_event_action halea on (hal.event_action = halea.id)
        join hv_pool hp on (hal.pool_id = hp.id)
      where hal.log_tstamp between _UTCStartDate and _UTCEndDate
        and hal.user_name like '%'
        and haleo.name = _AuditObject
        and halea.name in (select name from hv_audit_log_event_action where enabled='t' and udf_getauditloglevel(granularity) <= udf_getauditloglevel(_pool_audit_log_granularity))
        and hp.uuid = _PoolID
      order by hal.log_tstamp desc
      limit _pLimit
      offset _pOffset
    loop
    return next r;
    end loop;
  end if;

  if (_AuditUser <> 'ALL') and (_AuditObject = 'ALL') then
    for r in

      select  udf_getlocaltime(hal.log_tstamp, _pUTCOffset) as logtime,
        udf_getlocaltime(hal.tstamp, _pUTCOffset) as tstamp,
        hal.id as id,
        hal.user_name as username,
        hal.user_sid as usersid,
        hal.access_allowed as access,
        -- hal.call_type calltype,
        hal.event_object as eventobjectid,
        haleo.name as eventobject,
        hal.event_object_name as eventobjectname,
        hal.event_object_uuid as eventobjectuuid,
        hal.event_action as eventactionid,
        halea.name as eventaction,
        hal.succeeded as succeeded,
        hal.error_info as error
      from hv_audit_log hal
        join hv_audit_log_event_object haleo on (hal.event_object = haleo.id)
        join hv_audit_log_event_action halea on (hal.event_action = halea.id)
        join hv_pool hp on (hal.pool_id = hp.id)
      where hal.log_tstamp between _UTCStartDate and _UTCEndDate
        and case when (hal.user_name='') or (hal.user_name like 'OpaqueRef:%') then hal.user_sid else hal.user_name end = _AuditUser
        and haleo.name in (select name from hv_audit_log_event_object where enabled='t' and udf_getauditloglevel(granularity) <= udf_getauditloglevel(_pool_audit_log_granularity))
        and halea.name in (select name from hv_audit_log_event_action where enabled='t' and udf_getauditloglevel(granularity) <= udf_getauditloglevel(_pool_audit_log_granularity))
        and hp.uuid = _PoolID
      order by hal.log_tstamp desc
      limit _pLimit
      offset _pOffset
    loop
    return next r;
    end loop;
  end if;

  if (_AuditUser <> 'ALL') and (_AuditObject <> 'ALL') then
    for r in

      select  udf_getlocaltime(hal.log_tstamp, _pUTCOffset) as logtime,
        udf_getlocaltime(hal.tstamp, _pUTCOffset) as tstamp,
        hal.id as id,
        hal.user_name as username,
        hal.user_sid as usersid,
        hal.access_allowed as access,
        -- hal.call_type calltype,
        hal.event_object as eventobjectid,
        haleo.name as eventobject,
        hal.event_object_name as eventobjectname,
        hal.event_object_uuid as eventobjectuuid,
        hal.event_action as eventactionid,
        halea.name as eventaction,
        hal.succeeded as succeeded,
        hal.error_info as error
      from hv_audit_log hal
        join hv_audit_log_event_object haleo on (hal.event_object = haleo.id)
        join hv_audit_log_event_action halea on (hal.event_action = halea.id)
        join hv_pool hp on (hal.pool_id = hp.id)
      where hal.log_tstamp between _UTCStartDate and _UTCEndDate
        and case when (hal.user_name='') or (hal.user_name like 'OpaqueRef:%') then hal.user_sid else hal.user_name end = _AuditUser
        and haleo.name = _AuditObject
        and halea.name in (select name from hv_audit_log_event_action where enabled='t' and udf_getauditloglevel(granularity) <= udf_getauditloglevel(_pool_audit_log_granularity))
        and hp.uuid = _PoolID
      order by hal.log_tstamp desc
      limit _pLimit
      offset _pOffset
    loop
    return next r;
    end loop;
  end if;

  RETURN;
END;
$$ LANGUAGE plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
-- Author:    Phus Lu
-- Create date: July 8, 2014
-- Modified for
-- PosgtreSQL:  Deane Smith
-- On:    July 8, 2014
-- Description: Returns Audit Objects for the Pool Audit Trail History report
-- ==========================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".rp_pool_audit_history_get_objects_by_pool_uuid
(
  _pool_uuid  varchar,
  out name varchar
) returns setof varchar as $$

declare
  _pool_id int;
  _pool_audit_log_granularity varchar;

begin
  select into _pool_id hv_pool.id from hv_pool where hv_pool.uuid=_pool_uuid;
  select into _pool_audit_log_granularity value from hv_pool_config where hv_pool_config.pool_id = _pool_id and hv_pool_config.name = 'PoolAuditLogGranularity';
  return query (select eo_t.name from hv_audit_log_event_object eo_t where eo_t.enabled = 't' and udf_getauditloglevel(eo_t.granularity) <= udf_getauditloglevel(_pool_audit_log_granularity));
end;
$$ language plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
-- Author:    Phus Lu
-- Create date: July 8, 2014
-- Modified for
-- PosgtreSQL:  Deane Smith
-- On:    July 8, 2014
-- Description: Returns Audit Users for the Pool Audit Trail History report
-- ==========================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".rp_pool_audit_history_get_users_by_pool_uuid
(
  _pool_uuid  varchar,
  out name varchar
) returns setof varchar as $$

declare
  _pool_id int;

begin
  select into _pool_id hv_pool.id from hv_pool where hv_pool.uuid=_pool_uuid;
  return query (
          select distinct
          case when (user_name='') or (user_name like 'OpaqueRef:%') then user_sid
             else user_name
          end
          as name
          from hv_audit_log
          where (user_sid != '' or user_name != '')
            and hv_audit_log.pool_id=_pool_id
         );
end;
$$ language plpgsql;

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:    Brian Donegan
-- Create date: October 21, 2009
-- Modified for PosgtreSQL: Deane Smith
-- On:        Jan 17, 2011
-- Description: Updates a report's query_parameter and report_rdlc fields.
--              Used by the ReportUpload utility.
-- Parameters:
--     report_file - The internal name of the report
--     report_proc - The stored procedure used to populate the report
--     report_path - The physical path tot he report on the WLB server
--     query_parameters - A comma-seperated list of query parameters required by the report
--     report_rdlc - the "RDLC" XML describing the report
--     localized_report_names - A comma separated list of localized report names
--          ** each report name is in the format [two letter code]|[report name]
--     report_labels - A comma separated list of label codes used in the report

-- Modified by: Barbara Li
-- Modified date: February 25, 2010
--     added: report_parameters
--     report_parameters - A comma-seperated list of report parameters required by the report
-- ==========================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".report_upload_report
(
  _report_file      varchar,
  _report_proc      varchar,
  _report_path      varchar,
  _query_parameters     varchar,
  _report_parameters    varchar,
  _report_rdlc      text,
  _report_name_label    varchar,
  _report_labels      varchar,
  _report_version     varchar
)
RETURNS void AS
$$
declare _report_id int := null;
BEGIN

  _report_version := lower(_report_version);

  if exists(select * from report where report_file = _report_file and report_version = _report_version)
  then

    select repid into _report_id from report where report_file = _report_file and report_version = _report_version;

    update report
    set report_path = _report_path,
      query_parameters = _query_parameters,
      report_parameters = _report_parameters,
      report_rdlc = _report_rdlc
    where repid = _report_id;
  else
    insert into report
    (
      report_file,
      report_version,
      report_type,
                  report_proc,
                  report_path,
                  pid,
                  private,
                  custom,
                  req_features,
                  query_parameters,
                  report_parameters,
                  report_rdlc
    )
    values
    (
      _report_file,
      _report_version,
                  0,
                  _report_proc,
                  _report_path,
                  NULL,
                  0,
                  0,
                  0,
                  _query_parameters,
                  _report_parameters,
                  _report_rdlc
    )
    returning repid into _report_id;

  end if;

  -- Clean out existing labels
  delete from report_label_map where repid = _report_id;

  -- Add the supplied labels to the report label map
  insert into report_label_map (repid, rlid)
    select _report_id as repid, report_label.rlid
    from udf_core_array_to_table(_report_labels, ',') as report_labels
    join report_label on report_labels.fld = report_label.label_name;

  -- Clean out the existing report names
  delete from report_locale where repid = _report_id;


  -- Add the new report name(s)
  insert into report_locale (repid, two_letter_code, report_name_localized, report_desc_localized)
    select _report_id, rll.two_letter_code as two_letter_code,
    rll.description as report_name_localized, '' as report_desc_localized
    from report_label_locale rll
    join report_label rl on (rll.rlid = rl.rlid)
    where rl.label_name = _report_name_label;


END;
$$ LANGUAGE 'plpgsql';

DROP FUNCTION IF EXISTS report_upload_report(_report_file varchar, _report_proc varchar, _report_path varchar, _query_parameters varchar, _report_parameters varchar, _report_rdlc text, _report_name_label varchar, _report_labels varchar);

-- ==========================================================================
-- (c) Copyright 2010 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Updated: Dec 11 2010
--    Converted to PostGreSQL
-- Description: Converts string to table
-- Parameters:
--   None
-- Returns:
--   Nothing
-- ==========================================================================

CREATE OR REPLACE FUNCTION "WorkloadBalancing".udf_getauditloglevel
(
  _granularity  varchar
)
RETURNS integer AS $$

BEGIN

  if _granularity = 'Minimum' then
    return 10;
  elseif _granularity = 'Medium' then
    return 20;
  elseif _granularity = 'Maximum' then
    return 30;
  elseif _granularity = 'Full' then
    return 40;
  else
    return 0;
  end if;

END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- (c) Copyright 2008 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:      John Cartales
-- Create date:     June 18, 2008
-- Modified for PosgtreSQL: Rabin Karki
-- On:        Oct 20, 2010
-- Description:
--   Add or update a record in the virtual_machine table.
-- Parameters:
--   uuid                       - The unique ID of the virtual machine to add
--                                or update.
--   name                       - The name of the virtual machine.
--   description                - Description of the virtual machine.
--   host_affinity              - The internal, database ID, of the host to
--                                to which the virtual machine has affinity.
--   min_dynamic_memory         - The minimum amount of dynamic memory, in
--                                bytes required by the VM.
--   max_dynamic_memory         - The maximum amount of dynamic memory, in
--                                bytes that can be used by the VM.
--   min_static_memory          - The minimum amount of static memory, in
--                                bytes required by the VM.
--   max_static_memory          - The maximum amount of static memory, in
--                                bytes that can be used by VM.
--   target_memory              - The memory target, in bytes for the VM.
--   memory_overhead            - The amount of hypervisor memory overhead,
--                                in bytes, for the VM.
--   min_cpus                   - The minimum number of CPUs required by the VM.
--   hv_mem_multiplier          - The multiplier that needs to be applied to the
--                                VM's hypervisor memory overhead.
--   poolid                     - The internal, database ID of the pool to
--                                which the VM belongs.
--   is_control_domain      - Flag to indicate if the VM is a control
--                  domain or root partition.
--   is_agile                   - Flag to indicate if the VM can migrate between
--                                physical hosts.
--   drivers_up_to_date         - Flag to indicate if the virtual drivers are up
--                                to date for this VM.
--   active                     - Flag to indicate if the VM is still part of
--                  pool.  VMs that have been removed from a pool
--                  are not deleted from Kirkwood.  They are
--                  marked as inactive.
-- Returns:
--   The database ID of the (virtual_machine.id) of the record.
-- ============================================================================

create or replace function "WorkloadBalancing".add_update_virtual_machine
(
  _uuid               varchar,
  _name               varchar,
  _description        varchar,
  _host_affinity      int,
  _min_dynamic_memory bigint,
  _max_dynamic_memory bigint,
  _min_static_memory  bigint,
  _max_static_memory  bigint,
  _target_memory      bigint,
  _memory_overhead    bigint,
  _hv_mem_multiplier  decimal(7,2),
  _min_cpus           int,
  _poolid             int,
  _is_control_domain  boolean,
  _is_agile           boolean,
  _drivers_up_to_date boolean,
  _active             boolean
) returns int as $$

declare
  _id int := null;
begin

  select id into _id from virtual_machine where uuid=_uuid and poolid=_poolid;

  _description := substr(_description, 0, 1024);

  if _id is not null then
    update virtual_machine set name=_name,
       description=_description,
       host_affinity=_host_affinity,
       min_dynamic_memory=_min_dynamic_memory,
       max_dynamic_memory=_max_dynamic_memory,
       min_static_memory=_min_static_memory,
       max_static_memory=_max_static_memory,
       target_memory=_target_memory,
       memory_overhead=_memory_overhead,
       min_cpus=_min_cpus,
       hv_memory_multiplier=_hv_mem_multiplier,
       is_control_domain=_is_control_domain,
       is_agile=_is_agile,
       drivers_up_to_date=_drivers_up_to_date,
       active=_active
    where id=_id;
  else
    insert into virtual_machine (name,
      uuid,
      description,
      host_affinity,
      min_dynamic_memory,
      max_dynamic_memory,
      min_static_memory,
      max_static_memory,
      target_memory,
      memory_overhead,
      min_cpus,
      hv_memory_multiplier,
      poolid,
      is_control_domain,
      is_agile,
      drivers_up_to_date,
      active)
       values(_name,
      _uuid,
      _description,
      _host_affinity,
      _min_dynamic_memory,
      _max_dynamic_memory,
      _min_static_memory,
      _max_static_memory,
      _target_memory,
      _memory_overhead,
      _min_cpus,
      _hv_mem_multiplier,
      _poolid,
      _is_control_domain,
      _is_agile,
      _drivers_up_to_date,
      _active);
  end if;

  select id into _id from virtual_machine where uuid=_uuid and poolid=_poolid;
  return _id;
end;
$$ language plpgsql;


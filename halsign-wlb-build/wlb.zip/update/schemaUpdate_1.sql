﻿-- ============================================================================
-- (c) Copyright 2012 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Date:		Mar 10, 2012
-- Description:
--	 Schema update script
-- ============================================================================

ALTER TABLE "WorkloadBalancing"."report_label"
  DROP COLUMN IF EXISTS "flags";

DROP TABLE IF EXISTS "WorkloadBalancing"."rs_report";

ALTER TABLE "WorkloadBalancing"."hv_audit_log"
  ALTER COLUMN "error_info" TYPE VARCHAR(1024);

ALTER TABLE "WorkloadBalancing".hv_pool
  ADD COLUMN "discovery_status" INTEGER;

ALTER TABLE "WorkloadBalancing".hv_pool
  ALTER COLUMN "discovery_status" SET DEFAULT 0;

ALTER TABLE "WorkloadBalancing".hv_pool
  ADD COLUMN "last_discovery_completed" TIMESTAMP WITHOUT TIME ZONE;

ALTER TABLE "WorkloadBalancing".storage_repository
  ADD COLUMN "pool_default_sr" BOOLEAN DEFAULT false NOT NULL;

ALTER TABLE "WorkloadBalancing"."vbd"
  ALTER COLUMN device_name type varchar(256);
  
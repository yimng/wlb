-- ============================================================================
-- (c) Copyright 2012 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:    Phus Lu
-- Date:    Aug 5, 2014
-- Description:
--	 Post-database-update script
-- ============================================================================

delete from hv_audit_log_event_object;
delete from hv_audit_log_event_action;

CREATE FUNCTION "WorkloadBalancing"."add_audit_log_object"
(
  _name varchar,
  _granularity varchar,
  _enabled boolean,
  _description varchar default null
)
RETURNS void AS
$$
BEGIN
	if not exists(select * from hv_audit_log_event_object where name=_name)
    then
		insert into hv_audit_log_event_object (name, description, granularity, enabled) values(_name, _description, _granularity, _enabled);
	end if;
END;
$$ LANGUAGE 'plpgsql';

CREATE FUNCTION "WorkloadBalancing"."add_audit_log_action"
(
  _name varchar,
  _granularity varchar,
  _enabled boolean,
  _description varchar default null
)
RETURNS void AS
$$
BEGIN
	if not exists(select * from hv_audit_log_event_action where name=_name)
    then
		insert into hv_audit_log_event_action (name, description, granularity, enabled) values(_name, _description, _granularity, _enabled);
	end if;
END;
$$ LANGUAGE 'plpgsql';

-- These are the audit log objects and actions
-- If you want more actions or objects set the enabled flag to true
-- Minimum Objects
select * from add_audit_log_object('host', 'Minimum', true);
select * from add_audit_log_object('vm', 'Minimum', true);
select * from add_audit_log_object('pool', 'Minimum', true);

-- Normal Objects
select * from add_audit_log_object('bond', 'Medium', true);
select * from add_audit_log_object('host_patch', 'Medium', true);
select * from add_audit_log_object('network', 'Medium', true);
select * from add_audit_log_object('pbd', 'Medium', true);
select * from add_audit_log_object('pif', 'Medium', true);
select * from add_audit_log_object('pool_patch', 'Medium', true);
select * from add_audit_log_object('session', 'Medium', true);
select * from add_audit_log_object('sr', 'Medium', true);
select * from add_audit_log_object('subject', 'Medium', true);
select * from add_audit_log_object('vdi', 'Medium', true);
select * from add_audit_log_object('vif', 'Medium', true);
select * from add_audit_log_object('vlan', 'Medium', true);

-- Maximum Objects
select * from add_audit_log_object('dr_task', 'Maximum', true);
select * from add_audit_log_object('auth', 'Maximum', true);
select * from add_audit_log_object('role', 'Maximum', true);
select * from add_audit_log_object('blob', 'Maximum', true);
select * from add_audit_log_object('crashdump', 'Maximum', true);
select * from add_audit_log_object('host_crashdump', 'Maximum', true);
select * from add_audit_log_object('message', 'Maximum', true);
select * from add_audit_log_object('task', 'Maximum', true);
select * from add_audit_log_object('event', 'Maximum', true);
select * from add_audit_log_object('tunnel', 'Maximum', true);
select * from add_audit_log_object('vbd', 'Maximum', true);
select * from add_audit_log_object('vmpp', 'Maximum', true);
select * from add_audit_log_object('vm_appliance', 'Maximum', true);
select * from add_audit_log_object('gpu_group', 'Maximum', true);
select * from add_audit_log_object('pgpu', 'Maximum', true);
select * from add_audit_log_object('vgpu', 'Maximum', true);
select * from add_audit_log_object('vtpm', 'Maximum', true);
select * from add_audit_log_object('user', 'Maximum', true);
select * from add_audit_log_object('host_cpu', 'Maximum', true);
select * from add_audit_log_object('console', 'Maximum', true);
select * from add_audit_log_object('secret', 'Maximum', true);
select * from add_audit_log_object('data_source', 'Maximum', true);
select * from add_audit_log_object('vgpu_type', 'Maximum', true);
select * from add_audit_log_object('pci', 'Maximum', true);

-- Full Objects
select * from add_audit_log_object('vbd_metrics', 'Full', false);
select * from add_audit_log_object('vif_metrics', 'Full', false);
select * from add_audit_log_object('vm_guest_metrics', 'Full', false);
select * from add_audit_log_object('vm_metrics', 'Full', false);
select * from add_audit_log_object('host_metrics', 'Full', false);
select * from add_audit_log_object('pif_metrics', 'Full', false);
select * from add_audit_log_object('sm', 'Full', false);


-- Minimum Actions
select * from add_audit_log_action('clean_reboot', 'Minimum', true);
select * from add_audit_log_action('clone', 'Minimum', true);
select * from add_audit_log_action('copy', 'Minimum', true);
select * from add_audit_log_action('create_vlan', 'Minimum', true);
select * from add_audit_log_action('disable', 'Minimum', true);
select * from add_audit_log_action('disable_ha', 'Minimum', true);
select * from add_audit_log_action('enable', 'Minimum', true);
select * from add_audit_log_action('enable_ha', 'Minimum', true);
select * from add_audit_log_action('hard_reboot', 'Minimum', true);
select * from add_audit_log_action('hard_shutdown', 'Minimum', true);
select * from add_audit_log_action('join', 'Minimum', true);
select * from add_audit_log_action('join_force', 'Minimum', true);
select * from add_audit_log_action('pool_migrate', 'Minimum', true);
select * from add_audit_log_action('reboot', 'Minimum', true);
select * from add_audit_log_action('snapshot', 'Minimum', true);
select * from add_audit_log_action('snapshot_with_quiesce', 'Minimum', true);
select * from add_audit_log_action('start', 'Minimum', true);
select * from add_audit_log_action('start_on', 'Minimum', true);
select * from add_audit_log_action('suspend', 'Minimum', true);
select * from add_audit_log_action('clean_shutdown', 'Minimum', true);
select * from add_audit_log_action('create', 'Minimum', true);
select * from add_audit_log_action('destroy', 'Minimum', true);
select * from add_audit_log_action('forget', 'Minimum', true);
select * from add_audit_log_action('shutdown', 'Minimum', true);

-- Normal Actions
select * from add_audit_log_action('add_to_roles', 'Medium', true);
select * from add_audit_log_action('apply', 'Medium', true);
select * from add_audit_log_action('apply_edition', 'Medium', true);
select * from add_audit_log_action('backup_rrds', 'Medium', true);
select * from add_audit_log_action('bugreport_upload', 'Medium', true);
select * from add_audit_log_action('call_plugin', 'Medium', true);
select * from add_audit_log_action('certificate_install', 'Medium', true);
select * from add_audit_log_action('certificate_sync', 'Medium', true);
select * from add_audit_log_action('certificate_uninstall', 'Medium', true);
select * from add_audit_log_action('change_password', 'Medium', true);
select * from add_audit_log_action('checkpoint', 'Medium', true);
select * from add_audit_log_action('clean', 'Medium', true);
select * from add_audit_log_action('clean_on_host', 'Medium', true);
select * from add_audit_log_action('create_vlan_from_pif', 'Medium', true);
select * from add_audit_log_action('crl_install', 'Medium', true);
select * from add_audit_log_action('crl_uninstall', 'Medium', true);
select * from add_audit_log_action('db_forget', 'Medium', true);
select * from add_audit_log_action('db_introduce', 'Medium', true);
select * from add_audit_log_action('declare_dead', 'Medium', true);
select * from add_audit_log_action('deconfigure_wlb', 'Medium', true);
select * from add_audit_log_action('designate_new_master', 'Medium', true);
select * from add_audit_log_action('disable_external_auth', 'Medium', true);
select * from add_audit_log_action('disable_local_storage_caching', 'Medium', true);
select * from add_audit_log_action('disable_redo_log', 'Medium', true);
select * from add_audit_log_action('dmesg', 'Medium', true);
select * from add_audit_log_action('dmesg_clear', 'Medium', true);
select * from add_audit_log_action('eject', 'Medium', true);
select * from add_audit_log_action('emergency_ha_disable', 'Medium', true);
select * from add_audit_log_action('emergency_reset_master', 'Medium', true);
select * from add_audit_log_action('emergency_transition_to_master', 'Medium', true);
select * from add_audit_log_action('enable_external_auth', 'Medium', true);
select * from add_audit_log_action('enable_local_storage_caching', 'Medium', true);
select * from add_audit_log_action('enable_redo_log', 'Medium', true);
select * from add_audit_log_action('evacuate', 'Medium', true);
select * from add_audit_log_action('get_possible_hosts', 'Medium', true);
select * from add_audit_log_action('initialize_wlb', 'Medium', true);
select * from add_audit_log_action('introduce', 'Medium', true);
select * from add_audit_log_action('license_apply', 'Medium', true);
select * from add_audit_log_action('local_logout', 'Medium', true);
select * from add_audit_log_action('local_management_reconfigure', 'Medium', true);
select * from add_audit_log_action('login_with_password', 'Medium', true);
select * from add_audit_log_action('logout', 'Medium', true);
select * from add_audit_log_action('logout_subject_identifier', 'Medium', true);
select * from add_audit_log_action('management_disable', 'Medium', true);
select * from add_audit_log_action('management_reconfigure', 'Medium', true);
select * from add_audit_log_action('maximise_memory', 'Medium', true);
select * from add_audit_log_action('pause', 'Medium', true);
select * from add_audit_log_action('plug', 'Medium', true);
select * from add_audit_log_action('pool_apply', 'Medium', true);
select * from add_audit_log_action('pool_clean', 'Medium', true);
select * from add_audit_log_action('power_on', 'Medium', true);
select * from add_audit_log_action('power_state_reset', 'Medium', true);
select * from add_audit_log_action('precheck', 'Medium', true);
select * from add_audit_log_action('provision', 'Medium', true);
select * from add_audit_log_action('reconfigure_ip', 'Medium', true);
select * from add_audit_log_action('reconfigure_ipv6', 'Medium', true);
select * from add_audit_log_action('recover', 'Medium', true);
select * from add_audit_log_action('recover_slaves', 'Medium', true);
select * from add_audit_log_action('remove_from_roles', 'Medium', true);
select * from add_audit_log_action('reset_cpu_features', 'Medium', true);
select * from add_audit_log_action('resize', 'Medium', true);
select * from add_audit_log_action('resize_online', 'Medium', true);
select * from add_audit_log_action('restart_agent', 'Medium', true);
select * from add_audit_log_action('resume', 'Medium', true);
select * from add_audit_log_action('resume_on', 'Medium', true);
select * from add_audit_log_action('retrieve_wlb_recommendations', 'Full', true);
select * from add_audit_log_action('revert', 'Medium', true);
select * from add_audit_log_action('send_wlb_configuration', 'Medium', true);
select * from add_audit_log_action('set_allow_caching', 'Medium', true);
select * from add_audit_log_action('set_cpu_features', 'Medium', true);
select * from add_audit_log_action('set_default_locking_mode', 'Medium', true);
select * from add_audit_log_action('set_device_config', 'Medium', true);
select * from add_audit_log_action('set_ha_always_run', 'Medium', true);
select * from add_audit_log_action('set_ha_host_failures_to_tolerate', 'Medium', true);
select * from add_audit_log_action('set_ha_restart_priority', 'Medium', true);
select * from add_audit_log_action('set_hostname_live', 'Medium', true);
select * from add_audit_log_action('set_is_a_snapshot', 'Medium', true);
select * from add_audit_log_action('set_managed', 'Medium', true);
select * from add_audit_log_action('set_memory_dynamic_max', 'Medium', true);
select * from add_audit_log_action('set_memory_dynamic_min', 'Medium', true);
select * from add_audit_log_action('set_memory_dynamic_range', 'Medium', true);
select * from add_audit_log_action('set_memory_limits', 'Medium', true);
select * from add_audit_log_action('set_memory_static_max', 'Medium', true);
select * from add_audit_log_action('set_memory_static_min', 'Medium', true);
select * from add_audit_log_action('set_memory_static_range', 'Medium', true);
select * from add_audit_log_action('set_memory_target_live', 'Medium', true);
select * from add_audit_log_action('set_metadata_of_pool', 'Medium', true);
select * from add_audit_log_action('set_missing', 'Medium', true);
select * from add_audit_log_action('set_on_boot', 'Medium', true);
select * from add_audit_log_action('set_physical_utilisation', 'Full', true);
select * from add_audit_log_action('set_power_on_mode', 'Medium', true);
select * from add_audit_log_action('set_primary_address_type', 'Medium', true);
select * from add_audit_log_action('set_property', 'Medium', true);
select * from add_audit_log_action('set_read_only', 'Medium', true);
select * from add_audit_log_action('set_sharable', 'Medium', true);
select * from add_audit_log_action('set_shared', 'Medium', true);
select * from add_audit_log_action('set_snapshot_of', 'Medium', true);
select * from add_audit_log_action('set_snapshot_time', 'Medium', true);
select * from add_audit_log_action('set_virtual_size', 'Medium', true);
select * from add_audit_log_action('set_vswitch_controller', 'Medium', true);
select * from add_audit_log_action('shutdown_agent', 'Medium', true);
select * from add_audit_log_action('slave_local_login_with_password', 'Medium', true);
select * from add_audit_log_action('sync_data', 'Medium', true);
select * from add_audit_log_action('syslog_reconfigure', 'Medium', true);
select * from add_audit_log_action('unpause', 'Medium', true);
select * from add_audit_log_action('unplug', 'Medium', true);
select * from add_audit_log_action('unplug_force', 'Medium', true);
select * from add_audit_log_action('update', 'Medium', true);
select * from add_audit_log_action('set_actions_after_crash', 'Medium', true);
select * from add_audit_log_action('set_actions_after_reboot', 'Medium', true);
select * from add_audit_log_action('set_actions_after_shutdown', 'Medium', true);
select * from add_audit_log_action('set_address', 'Medium', true);
select * from add_audit_log_action('set_affinity', 'Medium', true);
select * from add_audit_log_action('set_allocation_algorithm', 'Medium', true);
select * from add_audit_log_action('set_backup_type', 'Medium', true);
select * from add_audit_log_action('set_blocked_operations', 'Medium', true);
select * from add_audit_log_action('set_bootable', 'Medium', true);
select * from add_audit_log_action('set_crash_dump_sr', 'Medium', true);
select * from add_audit_log_action('set_default_sr', 'Medium', true);
select * from add_audit_log_action('set_disallow_unplug', 'Medium', true);
select * from add_audit_log_action('set_fullname', 'Medium', true);
select * from add_audit_log_action('set_guest_vcpus_params', 'Medium', true);
select * from add_audit_log_action('set_gui_config', 'Medium', true);
select * from add_audit_log_action('set_ha_allow_overcommit', 'Medium', true);
select * from add_audit_log_action('set_hostname', 'Medium', true);
select * from add_audit_log_action('set_hvm_boot_params', 'Medium', true);
select * from add_audit_log_action('set_hvm_boot_policy', 'Medium', true);
select * from add_audit_log_action('set_is_a_template', 'Medium', true);
select * from add_audit_log_action('set_is_policy_enabled', 'Medium', true);
select * from add_audit_log_action('set_license_server', 'Medium', true);
select * from add_audit_log_action('set_logging', 'Medium', true);
select * from add_audit_log_action('set_mode', 'Medium', true);
select * from add_audit_log_action('set_mtu', 'Medium', true);
select * from add_audit_log_action('set_name_description', 'Medium', true);
select * from add_audit_log_action('set_name_label', 'Medium', true);
select * from add_audit_log_action('set_other_config', 'Medium', true);
select * from add_audit_log_action('set_pci_bus', 'Medium', true);
select * from add_audit_log_action('set_platform', 'Medium', true);
select * from add_audit_log_action('set_public', 'Medium', true);
select * from add_audit_log_action('set_pv_args', 'Medium', true);
select * from add_audit_log_action('set_pv_bootloader', 'Medium', true);
select * from add_audit_log_action('set_pv_bootloader_args', 'Medium', true);
select * from add_audit_log_action('set_pv_kernel', 'Medium', true);
select * from add_audit_log_action('set_pv_legacy_args', 'Medium', true);
select * from add_audit_log_action('set_pv_ramdisk', 'Medium', true);
select * from add_audit_log_action('set_qos_algorithm_params', 'Medium', true);
select * from add_audit_log_action('set_qos_algorithm_type', 'Medium', true);
select * from add_audit_log_action('set_recommendations', 'Medium', true);
select * from add_audit_log_action('set_sm_config', 'Medium', true);
select * from add_audit_log_action('set_status', 'Medium', true);
select * from add_audit_log_action('set_suspend_image_sr', 'Medium', true);
select * from add_audit_log_action('set_suspend_sr', 'Medium', true);
select * from add_audit_log_action('set_tags', 'Medium', true);
select * from add_audit_log_action('set_type', 'Medium', true);
select * from add_audit_log_action('set_unpluggable', 'Medium', true);
select * from add_audit_log_action('set_user_version', 'Medium', true);
select * from add_audit_log_action('set_userdevice', 'Medium', true);
select * from add_audit_log_action('set_value', 'Medium', true);
select * from add_audit_log_action('set_vcpus_params', 'Medium', true);
select * from add_audit_log_action('set_wlb_enabled', 'Medium', true);
select * from add_audit_log_action('set_wlb_verify_cert', 'Medium', true);
select * from add_audit_log_action('set_xenstore_data', 'Medium', true);

-- Maximum Actions
select * from add_audit_log_action('add_enabled_vgpu_types', 'Maximum', true);
select * from add_audit_log_action('add_ipv4_allowed', 'Maximum', true);
select * from add_audit_log_action('add_ipv6_allowed', 'Maximum', true);
select * from add_audit_log_action('add_to_alarm_config', 'Maximum', true);
select * from add_audit_log_action('add_to_archive_schedule', 'Maximum', true);
select * from add_audit_log_action('add_to_archive_target_config', 'Maximum', true);
select * from add_audit_log_action('add_to_backup_schedule', 'Maximum', true);
select * from add_audit_log_action('add_to_vcpus_params_live', 'Maximum', true);
select * from add_audit_log_action('archive_now', 'Maximum', true);
select * from add_audit_log_action('cancel', 'Maximum', true);
select * from add_audit_log_action('certificate_list', 'Maximum', true);
select * from add_audit_log_action('compute_free_memory', 'Maximum', true);
select * from add_audit_log_action('compute_memory_overhead', 'Maximum', true);
select * from add_audit_log_action('copy_bios_strings', 'Maximum', true);
select * from add_audit_log_action('create_new_blob', 'Maximum', true);
select * from add_audit_log_action('crl_list', 'Maximum', true);
select * from add_audit_log_action('detect_nonhomogeneous_external_auth', 'Maximum', true);
select * from add_audit_log_action('disable_database_replication', 'Maximum', true);
select * from add_audit_log_action('enable_database_replication', 'Maximum', true);
select * from add_audit_log_action('forget_data_source_archives', 'Maximum', true);
select * from add_audit_log_action('from', 'Maximum', true);
select * from add_audit_log_action('get', 'Maximum', true);
select * from add_audit_log_action('get_alerts', 'Maximum', true);
select * from add_audit_log_action('get_all', 'Maximum', true);
select * from add_audit_log_action('get_all_records', 'Maximum', true);
select * from add_audit_log_action('get_all_records_where', 'Maximum', true);
select * from add_audit_log_action('get_all_subject_identifiers', 'Maximum', true);
select * from add_audit_log_action('get_allowed_vbd_devices', 'Maximum', true);
select * from add_audit_log_action('get_allowed_vif_devices', 'Maximum', true);
select * from add_audit_log_action('get_boot_record', 'Maximum', true);
select * from add_audit_log_action('get_by_permission', 'Maximum', true);
select * from add_audit_log_action('get_by_permission_name_label', 'Maximum', true);
select * from add_audit_log_action('get_by_uuid', 'Maximum', true);
select * from add_audit_log_action('get_cooperative', 'Maximum', true);
select * from add_audit_log_action('get_current_id', 'Maximum', true);
select * from add_audit_log_action('get_data_sources', 'Maximum', true);
select * from add_audit_log_action('get_group_membership', 'Maximum', true);
select * from add_audit_log_action('get_license_state', 'Maximum', true);
select * from add_audit_log_action('get_log', 'Maximum', true);
select * from add_audit_log_action('get_management_interface', 'Maximum', true);
select * from add_audit_log_action('get_permissions', 'Maximum', true);
select * from add_audit_log_action('get_permissions_name_label', 'Maximum', true);
select * from add_audit_log_action('get_record', 'Maximum', true);
select * from add_audit_log_action('get_remaining_capacity', 'Maximum', true);
select * from add_audit_log_action('get_server_certificate', 'Maximum', true);
select * from add_audit_log_action('get_server_localtime', 'Maximum', true);
select * from add_audit_log_action('get_servertime', 'Maximum', true);
select * from add_audit_log_action('get_since', 'Maximum', true);
select * from add_audit_log_action('get_subject_information_from_identifier', 'Maximum', true);
select * from add_audit_log_action('get_supported_types', 'Maximum', true);
select * from add_audit_log_action('get_system_status_capabilities', 'Maximum', true);
select * from add_audit_log_action('get_uncooperative_resident_vms', 'Maximum', true);
select * from add_audit_log_action('get_vms_which_prevent_evacuation', 'Maximum', true);
select * from add_audit_log_action('ha_compute_hypothetical_max_host_failures_to_tolerate', 'Maximum', true);
select * from add_audit_log_action('ha_compute_max_host_failures_to_tolerate', 'Maximum', true);
select * from add_audit_log_action('ha_compute_vm_failover_plan', 'Maximum', true);
select * from add_audit_log_action('ha_failover_plan_exists', 'Maximum', true);
select * from add_audit_log_action('ha_prevent_restarts_for', 'Maximum', true);
select * from add_audit_log_action('import_convert', 'Maximum', true);
select * from add_audit_log_action('inject', 'Maximum', true);
select * from add_audit_log_action('insert', 'Maximum', true);
select * from add_audit_log_action('list_methods', 'Maximum', true);
select * from add_audit_log_action('make', 'Maximum', true);
select * from add_audit_log_action('migrate_receive', 'Maximum', true);
select * from add_audit_log_action('migrate_send', 'Maximum', true);
select * from add_audit_log_action('next', 'Maximum', true);
select * from add_audit_log_action('open_database', 'Maximum', true);
select * from add_audit_log_action('probe', 'Maximum', true);
select * from add_audit_log_action('protect_now', 'Maximum', true);
select * from add_audit_log_action('query_data_source', 'Maximum', true);
select * from add_audit_log_action('query_services', 'Maximum', true);
select * from add_audit_log_action('read_database_pool_uuid', 'Maximum', true);
select * from add_audit_log_action('record_data_source', 'Full', true);
select * from add_audit_log_action('refresh_pack_info', 'Maximum', true);
select * from add_audit_log_action('register', 'Maximum', true);
select * from add_audit_log_action('remove_enabled_vgpu_types', 'Maximum', true);
select * from add_audit_log_action('remove_from_alarm_config', 'Maximum', true);
select * from add_audit_log_action('remove_from_archive_schedule', 'Maximum', true);
select * from add_audit_log_action('remove_from_archive_target_config', 'Maximum', true);
select * from add_audit_log_action('remove_from_backup_schedule', 'Maximum', true);
select * from add_audit_log_action('remove_ipv4_allowed', 'Maximum', true);
select * from add_audit_log_action('remove_ipv6_allowed', 'Maximum', true);
select * from add_audit_log_action('retrieve_wlb_configuration', 'Maximum', true);
select * from add_audit_log_action('retrieve_wlb_evacuate_recommendations', 'Maximum', true);
select * from add_audit_log_action('send_debug_keys', 'Maximum', true);
select * from add_audit_log_action('send_sysrq', 'Maximum', true);
select * from add_audit_log_action('send_test_post', 'Maximum', true);
select * from add_audit_log_action('send_trigger', 'Maximum', true);
select * from add_audit_log_action('set_alarm_config', 'Maximum', true);
select * from add_audit_log_action('set_appliance', 'Maximum', true);
select * from add_audit_log_action('set_archive_frequency', 'Maximum', true);
select * from add_audit_log_action('set_archive_last_run_time', 'Maximum', true);
select * from add_audit_log_action('set_archive_schedule', 'Maximum', true);
select * from add_audit_log_action('set_archive_target_config', 'Maximum', true);
select * from add_audit_log_action('set_archive_target_type', 'Maximum', true);
select * from add_audit_log_action('set_backup_frequency', 'Maximum', true);
select * from add_audit_log_action('set_backup_last_run_time', 'Maximum', true);
select * from add_audit_log_action('set_backup_retention_value', 'Maximum', true);
select * from add_audit_log_action('set_backup_schedule', 'Maximum', true);
select * from add_audit_log_action('set_enabled_vgpu_types', 'Maximum', true);
select * from add_audit_log_action('set_gpu_group', 'Maximum', true);
select * from add_audit_log_action('set_hvm_shadow_multiplier', 'Maximum', true);
select * from add_audit_log_action('set_ipv4_allowed', 'Maximum', true);
select * from add_audit_log_action('set_ipv6_allowed', 'Maximum', true);
select * from add_audit_log_action('set_is_alarm_enabled', 'Maximum', true);
select * from add_audit_log_action('set_locking_mode', 'Maximum', true);
select * from add_audit_log_action('set_order', 'Maximum', true);
select * from add_audit_log_action('set_physical_size', 'Full', true);
select * from add_audit_log_action('set_protection_policy', 'Maximum', true);
select * from add_audit_log_action('set_shadow_multiplier_live', 'Maximum', true);
select * from add_audit_log_action('set_shutdown_delay', 'Maximum', true);
select * from add_audit_log_action('set_start_delay', 'Maximum', true);
select * from add_audit_log_action('set_suspend_vdi', 'Maximum', true);
select * from add_audit_log_action('set_vcpus_at_startup', 'Maximum', true);
select * from add_audit_log_action('set_vcpus_max', 'Maximum', true);
select * from add_audit_log_action('set_vcpus_number_live', 'Maximum', true);
select * from add_audit_log_action('set_virtual_allocation', 'Full', true);
select * from add_audit_log_action('sync_database', 'Maximum', true);
select * from add_audit_log_action('test_archive_target', 'Maximum', true);
select * from add_audit_log_action('unregister', 'Maximum', true);
select * from add_audit_log_action('update_allowed_operations', 'Maximum', true);
select * from add_audit_log_action('upload', 'Maximum', true);
select * from add_audit_log_action('wait_memory_target_live', 'Maximum', true);
select * from add_audit_log_action('get_access_pif', 'Maximum', true);
select * from add_audit_log_action('get_actions_after_crash', 'Maximum', true);
select * from add_audit_log_action('get_actions_after_reboot', 'Maximum', true);
select * from add_audit_log_action('get_actions_after_shutdown', 'Maximum', true);
select * from add_audit_log_action('get_address', 'Maximum', true);
select * from add_audit_log_action('get_affinity', 'Maximum', true);
select * from add_audit_log_action('get_after_apply_guidance', 'Maximum', true);
select * from add_audit_log_action('get_alarm_config', 'Maximum', true);
select * from add_audit_log_action('get_allocation_algorithm', 'Maximum', true);
select * from add_audit_log_action('get_appliance', 'Maximum', true);
select * from add_audit_log_action('get_applied', 'Maximum', true);
select * from add_audit_log_action('get_archive_frequency', 'Maximum', true);
select * from add_audit_log_action('get_archive_last_run_time', 'Maximum', true);
select * from add_audit_log_action('get_archive_schedule', 'Maximum', true);
select * from add_audit_log_action('get_archive_target_config', 'Maximum', true);
select * from add_audit_log_action('get_archive_target_type', 'Maximum', true);
select * from add_audit_log_action('get_attached_pcis', 'Maximum', true);
select * from add_audit_log_action('get_auth_user_name', 'Maximum', true);
select * from add_audit_log_action('get_auth_user_sid', 'Maximum', true);
select * from add_audit_log_action('get_backend', 'Maximum', true);
select * from add_audit_log_action('get_backup_frequency', 'Maximum', true);
select * from add_audit_log_action('get_backup_last_run_time', 'Maximum', true);
select * from add_audit_log_action('get_backup_retention_value', 'Maximum', true);
select * from add_audit_log_action('get_backup_schedule', 'Maximum', true);
select * from add_audit_log_action('get_backup_type', 'Maximum', true);
select * from add_audit_log_action('get_bios_strings', 'Maximum', true);
select * from add_audit_log_action('get_blobs', 'Maximum', true);
select * from add_audit_log_action('get_blocked_operations', 'Maximum', true);
select * from add_audit_log_action('get_body', 'Maximum', true);
select * from add_audit_log_action('get_bond_master_of', 'Maximum', true);
select * from add_audit_log_action('get_bond_slave_of', 'Maximum', true);
select * from add_audit_log_action('get_bootable', 'Maximum', true);
select * from add_audit_log_action('get_bridge', 'Maximum', true);
select * from add_audit_log_action('get_capabilities', 'Maximum', true);
select * from add_audit_log_action('get_carrier', 'Maximum', true);
select * from add_audit_log_action('get_children', 'Maximum', true);
select * from add_audit_log_action('get_chipset_info', 'Maximum', true);
select * from add_audit_log_action('get_class', 'Maximum', true);
select * from add_audit_log_action('get_class_name', 'Maximum', true);
select * from add_audit_log_action('get_cls', 'Maximum', true);
select * from add_audit_log_action('get_configuration', 'Maximum', true);
select * from add_audit_log_action('get_consoles', 'Maximum', true);
select * from add_audit_log_action('get_content_type', 'Maximum', true);
select * from add_audit_log_action('get_copyright', 'Maximum', true);
select * from add_audit_log_action('get_cpu_configuration', 'Maximum', true);
select * from add_audit_log_action('get_cpu_info', 'Maximum', true);
select * from add_audit_log_action('get_crash_dump_sr', 'Maximum', true);
select * from add_audit_log_action('get_crash_dumps', 'Maximum', true);
select * from add_audit_log_action('get_crashdumps', 'Maximum', true);
select * from add_audit_log_action('get_created', 'Maximum', true);
select * from add_audit_log_action('get_current_operations', 'Maximum', true);
select * from add_audit_log_action('get_currently_attached', 'Maximum', true);
select * from add_audit_log_action('get_default_locking_mode', 'Maximum', true);
select * from add_audit_log_action('get_default_sr', 'Maximum', true);
select * from add_audit_log_action('get_dependencies', 'Maximum', true);
select * from add_audit_log_action('get_device', 'Maximum', true);
select * from add_audit_log_action('get_device_config', 'Maximum', true);
select * from add_audit_log_action('get_device_id', 'Maximum', true);
select * from add_audit_log_action('get_device_name', 'Maximum', true);
select * from add_audit_log_action('get_disallow_unplug', 'Maximum', true);
select * from add_audit_log_action('get_disks', 'Maximum', true);
select * from add_audit_log_action('get_dns', 'Maximum', true);
select * from add_audit_log_action('get_domarch', 'Maximum', true);
select * from add_audit_log_action('get_domid', 'Maximum', true);
select * from add_audit_log_action('get_driver_filename', 'Maximum', true);
select * from add_audit_log_action('get_duplex', 'Maximum', true);
select * from add_audit_log_action('get_edition', 'Maximum', true);
select * from add_audit_log_action('get_empty', 'Maximum', true);
select * from add_audit_log_action('get_enabled', 'Maximum', true);
select * from add_audit_log_action('get_enabled_on_gpu_groups', 'Maximum', true);
select * from add_audit_log_action('get_enabled_on_pgpus', 'Maximum', true);
select * from add_audit_log_action('get_enabled_vgpu_types', 'Maximum', true);
select * from add_audit_log_action('get_error_info', 'Maximum', true);
select * from add_audit_log_action('get_external_auth_configuration', 'Maximum', true);
select * from add_audit_log_action('get_external_auth_service_name', 'Maximum', true);
select * from add_audit_log_action('get_external_auth_type', 'Maximum', true);
select * from add_audit_log_action('get_family', 'Maximum', true);
select * from add_audit_log_action('get_features', 'Maximum', true);
select * from add_audit_log_action('get_finished', 'Maximum', true);
select * from add_audit_log_action('get_flags', 'Maximum', true);
select * from add_audit_log_action('get_framebuffer_size', 'Maximum', true);
select * from add_audit_log_action('get_fullname', 'Maximum', true);
select * from add_audit_log_action('get_gateway', 'Maximum', true);
select * from add_audit_log_action('get_generation_id', 'Maximum', true);
select * from add_audit_log_action('get_gpu_group', 'Maximum', true);
select * from add_audit_log_action('get_gpu_types', 'Maximum', true);
select * from add_audit_log_action('get_guest_metrics', 'Maximum', true);
select * from add_audit_log_action('get_guest_vcpus_params', 'Maximum', true);
select * from add_audit_log_action('get_gui_config', 'Maximum', true);
select * from add_audit_log_action('get_ha_allow_overcommit', 'Maximum', true);
select * from add_audit_log_action('get_ha_always_run', 'Maximum', true);
select * from add_audit_log_action('get_ha_configuration', 'Maximum', true);
select * from add_audit_log_action('get_ha_enabled', 'Maximum', true);
select * from add_audit_log_action('get_ha_host_failures_to_tolerate', 'Maximum', true);
select * from add_audit_log_action('get_ha_network_peers', 'Maximum', true);
select * from add_audit_log_action('get_ha_overcommitted', 'Maximum', true);
select * from add_audit_log_action('get_ha_plan_exists_for', 'Maximum', true);
select * from add_audit_log_action('get_ha_restart_priority', 'Maximum', true);
select * from add_audit_log_action('get_ha_statefiles', 'Maximum', true);
select * from add_audit_log_action('get_host', 'Maximum', true);
select * from add_audit_log_action('get_host_cpus', 'Maximum', true);
select * from add_audit_log_action('get_host_patches', 'Maximum', true);
select * from add_audit_log_action('get_hostname', 'Maximum', true);
select * from add_audit_log_action('get_hvm_boot_params', 'Maximum', true);
select * from add_audit_log_action('get_hvm_boot_policy', 'Maximum', true);
select * from add_audit_log_action('get_hvm_shadow_multiplier', 'Maximum', true);
select * from add_audit_log_action('get_id', 'Maximum', true);
select * from add_audit_log_action('get_install_time', 'Maximum', true);
select * from add_audit_log_action('get_introduced_by', 'Maximum', true);
select * from add_audit_log_action('get_introduced_srs', 'Maximum', true);
select * from add_audit_log_action('get_io_read_kbs', 'Maximum', true);
select * from add_audit_log_action('get_io_write_kbs', 'Maximum', true);
select * from add_audit_log_action('get_ip', 'Maximum', true);
select * from add_audit_log_action('get_ip_configuration_mode', 'Maximum', true);
select * from add_audit_log_action('get_ipv4_allowed', 'Maximum', true);
select * from add_audit_log_action('get_ipv6', 'Maximum', true);
select * from add_audit_log_action('get_ipv6_allowed', 'Maximum', true);
select * from add_audit_log_action('get_ipv6_configuration_mode', 'Maximum', true);
select * from add_audit_log_action('get_ipv6_gateway', 'Maximum', true);
select * from add_audit_log_action('get_is_a_snapshot', 'Maximum', true);
select * from add_audit_log_action('get_is_a_template', 'Maximum', true);
select * from add_audit_log_action('get_is_alarm_enabled', 'Maximum', true);
select * from add_audit_log_action('get_is_archive_running', 'Maximum', true);
select * from add_audit_log_action('get_is_backup_running', 'Maximum', true);
select * from add_audit_log_action('get_is_control_domain', 'Maximum', true);
select * from add_audit_log_action('get_is_local_superuser', 'Maximum', true);
select * from add_audit_log_action('get_is_policy_enabled', 'Maximum', true);
select * from add_audit_log_action('get_is_snapshot_from_vmpp', 'Maximum', true);
select * from add_audit_log_action('get_last_active', 'Maximum', true);
select * from add_audit_log_action('get_last_boot_cpu_flags', 'Maximum', true);
select * from add_audit_log_action('get_last_booted_record', 'Maximum', true);
select * from add_audit_log_action('get_last_updated', 'Maximum', true);
select * from add_audit_log_action('get_license_params', 'Maximum', true);
select * from add_audit_log_action('get_license_server', 'Maximum', true);
select * from add_audit_log_action('get_links_up', 'Maximum', true);
select * from add_audit_log_action('get_live', 'Maximum', true);
select * from add_audit_log_action('get_local_cache_enabled', 'Maximum', true);
select * from add_audit_log_action('get_local_cache_sr', 'Maximum', true);
select * from add_audit_log_action('get_location', 'Maximum', true);
select * from add_audit_log_action('get_locking_mode', 'Maximum', true);
select * from add_audit_log_action('get_logging', 'Maximum', true);
select * from add_audit_log_action('get_mac', 'Maximum', true);
select * from add_audit_log_action('get_mac_autogenerated', 'Maximum', true);
select * from add_audit_log_action('get_managed', 'Maximum', true);
select * from add_audit_log_action('get_management', 'Maximum', true);
select * from add_audit_log_action('get_master', 'Maximum', true);
select * from add_audit_log_action('get_max', 'Maximum', true);
select * from add_audit_log_action('get_max_heads', 'Maximum', true);
select * from add_audit_log_action('get_max_resolution_x', 'Maximum', true);
select * from add_audit_log_action('get_max_resolution_y', 'Maximum', true);
select * from add_audit_log_action('get_memory', 'Maximum', true);
select * from add_audit_log_action('get_memory_actual', 'Maximum', true);
select * from add_audit_log_action('get_memory_dynamic_max', 'Maximum', true);
select * from add_audit_log_action('get_memory_dynamic_min', 'Maximum', true);
select * from add_audit_log_action('get_memory_free', 'Maximum', true);
select * from add_audit_log_action('get_memory_overhead', 'Maximum', true);
select * from add_audit_log_action('get_memory_static_max', 'Maximum', true);
select * from add_audit_log_action('get_memory_static_min', 'Maximum', true);
select * from add_audit_log_action('get_memory_target', 'Maximum', true);
select * from add_audit_log_action('get_memory_total', 'Maximum', true);
select * from add_audit_log_action('get_metadata_latest', 'Maximum', true);
select * from add_audit_log_action('get_metadata_of_pool', 'Maximum', true);
select * from add_audit_log_action('get_metadata_vdis', 'Maximum', true);
select * from add_audit_log_action('get_metrics', 'Maximum', true);
select * from add_audit_log_action('get_mime_type', 'Maximum', true);
select * from add_audit_log_action('get_min', 'Maximum', true);
select * from add_audit_log_action('get_missing', 'Maximum', true);
select * from add_audit_log_action('get_mode', 'Maximum', true);
select * from add_audit_log_action('get_model', 'Maximum', true);
select * from add_audit_log_action('get_model_name', 'Maximum', true);
select * from add_audit_log_action('get_modelname', 'Maximum', true);
select * from add_audit_log_action('get_mtu', 'Maximum', true);
select * from add_audit_log_action('get_name', 'Maximum', true);
select * from add_audit_log_action('get_name_description', 'Maximum', true);
select * from add_audit_log_action('get_name_label', 'Maximum', true);
select * from add_audit_log_action('get_netmask', 'Maximum', true);
select * from add_audit_log_action('get_network', 'Maximum', true);
select * from add_audit_log_action('get_networks', 'Maximum', true);
select * from add_audit_log_action('get_number', 'Maximum', true);
select * from add_audit_log_action('get_obj_uuid', 'Maximum', true);
select * from add_audit_log_action('get_on_boot', 'Maximum', true);
select * from add_audit_log_action('get_operation', 'Maximum', true);
select * from add_audit_log_action('get_order', 'Maximum', true);
select * from add_audit_log_action('get_originator', 'Maximum', true);
select * from add_audit_log_action('get_os_version', 'Maximum', true);
select * from add_audit_log_action('get_other', 'Maximum', true);
select * from add_audit_log_action('get_other_config', 'Maximum', true);
select * from add_audit_log_action('get_parent', 'Maximum', true);
select * from add_audit_log_action('get_patches', 'Maximum', true);
select * from add_audit_log_action('get_pbds', 'Maximum', true);
select * from add_audit_log_action('get_pci', 'Maximum', true);
select * from add_audit_log_action('get_pci_bus', 'Maximum', true);
select * from add_audit_log_action('get_pci_bus_path', 'Maximum', true);
select * from add_audit_log_action('get_pci_id', 'Maximum', true);
select * from add_audit_log_action('get_pcis', 'Maximum', true);
select * from add_audit_log_action('get_pgpus', 'Maximum', true);
select * from add_audit_log_action('get_physical', 'Maximum', true);
select * from add_audit_log_action('get_physical_size', 'Maximum', true);
select * from add_audit_log_action('get_physical_utilisation', 'Maximum', true);
select * from add_audit_log_action('get_pifs', 'Maximum', true);
select * from add_audit_log_action('get_platform', 'Maximum', true);
select * from add_audit_log_action('get_pool', 'Maximum', true);
select * from add_audit_log_action('get_pool_applied', 'Maximum', true);
select * from add_audit_log_action('get_pool_patch', 'Maximum', true);
select * from add_audit_log_action('get_power_on_config', 'Maximum', true);
select * from add_audit_log_action('get_power_on_mode', 'Maximum', true);
select * from add_audit_log_action('get_power_state', 'Maximum', true);
select * from add_audit_log_action('get_primary_address_type', 'Maximum', true);
select * from add_audit_log_action('get_primary_slave', 'Maximum', true);
select * from add_audit_log_action('get_priority', 'Maximum', true);
select * from add_audit_log_action('get_progress', 'Maximum', true);
select * from add_audit_log_action('get_properties', 'Maximum', true);
select * from add_audit_log_action('get_protection_policy', 'Maximum', true);
select * from add_audit_log_action('get_protocol', 'Maximum', true);
select * from add_audit_log_action('get_public', 'Maximum', true);
select * from add_audit_log_action('get_pv_args', 'Maximum', true);
select * from add_audit_log_action('get_pv_bootloader', 'Maximum', true);
select * from add_audit_log_action('get_pv_bootloader_args', 'Maximum', true);
select * from add_audit_log_action('get_pv_drivers_up_to_date', 'Maximum', true);
select * from add_audit_log_action('get_pv_drivers_version', 'Maximum', true);
select * from add_audit_log_action('get_pv_kernel', 'Maximum', true);
select * from add_audit_log_action('get_pv_legacy_args', 'Maximum', true);
select * from add_audit_log_action('get_pv_ramdisk', 'Maximum', true);
select * from add_audit_log_action('get_qos_algorithm_params', 'Maximum', true);
select * from add_audit_log_action('get_qos_algorithm_type', 'Maximum', true);
select * from add_audit_log_action('get_qos_supported_algorithms', 'Maximum', true);
select * from add_audit_log_action('get_rbac_permissions', 'Maximum', true);
select * from add_audit_log_action('get_read_only', 'Maximum', true);
select * from add_audit_log_action('get_recent_alerts', 'Maximum', true);
select * from add_audit_log_action('get_recommendations', 'Maximum', true);
select * from add_audit_log_action('get_redo_log_enabled', 'Maximum', true);
select * from add_audit_log_action('get_redo_log_vdi', 'Maximum', true);
select * from add_audit_log_action('get_ref', 'Maximum', true);
select * from add_audit_log_action('get_required_api_version', 'Maximum', true);
select * from add_audit_log_action('get_resident_on', 'Maximum', true);
select * from add_audit_log_action('get_resident_vgpus', 'Maximum', true);
select * from add_audit_log_action('get_resident_vms', 'Maximum', true);
select * from add_audit_log_action('get_restrictions', 'Maximum', true);
select * from add_audit_log_action('get_result', 'Maximum', true);
select * from add_audit_log_action('get_roles', 'Maximum', true);
select * from add_audit_log_action('get_runtime_properties', 'Maximum', true);
select * from add_audit_log_action('get_sched_policy', 'Maximum', true);
select * from add_audit_log_action('get_sharable', 'Maximum', true);
select * from add_audit_log_action('get_shared', 'Maximum', true);
select * from add_audit_log_action('get_short_name', 'Maximum', true);
select * from add_audit_log_action('get_shutdown_delay', 'Maximum', true);
select * from add_audit_log_action('get_size', 'Maximum', true);
select * from add_audit_log_action('get_slaves', 'Maximum', true);
select * from add_audit_log_action('get_sm_config', 'Maximum', true);
select * from add_audit_log_action('get_snapshot_info', 'Maximum', true);
select * from add_audit_log_action('get_snapshot_metadata', 'Maximum', true);
select * from add_audit_log_action('get_snapshot_of', 'Maximum', true);
select * from add_audit_log_action('get_snapshot_time', 'Maximum', true);
select * from add_audit_log_action('get_snapshots', 'Maximum', true);
select * from add_audit_log_action('get_software_version', 'Maximum', true);
select * from add_audit_log_action('get_speed', 'Maximum', true);
select * from add_audit_log_action('get_sr', 'Maximum', true);
select * from add_audit_log_action('get_standard', 'Maximum', true);
select * from add_audit_log_action('get_start_delay', 'Maximum', true);
select * from add_audit_log_action('get_start_time', 'Maximum', true);
select * from add_audit_log_action('get_state', 'Maximum', true);
select * from add_audit_log_action('get_status', 'Maximum', true);
select * from add_audit_log_action('get_status_code', 'Maximum', true);
select * from add_audit_log_action('get_status_detail', 'Maximum', true);
select * from add_audit_log_action('get_stepping', 'Maximum', true);
select * from add_audit_log_action('get_storage_lock', 'Maximum', true);
select * from add_audit_log_action('get_subject', 'Maximum', true);
select * from add_audit_log_action('get_subject_identifier', 'Maximum', true);
select * from add_audit_log_action('get_subroles', 'Maximum', true);
select * from add_audit_log_action('get_subtask_of', 'Maximum', true);
select * from add_audit_log_action('get_subtasks', 'Maximum', true);
select * from add_audit_log_action('get_supported_bootloaders', 'Maximum', true);
select * from add_audit_log_action('get_supported_on_gpu_groups', 'Maximum', true);
select * from add_audit_log_action('get_supported_on_pgpus', 'Maximum', true);
select * from add_audit_log_action('get_supported_vgpu_max_capacities', 'Maximum', true);
select * from add_audit_log_action('get_supported_vgpu_types', 'Maximum', true);
select * from add_audit_log_action('get_suspend_image_sr', 'Maximum', true);
select * from add_audit_log_action('get_suspend_sr', 'Maximum', true);
select * from add_audit_log_action('get_suspend_vdi', 'Maximum', true);
select * from add_audit_log_action('get_tag', 'Maximum', true);
select * from add_audit_log_action('get_tagged_pif', 'Maximum', true);
select * from add_audit_log_action('get_tags', 'Maximum', true);
select * from add_audit_log_action('get_tasks', 'Maximum', true);
select * from add_audit_log_action('get_this_host', 'Maximum', true);
select * from add_audit_log_action('get_this_user', 'Maximum', true);
select * from add_audit_log_action('get_timestamp', 'Maximum', true);
select * from add_audit_log_action('get_timestamp_applied', 'Maximum', true);
select * from add_audit_log_action('get_transport_pif', 'Maximum', true);
select * from add_audit_log_action('get_transportable_snapshot_id', 'Maximum', true);
select * from add_audit_log_action('get_tunnel_access_pif_of', 'Maximum', true);
select * from add_audit_log_action('get_tunnel_transport_pif_of', 'Maximum', true);
select * from add_audit_log_action('get_type', 'Maximum', true);
select * from add_audit_log_action('get_units', 'Maximum', true);
select * from add_audit_log_action('get_unpluggable', 'Maximum', true);
select * from add_audit_log_action('get_untagged_pif', 'Maximum', true);
select * from add_audit_log_action('get_user_version', 'Maximum', true);
select * from add_audit_log_action('get_userdevice', 'Maximum', true);
select * from add_audit_log_action('get_utilisation', 'Maximum', true);
select * from add_audit_log_action('get_uuid', 'Maximum', true);
select * from add_audit_log_action('get_validation_time', 'Maximum', true);
select * from add_audit_log_action('get_value', 'Maximum', true);
select * from add_audit_log_action('get_vbds', 'Maximum', true);
select * from add_audit_log_action('get_vcpus_at_startup', 'Maximum', true);
select * from add_audit_log_action('get_vcpus_cpu', 'Maximum', true);
select * from add_audit_log_action('get_vcpus_flags', 'Maximum', true);
select * from add_audit_log_action('get_vcpus_max', 'Maximum', true);
select * from add_audit_log_action('get_vcpus_number', 'Maximum', true);
select * from add_audit_log_action('get_vcpus_params', 'Maximum', true);
select * from add_audit_log_action('get_vcpus_utilisation', 'Maximum', true);
select * from add_audit_log_action('get_vdi', 'Maximum', true);
select * from add_audit_log_action('get_vdis', 'Maximum', true);
select * from add_audit_log_action('get_vendor', 'Maximum', true);
select * from add_audit_log_action('get_vendor_id', 'Maximum', true);
select * from add_audit_log_action('get_vendor_name', 'Maximum', true);
select * from add_audit_log_action('get_version', 'Maximum', true);
select * from add_audit_log_action('get_vgpus', 'Maximum', true);
select * from add_audit_log_action('get_vifs', 'Maximum', true);
select * from add_audit_log_action('get_virtual_allocation', 'Maximum', true);
select * from add_audit_log_action('get_virtual_size', 'Maximum', true);
select * from add_audit_log_action('get_vlan', 'Maximum', true);
select * from add_audit_log_action('get_vlan_master_of', 'Maximum', true);
select * from add_audit_log_action('get_vlan_slave_of', 'Maximum', true);
select * from add_audit_log_action('get_vm', 'Maximum', true);
select * from add_audit_log_action('get_vms', 'Maximum', true);
select * from add_audit_log_action('get_vswitch_controller', 'Maximum', true);
select * from add_audit_log_action('get_vtpms', 'Maximum', true);
select * from add_audit_log_action('get_wlb_enabled', 'Maximum', true);
select * from add_audit_log_action('get_wlb_url', 'Maximum', true);
select * from add_audit_log_action('get_wlb_username', 'Maximum', true);
select * from add_audit_log_action('get_wlb_verify_cert', 'Maximum', true);
select * from add_audit_log_action('get_xenstore_data', 'Maximum', true);

-- Full Actions
select * from add_audit_log_action('assert_agile', 'Full', false);
select * from add_audit_log_action('assert_attachable', 'Full', false);
select * from add_audit_log_action('assert_can_be_recovered', 'Full', false);
select * from add_audit_log_action('assert_can_boot_here', 'Full', false);
select * from add_audit_log_action('assert_can_evacuate', 'Full', false);
select * from add_audit_log_action('assert_can_host_ha_statefile', 'Full', false);
select * from add_audit_log_action('assert_can_migrate', 'Full', false);
select * from add_audit_log_action('assert_operation_valid', 'Full', false);
select * from add_audit_log_action('assert_supports_database_replication', 'Full', false);
select * from add_audit_log_action('scan', 'Full', false);
select * from add_audit_log_action('get_api_version_major', 'Full', false);
select * from add_audit_log_action('get_api_version_minor', 'Full', false);
select * from add_audit_log_action('get_api_version_vendor', 'Full', false);
select * from add_audit_log_action('get_api_version_vendor_implementation', 'Full', false);
select * from add_audit_log_action('get_allow_caching', 'Full', false);
select * from add_audit_log_action('get_allowed_operations', 'Full', false);

-- Drop the temporary functions
DROP FUNCTION "WorkloadBalancing"."add_audit_log_object"
(
  _name varchar,
  _granularity varchar,
  _enabled boolean,
  _description varchar
);
DROP FUNCTION "WorkloadBalancing"."add_audit_log_action"
(
  _name varchar,
  _granularity varchar,
  _enabled boolean,
  _description varchar
);

CREATE OR REPLACE FUNCTION "WorkloadBalancing"."tmp_add_update_hv_pool_config"
(
  "_name" varchar,
  "_value" varchar,
  "_default_value" varchar,
  "_description" varchar = null
)
RETURNS void AS
$$
declare UTCTimestamp timestamp;
BEGIN

	UTCTimestamp = (select current_timestamp at time zone 'UTC');

	-- This section is for default data
	if not exists(select * from "WorkloadBalancing"."hv_pool_config"
    		 	  where pool_id is null and lower(name) = lower(_name))
    then
		insert into "WorkloadBalancing"."hv_pool_config"
        (pool_id, name, value, default_value, description, tstamp)
		values
        (null, _name, _value, _default_value, _description, UTCTimestamp);
    else
    	update "WorkloadBalancing"."hv_pool_config"
		set default_value = _default_value,
			description = _description,
        	tstamp = UTCTimestamp
		where pool_id is null and lower(name) = lower(_name);
	end if;

	-- This section is for adding the new fields for existing pools
   	if not exists(select * from "WorkloadBalancing"."hv_pool_config"
    			 where pool_id is not null and lower(name) = lower(_name))
	then
    	insert into "WorkloadBalancing"."hv_pool_config"
        (pool_id, name, value, default_value, description, tstamp)
		select distinct pool_id, _name, _value, _default_value, _description, UTCTimestamp
			from "WorkloadBalancing"."hv_pool_config"
			where pool_id is not null;
	end if;

END;
$$
LANGUAGE 'plpgsql';

select * from "WorkloadBalancing"."tmp_add_update_hv_pool_config"('PoolAuditLogGranularity', 'Minimum', 'Minimum', 'Specify the pool audit trail log granularity. Default is Minimum.');

DROP FUNCTION "WorkloadBalancing"."tmp_add_update_hv_pool_config"("_name" varchar, "_value" varchar, "_default_value" varchar, "_description" varchar);

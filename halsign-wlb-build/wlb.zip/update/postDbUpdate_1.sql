-- ============================================================================
-- (c) Copyright 2012 Citrix Systems, Inc.
-- ALL RIGHTS RESERVED
--
-- Author:		Barbara Li
-- Date:		Mar 10, 2012
-- Description:
--	 Post-database-update script
-- ============================================================================

select * from "WorkloadBalancing".dwm_data_add_report_label('LBL_EVENT_OBJECT_UUID');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_OBJECT_UUID', 'en', 'Object UUID');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_OBJECT_UUID', 'ja', 'イベント UUIDは');
select * from "WorkloadBalancing".dwm_data_add_update_report_label_value('LBL_EVENT_OBJECT_UUID', 'zh', '对象标识');

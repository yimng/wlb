#!/bin/sh
#This script will make sure all the WLB services are running fine, if not it'll restart the dead ones

WLBPATH="/opt/halsign/wlb/"
WLBCONF=$WLBPATH"wlb.conf"
TMPPATH=/tmp/wlb/
#whether REST service is enabled
REST_ENABLED=1

pid_wc=`ps aux | grep DwmWebSvc.exe | grep -v grep | awk '{print $2}'`
pid_rwc=`ps aux | grep DwmRestWebSvc.exe | grep -v grep | awk '{print $2}'`
pid_dc=`ps aux | grep DwmDataColSvc.exe | grep -v grep | awk '{print $2}'`
pid_ae=`ps aux | grep DwmAnalEngSvc.exe | grep -v grep | awk '{print $2}'`

LOGFILE=$(grep LogFileLocation $WLBCONF | sed 's#\LogFileLocation\s*=\s*\(.*\)#\1#g')"/LogFile.log"
LOGFILE=${LOGFILE//[[:space:]]}

function log()
{	
	echo $(date +"%m/%d/%Y %H:%M:%S") - WlbWatchDog: $1 >> $LOGFILE
}

function check_status()
{
	fine=1
	dead=""
	if [ "$pid_wc" == "" ] ; then		
		#if lock file is still there, service must've crashed
		if [ -f ${TMPPATH}DwmWebSvc.exe.lock ]; then
			fine=0
			log "Web Service is dead."
		else #otherwise service was stopped manually using service stop command, do nothing
			log "Web service is not running."
		fi
	fi
	
	if [ "$REST_ENABLED" != "0" ]; then
	if [ "$pid_rwc" == "" ] ; then
		#if lock file is still there, service must've crashed
		if [ -f ${TMPPATH}DwmRestWebSvc.exe.lock ]; then
			fine=0
			log "REST Web Service is dead."
		else #otherwise service was stopped manually using service stop command, do nothing
			log "REST Web service is not running."
		fi
	fi
	fi

	if [ "$pid_dc" == "" ] ; then
		if [ -f ${TMPPATH}DwmDataColSvc.exe.lock ]; then
			fine=0
			log "Data Collection Service is dead."
		else
			log "Data collector is not running."
		fi
	fi
	
	if [ "$pid_ae" == "" ] ; then
		if [ -f ${TMPPATH}DwmAnalEngSvc.exe.lock ]; then
			fine=0
			log "Data Analysis Service is dead."			
		else
			log "Analysis engine is not running."
		fi
	fi
	
	if [ "$fine" == "0" ]; then
		log "Starting dead service(s)..."
		/etc/init.d/workloadbalancing start
		log "  [  OK  ]"
	fi
	
	#if [ "$fine" == "1" ]; then
	#	log "All WLB services are running fine."
	#fi
}

check_status;
